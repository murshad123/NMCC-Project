<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Acronyms extends MY_Controller {

	public function __construct() {
           parent::__construct();
           $this->load->model('admin/general_modal','model_general');
           $this->adminloginCheck();

    }
    
	public function  index(){
		$this->data['acronyms'] = $this->model_general->getacronyms();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}


	public function  add(){
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('acronym', ' Enter acronym Name', 'required');
		$this->form_validation->set_rules('definition', 'Enter Definition of Acronym Word', 'required');
        if(!$this->form_validation->run() == FALSE) {
			$table='acronyms';
			$totalFormData = array( 			
				'acronym'                  => $_POST['acronym'],
				'definition'               => $_POST['definition'],				
				'status'                   => $_POST['status'],
				'created_date'             => date('Y-m-d h:i:s')
			);	
				
			if($this->model_general->addRow($table,$totalFormData)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Acronym Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/acronyms';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to add Acronym.</div>');
				$redirecturl = ADMIN_URL.'/acronyms/add';
				redirect($redirecturl,'refresh');
			}
		}
        $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}

   public function updateStatus($status,$id){
		if($status == 'deactive'){
           $statusnew = '0';
		}else{
           $statusnew = '1';
		}

        $this->db->where('acronyms.id', $id);
        $this->db->update('acronyms', array('status' => $statusnew));
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable"> status successfully Updated.</div>');
        redirect($_SERVER['HTTP_REFERER'],'refresh');
    }

    public function delete($acronym_id){ 
	    if($this->model_general->deleteRow('acronyms','id',$acronym_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Acronym Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}

  	

	public function  edit($acronym_id){
        $table='acronyms';
		$this->data['acronyms'] = $this->model_general->GetAcronymsDetails($acronym_id);
		$this->data['acronym_id'] = $acronym_id;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('acronym', ' Enter acronym Name', 'required');
		$this->form_validation->set_rules('definition', 'Enter Definition of Acronym Word', 'required');
        if(!$this->form_validation->run() == FALSE) {
			$table='acronyms';
			$totalFormData = array( 			
				'acronym'                  => $_POST['acronym'],
				'definition'               => $_POST['definition'],				
				'status'                   => $_POST['status'],
				'created_date'             => date('Y-m-d h:i:s')
			);
		
			if($this->model_general->updateRow($table,$totalFormData,'id',$acronym_id)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Acronym Successfully Updated.</div>');
               $rediredcturl = ADMIN_URL.'acronyms/edit/'.$acronym_id; 
				redirect($rediredcturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to update Acronym.</div>');
			}
		}
					
       $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	
	}
		



}