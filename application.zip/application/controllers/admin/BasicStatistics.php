<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BasicStatistics extends MY_Controller {

	public function __construct() {
           parent::__construct();
           $this->load->model('admin/basicStatistics_modal','modal_basicStatistics');
           $this->adminloginCheck();

    }



    public function strainlist(){
		$this->data['strain'] = $this->modal_basicStatistics->getstrain();
		// print_r($this->data['strain']); die;
      
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}
    
	public function countries(){
		 $this->data['countries'] = $this->modal_basicStatistics->getactivecountries();
		 $this->data['continents'] = $this->modal_basicStatistics->getcontinents();
      $this->data['strain'] = $this->modal_basicStatistics->getstrain();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}

	public function stainadding(){
		$this->data['strain'] = $this->modal_basicStatistics->getstrain();
		$strainapecies = array_combine($_POST['strain'], $_POST['species']);
			$dataarray = array();
			foreach ($strainapecies as $key => $value) {
				$dataarray['strain'] = $key;
				$dataarray['species'] = $value;
				//$dataarray['country_id'] = $_POST['country_id'];
				$dataarray['status'] = 1;
				$dataarray['created_date'] = date('Y-m-d h:i:s');
                $insert = $this->modal_basicStatistics->insertdata('cultures_held',$dataarray);
                unset($dataarray);

			}

			if($insert){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">cultures Held Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/culturesHeld';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to add Cultures held.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
			}
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}


	public function  culturscollections(){
        /*  echo "<pre>";
          print_r($_POST); die;*/


		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('supported_by', ' Enter supported_by', 'required');
		$this->form_validation->set_rules('no_of_collection', 'Enter no_of_collection', 'required');
        if(!$this->form_validation->run() == FALSE) {
			$table='culture_collections';
			$totalFormData = array( 			
				'supported_by'             => $_POST['supported_by'],
				'no_of_collection'         => $_POST['no_of_collection'],	
				'status'                   =>1,
				'created_date'             => date('Y-m-d h:i:s')
			);

		/*	echo "<pre>";
          print_r($totalFormData); die;*/	
				
			if($this->modal_basicStatistics->insertdata($table,$totalFormData)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">cultures Collections Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to add Cultures Collections.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
			}
		}
        $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}


	public function culturesHeld(){
		$this->data['getculturesHeld'] = $this->modal_basicStatistics->getculturesHeld();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}


	public function  addculturesHeld(){
          // echo "<pre>";
          // print_r($_POST); die;


		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('strain', ' Enter strain', 'required');
		$this->form_validation->set_rules('species', 'Enter species', 'required');
        if(!$this->form_validation->run() == FALSE) {
			$table='cultures_held';
			$totalFormData = array( 			
				'strain'                  => $_POST['strain'],
				'species'               => $_POST['species'],				
				'status'                   => $_POST['status'],
				'created_date'             => date('Y-m-d h:i:s')
			);

			// echo "<pre>";
   //        print_r($totalFormData); die;	
				
			if($this->modal_basicStatistics->insertdata($table,$totalFormData)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">cultures Held Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/addculturesHeld';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to add Cultures held.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics.addculturesHeld';
				redirect($redirecturl,'refresh');
			}
		}
        $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}

   public function updateStatus($status,$id){
		if($status == 'deactive'){
           $statusnew = '0';
		}else{
           $statusnew = '1';
		}

        $this->db->where('cultures_held.id', $id);
        $this->db->update('cultures_held', array('status' => $statusnew));
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable"> status successfully Updated.</div>');
        redirect($_SERVER['HTTP_REFERER'],'refresh');
    }

    
  	

	

	public function editculturesHeld($cultures_held_id){
          // echo "<pre>";
          // print_r($_POST); die;
		  $this->data['editculturesHeld'] = $this->modal_basicStatistics->GetCulturesDetails($cultures_held_id);
		  $this->data['cultures_held_id']=$cultures_held_id;
		  //  echo "<pre>";
		  //  print_r($this->data['cultures_held_id']);
		  // die;


		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('strain', ' Enter strain', 'required');
		$this->form_validation->set_rules('species', 'Enter species', 'required');
        if(!$this->form_validation->run() == FALSE) {
			$table='cultures_held';
			$totalFormData = array( 			
				'strain'                  => $_POST['strain'],
				'species'               => $_POST['species'],				
				'status'                   => $_POST['status'],
				'created_date'             => date('Y-m-d h:i:s')
			);

			 // echo "<pre>";
    //          print_r($totalFormData); die;	
				
			if($this->modal_basicStatistics->updateRow($table,$totalFormData,'id',$cultures_held_id)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">cultures Held Successfully Updated.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/culturesHeld';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to Edit Cultures held.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/culturesHeld';
				redirect($redirecturl,'refresh');
			}
		}
        $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}
	
	public function deleteculturesHeld($cultures_held_id){
		$this->adminloginCheck();
	    if($this->modal_basicStatistics->deleteculturesHeldDetails($cultures_held_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">cultures_held Successfully.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}

  public function cultureCollection(){
		$this->data['cultureCollection'] = $this->modal_basicStatistics->getcultureCollection();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}


	public function addingculturesHeld(){
          // echo "<pre>";
          // print_r($_POST); die;
		if(isset($_POST['save'])){
           // echo "<pre>";
           // print_r($_POST); die;
			   
			   $data=$_POST['species'];
			   $count=count($data);
		   // echo "<pre>";
     //       print_r($data); 
     //       print_r($count);
     //       die;
		    for($i=0;$i<$count;$i++){
		    	$table='cultures_held';
			    $totalFormData[] = array( 			
				'strain'                  => $_POST['strain'],
				'species'               => $_POST['species']				
				
			);
		    $this->modal_basicStatistics->insertdata($table,$totalFormData);


		    }
		}
               

	
		
        $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}

	public function getajaxcountry()
	{
		$continent_cod = $this->input->post('continent_cod');

		if($continent_cod!=''){
			$this->data['countriess'] = $this->modal_basicStatistics->getContinentsCountry($continent_cod);
			// echo "<pre>";
			// print_r($this->data['countries']); die;
        $this->load->view('admin/basicStatistics/getajaxcountry',$this->data);	
			
          
		}
	}

	public function getajaxcountry2()
	{
		$continent_cod = $this->input->post('continent_cod');

		if($continent_cod!=''){
			$this->data['countriess'] = $this->modal_basicStatistics->getContinentsCountry($continent_cod);
			// echo "<pre>";
			// print_r($this->data['countries']); die;
        $this->load->view('admin/basicStatistics/getajaxcountry2',$this->data);	
			
          
		}
	}

	public function getajaxcountry3()
	{
		$continent_cod = $this->input->post('continent_cod');

		if($continent_cod!=''){
			$this->data['countriess'] = $this->modal_basicStatistics->getContinentsCountry($continent_cod);
			// echo "<pre>";
			// print_r($this->data['countries']); die;
        $this->load->view('admin/basicStatistics/getajaxcountry3',$this->data);	
			
          
		}
	}

public function numberCultureState()
{  
    $culture_collections_array =  array_filter($_POST['culture_collections']);
    $cultures_array =  array_filter($_POST['cultures']);
    $countries =  $_POST['country_name'];     
    $dataarray = array();
    

    if(!empty($countries)){
    	foreach ($countries as $key => $value) {
    		if(!empty($culture_collections_array[$key]))
    		{
    			$dataarray['country_name'] = $value;
				$dataarray['culture_collections'] = $culture_collections_array[$key];
				$dataarray['cultures'] = $cultures_array[$key];
				$dataarray['status'] = 1;
				$dataarray['created_date'] = date('Y-m-d h:i:s');
				$insert = $this->modal_basicStatistics->insertdata2('number_culture_collection',$dataarray,$value);
				unset($dataarray);
    		}
			
			

    	}
    } 
  
    if($insert){
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Culture Collections Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
	}else {
		$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to add Cultures held.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
	}
	       
    $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
}

public function serviceProvided()
{
	      // echo "<pre>";
       //    print_r($_POST);
       //   die;
	$patent_array =  array_filter($_POST['patent']);
    $store_array =  array_filter($_POST['store']);
    $distribution_array =  array_filter($_POST['distribution']);
    $identification_array =  array_filter($_POST['identification']);
    $training_array =  array_filter($_POST['training']);
    $consult_array =  array_filter($_POST['consult']);
    $countries =  $_POST['country_name'];     
    $dataarray = array();
    

    if(!empty($countries)){
    	foreach ($countries as $key => $value) {
    		if(!empty($patent_array[$key]))
    		{
    			$dataarray['countries'] = $value;
				$dataarray['patent'] = $patent_array[$key];
				$dataarray['store'] =  $store_array[$key];
				$dataarray['distribution'] =  $distribution_array[$key];
				$dataarray['identification'] =  $identification_array[$key];
				$dataarray['training'] = $training_array[$key];
				$dataarray['consult'] = $consult_array[$key];
				$dataarray['status'] = 1;
				$dataarray['created_date'] = date('Y-m-d h:i:s');
				$insert = $this->modal_basicStatistics->insertdata3('service_provided',$dataarray,$value);
		
				unset($dataarray);
    		}
			
			

    	}
    } 
  
    if($insert){
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Service Provided in addition to regular maintenance Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
	}else {
		$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to add Service Provided in addition to regular maintenance.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
	}
	       
    $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);


		
}

public function typesofservices()
{
	      // echo "<pre>";
       //    print_r($_POST);
        // die;


		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('service', ' Enter service', 'required');
		$this->form_validation->set_rules('collection', 'Enter collection', 'required');
        if(!$this->form_validation->run() == FALSE) {
			$table='culture_services';
			$totalFormData = array( 			
				'service'                     => $_POST['service'],
				'collection'                  => $_POST['collection'],	
			    'created_at'                => date('Y-m-d h:i:s')
			);

			// echo "<pre>";
   //        print_r($totalFormData); die;	
				
			if($this->modal_basicStatistics->insertdata($table,$totalFormData)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Service Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to add Service</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
			}
		}
        $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
}



   
   
    public function uploadDataCSVfile(){


        //$count=0;
        $fp = fopen($_FILES['userfile']['tmp_name'],'r') or die("can't open file");
        while($csv_line = fgetcsv($fp,1024))
        {
            // $count++;
            // if($count == 1)
            // {
            //     continue;
            // }//keep this if condition if you want to remove the first row
            for($i = 0, $j = count($csv_line); $i < $j; $i++)
            {
                $insert_csv = array();
                $insert_csv['strain'] = $csv_line[1];
               

            }
            $i++;
            $data = array(
                'strains' => $insert_csv['strain'],
                'status'                     => 1,
                'created_date' => date('Y-m-d h:i:s')
                 );
             $insert=$this->modal_basicStatistics->insertdata('strain', $data);
        }
        fclose($fp) or die("can't close file");
    if($insert){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Strains Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to add Strains.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/countries';
				redirect($redirecturl,'refresh');
			}


	  $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}


	public function straincultures(){
		$this->data['strains'] = $this->modal_basicStatistics->getstraincultures();
		/*echo "<pre>";
		print_r($this->data['strains']); die;*/
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}

	public function  addstraincultures(){
          // echo "<pre>";
          // print_r($_POST); die;


		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('strains', ' Enter strain', 'required');
		
        if(!$this->form_validation->run() == FALSE) {
			$table=' strain';
			$totalFormData = array( 			
				'strains'                  => $_POST['strains'],
						
				'status'                   => $_POST['status'],
				'created_date'             => date('Y-m-d h:i:s')
			);

		/*	echo "<pre>";
          print_r($totalFormData); die;	*/
				
			if($this->modal_basicStatistics->insertdata($table,$totalFormData)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Strain Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/addstraincultures';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to add Strain.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics.addstraincultures';
				redirect($redirecturl,'refresh');
			}
		}
        $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}


	public function editStraincultures($strain_id){
          // echo "<pre>";
          // print_r($_POST); die;
		  $this->data['editcultureStrain'] = $this->modal_basicStatistics->GetStrainCulturesDetails($strain_id);
		  $this->data['strain_id']=$strain_id;
		  /* echo "<pre>";
		   print_r($this->data['editcultureStrain']);
		  die;*/


		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('strains', ' Enter strain', 'required');
		
        if(!$this->form_validation->run() == FALSE) {
			$table='strain';
			$totalFormData = array( 			
				'strains'                  => $_POST['strains'],
							
				'status'                   => $_POST['status'],
				'created_date'             => date('Y-m-d h:i:s')
			);

			/* echo "<pre>";
             print_r($totalFormData); die;	*/
				
			if($this->modal_basicStatistics->updateRow($table,$totalFormData,'id',$strain_id)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Strain Successfully Updated.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/straincultures';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to Edit Cultures held.</div>');
				$redirecturl = ADMIN_URL.'/basicStatistics/straincultures';
				redirect($redirecturl,'refresh');
			}
		}
        $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}

		public function deleteStrainCultures($strain_id){
		$this->adminloginCheck();
	    if($this->modal_basicStatistics->deleteStrainCulturesDetails($strain_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Strain Successfully Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}

  	 public function updateStatus2($status,$id){
		if($status == 'deactive'){
           $statusnew = '0';
		}else{
           $statusnew = '1';
		}

        $this->db->where('strain.id', $id);
        $this->db->update('strain', array('status' => $statusnew));
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable"> status successfully Updated.</div>');
        redirect($_SERVER['HTTP_REFERER'],'refresh');
    }




}