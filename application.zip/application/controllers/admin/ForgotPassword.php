<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ForgotPassword extends MY_Controller {

	public function __construct() {
        parent::__construct();
        $this->load->model('admin/Forgot_Model');
        
    }


   public function index(){

        $this->load->view('admin/login/forgotpassword');


   }

   public function forgot_pass(){

         $email = $this->input->post('email');      
         $findemail = $this->Forgot_Model->ForgotPassword($email);  

         if($findemail){
          $this->Forgot_Model->sendpassword($findemail);        
           }
        else{
         $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Email not found!.</div>');
        $redirecturl = ADMIN_URL.'/Login';
        redirect($redirecturl,'refresh');
      }
      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Your Password is sent on Your Email ID !</div>');
        $redirecturl = ADMIN_URL.'/Login';
        redirect($redirecturl,'refresh');
   }







}  ?>