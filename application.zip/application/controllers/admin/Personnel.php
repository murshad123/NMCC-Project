<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Personnel extends MY_Controller {

	public function __construct() {
           parent::__construct();
           $this->load->model('admin/customer_modal','model_customer');

    }
    
	public function  index(){
		$this->adminloginCheck();
		$this->data['customers'] = $this->model_customer->getpersonal();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}


	public function  add(){
        $this->adminloginCheck();
        if($this->input->post('submit'))
		{
            $table='personnel';
            $totalFormData = array( 			
				'name'                  => $_POST['firstname'],
				'phonenumber'           => $_POST['phonenumber'],
				'designation'           => $_POST['designation'],
				'email'                 => $_POST['email'],
				'role'                  => $_POST['role'],
				'status'                => $_POST['status'],
				'created_date'          => date('Y-m-d h:i:s'),
			);	

			if (isset($_FILES['file'])) {
                $files = $_FILES['file'];
		        $_FILES['file']=array();
				$_FILES['file']['name'] = str_replace(' ','_',$files['name']);
				$_FILES['file']['type'] = $files['type'];
				$_FILES['file']['tmp_name'] = $files['tmp_name'];
				$_FILES['file']['error'] = $files['error'];
				$_FILES['file']['size'] = $files['size'];
				$uploadPath = 'assets/dist/personnel_img';
				$config['upload_path'] = $uploadPath;
				$config['allowed_types'] = 'jpg|png|jpeg';
				$config['max_width']  = '13490';
				$config['max_height']  = '4960';
				$this->load->library('upload', $config);
				$this->upload->initialize($config); 
                if($_FILES['file']['error']!= 4 ) {
					if($this->upload->do_upload('file')){
						$fileData = $this->upload->data();
						$totalFormData['image'] = $fileData['file_name'];
					}
				} 
			}    
		    if (isset($_FILES['resume'])) {
                $files = $_FILES['resume'];
		        $_FILES['resume']=array();			
				$_FILES['resume']['name'] = str_replace(' ','_',$files['name']);
				$_FILES['resume']['type'] = $files['type'];
				$_FILES['resume']['tmp_name'] = $files['tmp_name'];
				$_FILES['resume']['error'] = $files['error'];
				$_FILES['resume']['size'] = $files['size'];
				$uploadPath = 'assets/dist/personnel_pdf';
				$config['upload_path'] = $uploadPath;
				$config['allowed_types'] = 'pdf|doc';
				$config['max_width']  = '13490';
		        $config['max_height']  = '4960';
				$this->load->library('upload', $config);
				$this->upload->initialize($config); 
                if($_FILES['resume']['error']!= 4 ) {
					if($this->upload->do_upload('resume')){
						$fileData = $this->upload->data();
						$totalFormData['resume'] = $fileData['file_name'];
					}
				}
		    } 
		
			if($this->model_customer->insertdata($table,$totalFormData)){
                $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Personal Details Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/personnel';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add Customer.</div>');
				$redirecturl = ADMIN_URL.'/members';
				redirect($redirecturl,'refresh');
			}
		
	    }
        $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	

		
	}

	public function  view($customer_id){
		$this->adminloginCheck();
		$this->data['customers'] = $this->model_customer->getcustomersdetails($customer_id);
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function updateStatus($status,$id){
		$this->adminloginCheck();
		if($status == 'deactive'){
           $statusnew = '0';
		}else{
           $statusnew = '1';
		}

        $this->db->where('personnel.id', $id);
        $this->db->update('personnel', array('status' => $statusnew));
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable"> status successfully Updated.</div>');
        redirect($_SERVER['HTTP_REFERER'],'refresh');
    }

    public function delete($customer_id){
		$this->adminloginCheck();
	    if($this->model_customer->deletePersonalDetails($customer_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Personal Details Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}

  	public function  edit($member_id){
  		//echo $member_id; die;
		$this->adminloginCheck();
		$table='personnel';
		$this->data['memberdetails'] = $this->model_customer->getpersonalDetails($member_id);
		/*echo "<pre>";
		print_r($this->data['memberdetails']); die;*/ 
		$this->data['member_id'] = $member_id;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('name', ' Name', 'required');
		if (!$this->form_validation->run() == FALSE) {	
			$dataArray['name']          =$_POST['name'];
		    $dataArray['phonenumber']   = $_POST['phonenumber'];
			$dataArray['designation']   = $_POST['designation'];
			$dataArray['email']         = $_POST['email'];

              if (isset($_FILES['file'])) {

		                $files = $_FILES['file'];
		               /* echo "<pre>";
		                print_r($files);die;*/
						$_FILES['file']=array();
						/* echo "<pre>";
		                print_r($_FILES['file']);die;*/
						$_FILES['file']['name'] = str_replace(' ','_',$files['name']);
						$_FILES['file']['type'] = $files['type'];
						$_FILES['file']['tmp_name'] = $files['tmp_name'];
						$_FILES['file']['error'] = $files['error'];
						$_FILES['file']['size'] = $files['size'];
						$uploadPath = 'assets/dist/personnel_img';
						$config['upload_path'] = $uploadPath;
						$config['allowed_types'] = 'jpg|png|jpeg';
						$config['max_width']  = '13490';
				        $config['max_height']  = '4960';
						$this->load->library('upload', $config);
						$this->upload->initialize($config); 
                     /*  echo "<pre>";
		                print_r($_FILES['file']['error']);die;*/
                     if($_FILES['file']['error']!= 4 ) {
					if($this->upload->do_upload('file')){
						$fileData = $this->upload->data();

						 /* echo "<pre>";
		                 print_r($fileData);die;*/
						$dataArray['image'] = $fileData['file_name'];
					}
				}
		     } 

		  


		    $dataArray['role']          = $_POST['role'];
			$dataArray['status']        = $_POST['status'];
		    $dataArray['created_date']  = date('Y-m-d h:i:s');
			
			if($this->model_customer->updateRow($table,$dataArray,'id',$member_id)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Personal Details Successfully Updated.</div>');
               $rediredcturl = ADMIN_URL.'personnel/edit/'.$member_id; 
				redirect($rediredcturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to update Detail.</div>');
			}
		}
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	

	}
}