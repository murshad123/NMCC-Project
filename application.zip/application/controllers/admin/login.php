<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller {

	public function __construct() {
        parent::__construct();
        $this->load->model('admin/user');
    }

	public function index(){

		/*$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);*/
		$this->load->view('admin/login/index');
	}

	public function verify(){
		$error = 0;
        $this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		if (!$this->form_validation->run() == FALSE) {
            $username = $this->input->post('username');
			$password = $this->input->post('password');
			$user_info = $this->user->login($username,$password);
			if($user_info){
                $session = $user_info;
				$this->session->set_userdata('admin_logged_in', $session);
				$urll = BASE_URL.'admin/dashboard/'; 
				redirect( $urll ,'refresh');
		    }else{
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Email or Password Invalid</div>');			
				header('Location: ' . $_SERVER['HTTP_REFERER']);      
		    }	
		}
	}

	public function logout(){
		$this->session->sess_destroy();
		$logouturl = BASE_URL.'admin/login'; 
		redirect($logouturl,'index');

	}


	
	
}
