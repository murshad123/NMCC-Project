<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class news extends MY_Controller {

	public function __construct() {
           parent::__construct();
           $this->load->model('admin/customer_modal','model_customer');

    }
    
	public function  currentnews(){
		$this->adminloginCheck();
		$this->data['news'] = $this->model_customer->getCurrentNews();
		//$this->data['customers'] = array();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);

	}

	public function  pastnews(){
		$this->adminloginCheck();
		$this->data['news'] = $this->model_customer->pastgetnews();
		//$this->data['customers'] = array();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);

	}




	public function  add($type){
		
		
			/*	$this->data['states'] = $this->model_customer->getstates();
	           $this->data['country'] = $this->model_customer->getcountry();*/

	         $this->data['news_time'] = $type;
		
	           $this->adminloginCheck();

				if($this->input->post('submit'))
				{
                    $table='news';
					$totalFormData = array( 			
						'title'                 => $_POST['title'],
						'description'           => $_POST['description'],
						'added_by'              => $_POST['added_by'],
						'status'                => $_POST['status'],
						'created_date'          => date('Y-m-d h:i:s')
				
			);	

                if (isset($_FILES['file'])) {

		                $files = $_FILES['file'];
		              
						$_FILES['file']=array();
						 //echo "<pre>";
		                // print_r($_FILES['file']);die;
						$_FILES['file']['name'] = str_replace(' ','_',$files['name']);
						$_FILES['file']['type'] = $files['type'];
						$_FILES['file']['tmp_name'] = $files['tmp_name'];
						$_FILES['file']['error'] = $files['error'];
						$_FILES['file']['size'] = $files['size'];
						$uploadPath = 'assets/dist/news_img';
						$config['upload_path'] = $uploadPath;
						$config['allowed_types'] = 'jpg|png|jpeg';
						$config['max_width']  = '13490';
				        $config['max_height']  = '4960';
						$this->load->library('upload', $config);
						$this->upload->initialize($config); 
                      /* echo "<pre>";
		                print_r($_FILES['file']['error']);die;*/
                if($_FILES['file']['error']!= 4 ) {
					if($this->upload->do_upload('file')){
						$fileData = $this->upload->data();

						// echo "<pre>";
		    //             print_r($fileData);die;
						$totalFormData['image'] = $fileData['file_name'];
					}
				} 
			    
		    } 


				

				

				//echo "<pre>";
				//print_r($totalFormData); die;
			/*$totalFormData = array( 			
				'name'                  => $_POST['firstname'],
				'email'                 => $_POST['email'],
				'phonenumber'           => $_POST['phonenumber'],
				'affilication'          => $_POST['affilication'],
				'institution_name'      => $_POST['institution_name'],
				'institution_country'   => $_POST['institution_country'],
				'institution_state'     => $_POST['institution_state'],
				'institution_city'      => $_POST['institution_city'],
				'institution_zipcode'   => $_POST['institution_zipcode'],
				'institution_type'      => $_POST['institution_type'],
				'isolation_reason'      => $_POST['isolation_reason'],
				'journal_name'          => $_POST['journal_name'],
				'organisms_name'        => $_POST['organisms_name'],
				'organisms_address'     => $_POST['organisms_address'],
				'organisms_country'     => $_POST['organisms_country'],
				'organisms_state'       => $_POST['organisms_state'],
				'organisms_city'        => $_POST['organisms_city'],
				'biological_importance' => $_POST['biological_importance'],
				'isolation_date	'       => date('Y-m-d h:i:s'),
				'isolation_method'      => $_POST['isolation_method'],
				'depository'            => $_POST['depository'],
			);*/
		
            // print_r($totalFormData);die;			
			if($member_result = $this->model_customer->insertdata($table,$totalFormData)){

				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">News Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/news';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add News.</div>');
				$redirecturl = ADMIN_URL.'/news';
				redirect($redirecturl,'refresh');
			}
		
	}
		// $this->data['states'] = $this->model_customer->getstates();
	    // $this->data['country'] = $this->model_customer->getcountry();

		// echo "<pre>";
         // print_r($this->data['states']);die;
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	

		
	}

	public function  view($customer_id){
		$this->adminloginCheck();
		$this->data['customers'] = $this->model_customer->getcustomersdetails($customer_id);
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function updateStatus($status,$id){
		$this->adminloginCheck();
		if($status == 'deactive'){
           $statusnew = '0';
		}else{
           $statusnew = '1';
		}

        $this->db->where('news.id', $id);
        $this->db->update('news', array('status' => $statusnew));
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable"> status successfully Updated.</div>');
        redirect($_SERVER['HTTP_REFERER'],'refresh');
    }

    public function delete($customer_id){
		$this->adminloginCheck();
	    if($this->model_customer->deleteNewsDetails($customer_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">News Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}

  	public function  edit($member_id){
  		//echo $member_id; die;
		$this->adminloginCheck();
		$table='news';
		$this->data['memberdetails'] = $this->model_customer->getNewsDetails($member_id);
		$this->data['member_id'] = $member_id;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('title', 'Title Name', 'required');
		if (!$this->form_validation->run() == FALSE) {	
			$dataArray['title'] =$_POST['title'];
		    $dataArray['description'] = $_POST['description'];
			$dataArray['added_by']  = $_POST['added_by'];
			$dataArray['status'] = $_POST['status'];
		    $dataArray['created_date']  = date('Y-m-d h:i:s');
			
			if($this->model_customer->updateRow($table,$dataArray,'id',$member_id)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">News Successfully Updated.</div>');
               $rediredcturl = ADMIN_URL.'news/edit/'.$member_id; 
				redirect($rediredcturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to update News.</div>');
			}
		}
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	

	}
}