<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Members extends MY_Controller {

	public function __construct() {
           parent::__construct();
           $this->load->model('admin/customer_modal','model_customer');
           $this->adminloginCheck();

    }
    
	public function  index(){
		$this->data['customers'] = $this->model_customer->getmembers();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);

	}


	public function  add(){
        if($this->input->post('submit'))
		{
			$table='user_register';
            $totalFormData = array( 			
				'first_name'            => $_POST['firstname'],
				'last_name'             => $_POST['lastname'],
				'username'              => $_POST['username'],
				'email'                 => $_POST['email'],
				'phonenumber'           => $_POST['phonenumber'],
				'password'              => $_POST['password'],
				'created_date'          => date('Y-m-d h:i:s'),
				'status'                => $_POST['status']
				
			);	
					
			if($this->model_customer->insertdata($table,$totalFormData)){
                $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Member Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'/members';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add member.</div>');
				$redirecturl = ADMIN_URL.'/members';
				redirect($redirecturl,'refresh');
			}
		
	}
		
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	

		
	}

	public function  view($customer_id){
		$this->adminloginCheck();
		$this->data['customers'] = $this->model_customer->getcustomersdetails($customer_id);
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function updateStatus($status,$id){
		$this->adminloginCheck();
		if($status == 'deactive'){
           $statusnew = '0';
		}else{
           $statusnew = '1';
		}

        $this->db->where('user_register.id', $id);
        $this->db->update('user_register', array('status' => $statusnew));
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable"> status successfully Updated.</div>');
        redirect($_SERVER['HTTP_REFERER'],'refresh');
    }

    public function delete($member_id){
		$this->adminloginCheck();
	    if($this->model_customer->deleteCustomers($member_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Member Deleted Successfully.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}

  	public function  edit($member_id){
  		//echo $member_id; die;
		$this->adminloginCheck();
		$table='user_register';
		$this->data['memberdetails'] = $this->model_customer->getmeberetails($member_id);
		$this->data['member_id'] = $member_id;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('firstname', 'First Name', 'required');
		if (!$this->form_validation->run() == FALSE) {	
			$dataArray['first_name'] =$_POST['firstname'];
		    $dataArray['last_name'] = $_POST['lastname'];
			$dataArray['username']  = $_POST['username'];
			$dataArray['email']   = $_POST['email'];
		    $dataArray['phonenumber']  = $_POST['phonenumber'];
			//$dataArray['password']  =$_POST['password'];
		    $dataArray['created_date']  = date('Y-m-d h:i:s');
			$dataArray['status'] = $_POST['status'];
			if($this->model_customer->updateRow($table,$dataArray,'id',$member_id)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Member Successfully Updated.</div>');
               $rediredcturl = ADMIN_URL.'members/edit/'.$member_id; 
				redirect($rediredcturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to update Member.</div>');
			}
		}
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	

	}
}