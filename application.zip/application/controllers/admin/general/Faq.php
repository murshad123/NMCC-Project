<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Faq extends MY_Controller {

	public function __construct() {
        parent::__construct();
        $this->load->model('admin/general_modal','cms');
        $this->load->model('common/common_model','common');
    }


	public function  index(){
        $this->adminloginCheck();
		$data['faqs'] = $this->cms->getFaqs();
		$this->load->admin(basename(__DIR__).'/'.$this->router->fetch_class().'/'.$this->router->fetch_method(),$data);

	}

	public function add(){
		 
		//$data11 = $this->session->userdata('admin_logged_in');

        $this->adminloginCheck();
        //$permission = $this->checkUrlpermission();
        //$this->data['permission']=$permission;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('title', 'Page_title', 'required');
		$this->form_validation->set_rules('content', 'Content', 'required');
		if (!$this->form_validation->run() == FALSE) {
			$data1['title'] = $this->input->post('title');
			$data1['content'] = $this->input->post('content');
			$data1['slug'] = strtolower(str_replace(' ', '-', $this->input->post('title')));
			$data1['status'] = 1;
			$data1['added_date'] = date('Y-m-d H:i:s');
			if($lastid = $this->common->addRow('faq',$data1)){
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Add faq successfully.</div>');
				redirect('admin/general/faq');

			}
		}	
		$data['faqs'] = '';
		$this->load->admin(basename(__DIR__).'/'.$this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);

	}

	public function faqStatus($status,$id){
      	  $this->loginCheck();
          $this->db->where('faq_id', $id);
          $this->db->update('faq', array('status' => ($status=='active'?$status=1:$status=0)));
          $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable"> Status successfully updated.</div>');
          redirect('admin/faq','refresh');

    }

    public function edit($id=0){
		
		$this->loginCheck();
		$permission = $this->checkUrlpermission();
        $this->data['permission']=$permission;
		$data = array();
		$this->data['faqs'] = $this->cms->getfaq($id);
		
		
	    $this->load->library('form_validation');
	    $this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
	    $this->form_validation->set_rules('title', 'Page_title', 'required');
	    $this->form_validation->set_rules('content', 'Content', 'required');
		if (!$this->form_validation->run() == FALSE) {
			$data1['title'] = $this->input->post('title');
			$data1['content'] = $this->input->post('content');
			$data1['status'] = 1;
			$data1['added_date'] = date('Y-m-d H:i:s');
			if($lastid = $this->cms->updateRow('faq',$data1,'faq_id',$id)){
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Faq successfully updated.</div>');
				redirect('admin/faq');

			}
		}
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
		
	   
	}	
	






	




















}
