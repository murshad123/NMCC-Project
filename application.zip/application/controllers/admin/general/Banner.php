<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banner extends MY_Controller {

	public function __construct() {
        parent::__construct();
        $this->load->model('admin/general_modal','cms');
    }
    
	public function  index(){
        $this->adminloginCheck();
	    $data['banners']= $this->cms->getBanners();;
		$this->load->admin(basename(__DIR__).'/'.$this->router->fetch_class().'/'.$this->router->fetch_method(),$data);
	}

	public function add(){
        $this->adminloginCheck();
/*        $permission = $this->checkUrlpermission();
        $this->data['permission']=$permission;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('title', 'Page_title', 'required');
		$this->form_validation->set_rules('content', 'Content', 'required');
		if (!$this->form_validation->run() == FALSE) {
			$data1['title'] = $this->input->post('title');
			$data1['meta_title'] = $this->input->post('meta_title');
			$data1['meta_keyword'] = $this->input->post('meta_keyword');
			$data1['meta_description'] = $this->input->post('meta_desc');
			$data1['slug']  = str_replace(' ', '-', $this->input->post('title'));
			$data1['content'] = $this->input->post('content');
			$data1['status'] = 1;
			$data1['created_by'] = date('Y-m-d H:i:s');
			if (isset($_FILES['image'])) {
                $files = $_FILES['image'];
				$_FILES['image']=array();
				$_FILES['image']['name'] = str_replace(' ','_',$files['name']);
				$_FILES['image']['type'] = $files['type'];
				$_FILES['image']['tmp_name'] = $files['tmp_name'];
				$_FILES['image']['error'] = $files['error'];
				$_FILES['image']['size'] = $files['size'];
				$uploadPath = 'assets/dist/img/cms';
				$config['upload_path'] = $uploadPath;
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$config['max_size']       = '30000';
				$this->load->library('upload', $config);
				$this->upload->initialize($config); 
                if($_FILES['image']['error']!= 4 ) {
					if($this->upload->do_upload('image')){
						$fileData = $this->upload->data();
						$data1['banner_image'] = $fileData['file_name'];
					}
				}	 
			    
		    } 
			if($lastid = $this->cms->addRow('cms_pages',$data1)){
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Add cms page successfully.</div>');
				redirect('admin/cms');

			}
		}	*/
		$data['addtion'] = '';
		$this->load->admin(basename(__DIR__).'/'.$this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);

	}

	public function cmsStatus($data){
		  $status = $data[0];
  		  $id = $data[1];
      	  $this->loginCheck();
          $this->db->where('page_id', $id);
          $this->db->update('cms_pages', array('status' => ($status=='active'?$status=1:$status=0)));
          $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable"> Status successfully updated.</div>');
          redirect('admin/cms','refresh');

    }

    public function edit($id=0){
		
		$this->loginCheck();
		$permission = $this->checkUrlpermission();
		
        $this->data['permission']=$permission;
		$data = array();
		$this->data['pages'] = $this->cms->getcmspage($id);
		
		
		   $this->load->library('form_validation');
		   $this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		   $this->form_validation->set_rules('title', 'Page_title', 'required');
		   $this->form_validation->set_rules('content', 'Content', 'required');
		  
           if (!$this->form_validation->run() == FALSE) {
           	$data1['title'] = $this->input->post('title');
			$data1['meta_title'] = $this->input->post('meta_title');
			$data1['meta_keyword'] = $this->input->post('meta_keyword');
			$data1['meta_description'] = $this->input->post('meta_desc');
			//$data1['slug']  = str_replace(' ', '-', $this->input->post('title'));
			$data1['content'] = $this->input->post('content');
			$data1['status'] = 1;
			$data1['created_by'] = date('Y-m-d H:i:s');
			if (isset($_FILES['image'])) {
                $files = $_FILES['image'];
				$_FILES['image']=array();
				$_FILES['image']['name'] = str_replace(' ','_',$files['name']);
				$_FILES['image']['type'] = $files['type'];
				$_FILES['image']['tmp_name'] = $files['tmp_name'];
				$_FILES['image']['error'] = $files['error'];
				$_FILES['image']['size'] = $files['size'];
				$uploadPath = 'assets/dist/img/cms';
				$config['upload_path'] = $uploadPath;
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$config['max_size']       = '30000';
				$this->load->library('upload', $config);
				$this->upload->initialize($config); 
                if($_FILES['image']['error']!= 4 ) {
					if($this->upload->do_upload('image')){
						$fileData = $this->upload->data();
						$data1['banner_image'] = $fileData['file_name'];
					}
				}	 
			    
		    } 
			if($lastid = $this->cms->updateRow('cms_pages',$data1,'page_id',$id)){
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Cms page successfully updated.</div>');
				redirect('admin/cms');

			}
		}
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
		
	   
	}	
	






	




















}
