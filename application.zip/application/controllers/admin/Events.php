<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Events extends MY_Controller {

	public function __construct() {
           parent::__construct();
           $this->load->model('admin/general_modal','model_general');
    }
    
	public function currentevents(){
		$this->adminloginCheck();
		$this->data['events'] = $this->model_general->getCurrentEvents();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function pastevents(){
		$this->adminloginCheck();
		$this->data['events'] = $this->model_general->getPastEvents();
		// echo "<pre>";
		// print_r($this->model_general->getPastEvents()); die;
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function add($type)
	{
		$this->adminloginCheck();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('event_name', 'Event Name', 'required');
		$this->form_validation->set_rules('presenter', 'Presenter', 'required');
		$this->form_validation->set_rules('info', 'Fee', 'required');
		$this->form_validation->set_rules('start_date', 'Start Date', 'required');
		$this->form_validation->set_rules('entry_time', 'Entry Time', 'required');
		
		if (!$this->form_validation->run() == FALSE) {
		    $table = 'events';
			$dataArray['event_name'] = $_POST['event_name'];
			$dataArray['event_type'] = $_POST['event_type'];
			$dataArray['info'] = $_POST['info'];
			$dataArray['presenter'] = $_POST['presenter'];
			$dataArray['presenter_designation'] = $_POST['presenter_designation'];
			$dataArray['duration'] = $_POST['duration'];
			$dataArray['duration_period'] = $_POST['duration_period'];
			$dataArray['entry_time'] = $_POST['entry_time'];
			$dataArray['start_date'] = date('Y-m-d',strtotime($_POST['start_date']));
			
			$dataArray['end_date'] = date('Y-m-d',strtotime($_POST['start_date']));
			$dataArray['event_year'] = date('Y',strtotime($_POST['start_date']));
			$dataArray['description'] = $_POST['description'];
			$dataArray['event_files'] = '';
			$dataArray['status'] = $_POST['status'];
			$dataArray['created_date'] = date('Y-m-d h:i:s');
			if (isset($_FILES['presenter_image'])) {
                $files = $_FILES['presenter_image'];
				$_FILES['presenter_image']=array();
				$_FILES['presenter_image']['name'] = str_replace(' ','_',$files['name']);
				$_FILES['presenter_image']['type'] = $files['type'];
				$_FILES['presenter_image']['tmp_name'] = $files['tmp_name'];
				$_FILES['presenter_image']['error'] = $files['error'];
				$_FILES['presenter_image']['size'] = $files['size'];
				$uploadPath = 'assets/dist/pre_img';
				$config['upload_path'] = $uploadPath;
				$config['allowed_types'] = 'jpg|png|jpeg';
				$config['max_width']  = '13490';
		        $config['max_height']  = '4960';
				$this->load->library('upload', $config);
				$this->upload->initialize($config); 

                if($_FILES['presenter_image']['error']!= 4 ) {
					if($this->upload->do_upload('presenter_image')){
						$fileData = $this->upload->data();
						$dataArray['presenter_image'] = $fileData['file_name'];
					}
				} 
			    
		    } 
		    if (isset($_FILES['event_files'])) {
                $files = $_FILES['event_files'];
				$_FILES['event_files']=array();
				$_FILES['event_files']['name'] = str_replace(' ','_',$files['name']);
				$_FILES['event_files']['type'] = $files['type'];
				$_FILES['event_files']['tmp_name'] = $files['tmp_name'];
				$_FILES['event_files']['error'] = $files['error'];
				$_FILES['event_files']['size'] = $files['size'];
				$uploadPath = 'assets/dist/pre_img';
				$config['upload_path'] = $uploadPath;
				$config['allowed_types'] = 'pdf';
				/*$config['max_width']  = '13490';
		        $config['max_height']  = '4960';*/
				$this->load->library('upload', $config);
				$this->upload->initialize($config); 

                if($_FILES['event_files']['error']!= 4 ) {
					if($this->upload->do_upload('event_files')){
						$fileData = $this->upload->data();
						$dataArray['event_files'] = $fileData['file_name'];
					}
				} 
			    
		    } 
            // echo "<pre>";
            // print_r($dataArray); die;
			if($this->model_general->addRow($table,$dataArray)){
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Event Successfully Added.</div>');
                if(date('Y',strtotime($_POST['start_date'])) >= date('Y')){
                	$redirecturl = ADMIN_URL.'events/currentevents'; 
                }else if(date('Y',strtotime($_POST['start_date'])) < date('Y')){
                    $redirecturl = ADMIN_URL.'events/pastevents'; 
                }
				
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add Event.</div>');
			}
		}
		$this->data['event_time'] = $type;
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function updateStatus($status,$id){
		$this->adminloginCheck();
		if($status == 'deactive'){
           $statusnew = '0';
		}else{
           $statusnew = '1';
		}

        $this->db->where('events.id', $id);
        $this->db->update('events', array('status' => $statusnew));
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable"> status successfully Updated.</div>');
        redirect($_SERVER['HTTP_REFERER'],'refresh');
    }

     public function delete($event_id){
		$this->adminloginCheck();
	    if($this->model_general->deleteRow('events','id',$event_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Events Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}

  	public function  edit($event_id){
		$this->adminloginCheck();
		$this->data['eventdetails'] = $this->model_general->geteventdetails($event_id);
		$this->data['event_id'] = $event_id;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('event_name', 'Event Name', 'required');
		$this->form_validation->set_rules('presenter', 'Presenter', 'required');
		$this->form_validation->set_rules('info', 'Fee', 'required');
		$this->form_validation->set_rules('start_date', 'Start Date', 'required');
		
		if (!$this->form_validation->run() == FALSE) {
			$table = 'events';
			$dataArray['event_name'] = $_POST['event_name'];
			$dataArray['event_type'] = $_POST['event_type'];
			$dataArray['info'] = $_POST['info'];
			$dataArray['presenter'] = $_POST['presenter'];
			$dataArray['duration'] = $_POST['duration'];
			$dataArray['duration_period'] = $_POST['duration_period'];
			$dataArray['entry_time'] = $_POST['entry_time'];
			$dataArray['presenter_designation'] = $_POST['presenter_designation'];
            $dataArray['start_date'] = date('Y-m-d',strtotime($_POST['start_date']));
			$dataArray['end_date'] = date('Y-m-d',strtotime($_POST['start_date']));
            $dataArray['event_year'] =  date('Y',strtotime($_POST['start_date']));
			$dataArray['description'] = $_POST['description'];
			$dataArray['event_files'] = '';
			$dataArray['status'] = $_POST['status'];
			$dataArray['created_date'] = date('Y-m-d h:i:s');
			if (isset($_FILES['presenter_image'])) {
                $files = $_FILES['presenter_image'];
				$_FILES['presenter_image']=array();
				$_FILES['presenter_image']['name'] = str_replace(' ','_',$files['name']);
				$_FILES['presenter_image']['type'] = $files['type'];
				$_FILES['presenter_image']['tmp_name'] = $files['tmp_name'];
				$_FILES['presenter_image']['error'] = $files['error'];
				$_FILES['presenter_image']['size'] = $files['size'];
				$uploadPath = 'assets/dist/pre_img';
				$config['upload_path'] = $uploadPath;
				$config['allowed_types'] = 'jpg|png|jpeg';
				$config['max_width']  = '13490';
		        $config['max_height']  = '4960';
				$this->load->library('upload', $config);
				$this->upload->initialize($config); 

                if($_FILES['presenter_image']['error']!= 4 ) {
					if($this->upload->do_upload('presenter_image')){
						$fileData = $this->upload->data();
						$dataArray['presenter_image'] = $fileData['file_name'];
					}
				} 
			    
		    } 

		    if (isset($_FILES['event_files'])) {
                $files = $_FILES['event_files'];
				$_FILES['event_files']=array();
				$_FILES['event_files']['name'] = str_replace(' ','_',$files['name']);
				$_FILES['event_files']['type'] = $files['type'];
				$_FILES['event_files']['tmp_name'] = $files['tmp_name'];
				$_FILES['event_files']['error'] = $files['error'];
				$_FILES['event_files']['size'] = $files['size'];
				$uploadPath = 'assets/dist/pre_img';
				$config['upload_path'] = $uploadPath;
				$config['allowed_types'] = 'pdf';
				/*$config['max_width']  = '13490';
		        $config['max_height']  = '4960';*/
				$this->load->library('upload', $config);
				$this->upload->initialize($config); 

                if($_FILES['event_files']['error']!= 4 ) {
					if($this->upload->do_upload('event_files')){
						$fileData = $this->upload->data();
						$dataArray['event_files'] = $fileData['file_name'];
					}
				} 
			    
		    } 

		  //  echo "<pre>";
		   // print_r($dataArray); die;

			if($this->model_general->updateRow($table,$dataArray,'id',$event_id)){
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Event successfully updated.</div>');
				$redirecturl = ADMIN_URL.'events/edit/'.$event_id;
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to update Events.</div>');
			}
		}
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	
	
		



	

}