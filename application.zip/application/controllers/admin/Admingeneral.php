<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admingeneral extends CI_Controller {

	
        public function __construct() {
           parent::__construct();
           $this->load->model('admin/general_modal','model_general');
       }
   
  
	public function inquiry()
	{
		$this->data['inquiry'] = $this->model_general->getinquiries();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}


	public function delete($enquiry_id){
	    if($this->model_general->deleteRow('inquiry','id',$enquiry_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Enquiry Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}



  	public function  edit($inquiry_id){
        $table='inquiry';
		$this->data['inquiry'] = $this->model_general->getinquiriesDetails($inquiry_id);
		$this->data['inquiry_id'] = $inquiry_id;
		// echo "<pre>";
		// print_r($this->model_general->getinquiriesDetails($inquiry_id));  die;

		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('name', ' Enter Name', 'required');
		$this->form_validation->set_rules('email', 'Enter Email', 'required');
        if(!$this->form_validation->run() == FALSE) {
			
			$totalFormData = array( 			
				'name'                  => $_POST['name'],
				'email'               => $_POST['email'],				
				'subject'                   => $_POST['subject'],
				'message'             => $_POST['message']
			);
			// echo "<pre>";
		 //    print_r($totalFormData); die;
			if($this->model_general->updateRow($table,$totalFormData,'id',$inquiry_id)){
               $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">inquiry Successfully Updated.</div>');
               $rediredcturl = ADMIN_URL.'admingeneral/edit/'.$inquiry_id; 
				redirect($rediredcturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to update inquiry.</div>');
			}
		}
					
       $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	
	}

	
}
