<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Regions extends MY_Controller {

	public function __construct() {
           parent::__construct();
           $this->load->model('admin/general_modal','model_general');
           $this->adminloginCheck();
    }
    
    public function otherregion()
	{	
		$this->data['continents'] = $this->model_general->getcontinents();
		/*echo "<pre>";
		print_r($this->data); die;*/
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function countries($continents_code)
	{
		$this->data['continents_details'] = $this->model_general->getcontinentsdetailsbyCode($continents_code);

		
		$this->data['countries'] = $this->model_general->getcountries($continents_code);

		/*echo "<pre>";
		print_r($this->data); die;*/

		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function states($continents_code,$country_id)
	{
		$this->data['continents_details'] = $this->model_general->getcontinentsdetailsbyCode($continents_code);
		$this->data['country_details'] = $this->model_general->getcontrydetails($country_id);
		$this->data['states'] = $this->model_general->getcountrystate($country_id);
		// echo "<pre>";
		// print_r($this->data) ; die;
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}


	public function nigeria()
	{
		$this->adminloginCheck();
		$this->data['nigeriaStates'] = $this->model_general->getnigeriastates();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function nigeriaStatesLga($state_id)
	{
		$this->adminloginCheck();
		$this->data['statename'] = $this->model_general->getStateName($state_id);
		//echo "<pre>"; print_r($this->data);  die; 
		$this->data['statesLga'] = $this->model_general->getnigeriastateslga($state_id);
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function nigeriancommunity()
	{
		$this->adminloginCheck();
		$this->data['community'] = $this->model_general->getcommunities();
		//echo "<pre>";
		//print_r($this->data['community']); die; 
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function community()
	{
		$this->adminloginCheck();
		$this->data['community'] = $this->model_general->getallcommunity();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function addcommunity($state_id,$lga_id)
	{
		
		$this->data['regiondetails'] = $this->model_general->getregiondetailsbystateid($state_id);
		$this->data['lga_id'] = $lga_id;
		//echo "<pre>";
		//print_r($this->data['regiondetails']); die;
		$this->data['community'] = $this->model_general->getcommunitybystates($state_id);
		
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('community_name', 'Community Name', 'required');
		//$this->form_validation->set_rules('state', 'State', 'required');
		//$this->form_validation->set_rules('country', 'Country', 'required');
		$dataArray = array(
                           'community_name' => $this->input->post('community_name'),
                           'state_id' => $this->data['regiondetails']['zone_id'],
                           'city' => $lga_id,
                           'country_id' => $this->data['regiondetails']['country_id'],
                           'status' => $this->input->post('status'),
                           'created_date' => date('Y-m-d h:i:s')
				          );
		//echo "<pre>";
		//print_r($this->data['regiondetails']); die;
		if (!$this->form_validation->run() == FALSE) {
			if($this->model_general->addRow('community',$dataArray)){
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Community Successfully Added.</div>');
					$redirect_url = ADMIN_URL.'regions/addcommunity/'.$state_id.'/'.$lga_id;
					redirect($redirect_url,'refresh');
			}else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add community.</div>');
			}
		}
		 // $this->data['state'] = $this->model_general->getnigeriastates($state_id);
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}

	public function addnigeriancommunity()
	{
		
		if($_POST){
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
			$this->form_validation->set_rules('community_name', 'Community Name', 'required');
			$this->form_validation->set_rules('state', 'State', 'required');
			$this->form_validation->set_rules('country', 'Country', 'required');
			//$this->form_validation->set_rules('lga', 'LGA', 'required');
			//$this->form_validation->set_rules('description', 'Description', 'required');
			$dataArray = array(
                               'community_name' => $this->input->post('community_name'),
                               'state_id' => $this->input->post('state'),
                               'city' => $this->input->post('lga'),
                               'country_id' => $this->input->post('country'),
                               'status' => $this->input->post('status'),
                               'created_date' => date('Y-m-d h:i:s')
				              );
			if (!$this->form_validation->run() == FALSE) {
				
				if($this->model_general->addRow('community',$dataArray)){
					$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Community Successfully Added.</div>');
					$redirect_url = ADMIN_URL.'regions/nigeriancommunity';
					redirect($redirect_url,'refresh');
				}
				else {
					//echo "not added"; die;
					$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add community.</div>');
				}
			}
		}
		$this->data['countries'] = $this->model_general->getactivecountries();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	

	public function getstatelga(){
		$this->adminloginCheck();
		$state_id = $this->input->post('state_id');
		if($state_id!=''){
			$this->data['lga'] = $this->model_general->getnigeriastateslga($state_id);

            $this->load->view('admin/regions/'.$this->router->fetch_method(),$this->data);
		}
	}

	public function getajaxcountrystate()
	{
		$country_id = $this->input->post('country_id');
		if($country_id!=''){
			$this->data['states'] = $this->model_general->getcountrystate($country_id);
			
            $this->load->view('admin/regions/'.$this->router->fetch_method(),$this->data);
		}
	}

	public function updateCommunityStatus($status,$id)
	{
		if($status == 'deactive'){
           $statusnew = '0';
		}else{
           $statusnew = '1';
		}

        $this->db->where('community.id', $id);
        $this->db->update('community', array('status' => $statusnew));
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable"> Status successfully Updated.</div>');
        redirect($_SERVER['HTTP_REFERER'],'refresh');
	}

	public function deleteCommunity($community_id){
	    if($this->model_general->deleteRow('community','id',$community_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Community Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}

  	public function editnigeriancommunity($community_id)
	{
		
		$this->data['community_detail'] = $this->model_general->getCommunityDetails($community_id);
		$this->data['community_id'] = $community_id;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('community_name', 'Community Name', 'required');
		$this->form_validation->set_rules('state', 'State', 'required');
		$this->form_validation->set_rules('country', 'Country', 'required');
		$dataArray = array(
	                       'community_name' => $this->input->post('community_name'),
	                       'state_id' => $this->input->post('state'),
	                       'city' => $this->input->post('lga'),
	                       'country_id' => $this->input->post('country'),
	                       'status' => $this->input->post('status'),
	                       'created_date' => date('Y-m-d h:i:s')
				        );
		if (!$this->form_validation->run() == FALSE) {
			if($this->model_general->updateRow('community',$dataArray,'id',$community_id)){
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Community Successfully updated.</div>');
					$redirect_url = ADMIN_URL.'regions/editnigeriancommunity/'.$community_id;
					redirect($redirect_url,'refresh');
			}else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to update community.</div>');
			}
		}
		
		$this->data['countries'] = $this->model_general->getactivecountries();
		$this->data['states'] = $this->model_general->getcountrystate($this->data['community_detail']['country_id']);

		//echo "<pre>";
		//print_r($this->data); die;
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}
	
// Murshid code

	public function addotherregion(){
		$this->adminloginCheck();
		
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('name', 'name', 'required');

		if (!$this->form_validation->run() == FALSE) {
			$table='continents';
			$totalFormData = array( 			
				'name'                   => $_POST['name'],
				'code'                   =>$_POST['code'],
				
			);

		    if($member_result = $this->model_general->addRow($table,$totalFormData)){

				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">continents Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'regions/otherregion';
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add Customer.</div>');
				$redirecturl = ADMIN_URL.'regions/otherregion';
				redirect($redirecturl,'refresh');
			}
		  
		}
	
		   $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}


	public function editotherregion($continents_id){
		$table='continents';
		$this->data['continents'] = $this->model_general->getcontinentsDetails($continents_id);
		$this->data['continents_id'] = $continents_id;
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('name', 'name', 'required');

		if (!$this->form_validation->run() == FALSE) {
			$table='continents';
			$totalFormData = array( 			
				'name'                   => $_POST['name'],
				'code'                   =>$_POST['code'],
				
			);
            if($this->model_general->updateRow($table,$totalFormData,'id',$continents_id)){

				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">continents Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'regions/editotherregion/'.$continents_id;
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add Continents.</div>');
				$redirecturl = ADMIN_URL.'regions/otherregion';
				redirect($redirecturl,'refresh');
			}
		  
		}
	
		   $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}


	 public function deleteotherregion($continents_id){
	    if($this->model_general->deleteRow('continents','id',$continents_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">continents Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}


  	public function addcountries($continent_code)
	{	
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('name', 'name', 'required');
        if (!$this->form_validation->run() == FALSE) {
			$table='country';
			$totalFormData = array( 			
				'name'                   => $_POST['name'],
				'continent_code'         => $continent_code,
				'status'                 => $_POST['status']
            );
             echo "<pre>";
            print_r($totalFormData); die;

		    if($member_result = $this->model_general->addRow($table,$totalFormData)){
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Country Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'regions/countries/'.$continent_code;
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add Countries.</div>');
			}
	}
    
    $this->data['continent_code'] = $continent_code;
	$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	

}
  


   public function deletecountry($country_id){
	    if($this->model_general->deleteRow('country','country_id',$country_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Country Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}


  	public function editeCountry($country_id){
		$table=' country';
		$this->data['country'] = $this->model_general->getCountryDetails($country_id);
		$this->data['country_id'] = $country_id;
        /* echo "<pre>";
		print_r($this->data); die;	*/	  		
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('name', 'name', 'required');

		if (!$this->form_validation->run() == FALSE) {
			$table='country';
			$totalFormData = array( 			
				'name'                   => $_POST['name'],
				//'continent_code'           =>$_POST['code'],
				 'status'                 => $_POST['status']
				
			);
			/*echo "<pre>";
             print_r($totalFormData);die;*/
		    if($member_result = $this->model_general->updateRow($table,$totalFormData,'country_id',$country_id)){

				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">country Successfully Updated.</div>');
				$redirecturl = ADMIN_URL.'regions/editeCountry/'.$country_id;
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add Country.</div>');
				$redirecturl = ADMIN_URL.'regions/editeCountry/'.$country_id;
				redirect($redirecturl,'refresh');
			}
		  
		}
	
		   $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function addstates($continent_code,$country_id){
		$this->adminloginCheck();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('name', 'name', 'required');
        if (!$this->form_validation->run() == FALSE) {
			$table='zone';
			$totalFormData = array( 
                            'country_id' => $country_id,
				            'name' => $_POST['name'],
				            'status'  => $_POST['status'],
                        );
		    if($member_result = $this->model_general->addRow($table,$totalFormData)){
                $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">states Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'regions/states/'.$continent_code.'/'.$country_id;
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add states.</div>');
				$redirecturl = ADMIN_URL.'regions/addstates/'.$continent_code.'/'.$country_id;
				redirect($redirecturl,'refresh');
			}
		  
		}
        $this->data['continent_code'] = $continent_code;
        $this->data['country_id'] = $country_id;
	    $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}


	public function editeStates($continent_code,$state_id){
		$this->adminloginCheck();
		
		$this->data['states'] = $this->model_general->editStateDetails($state_id);
		$this->data['state_id'] = $state_id;
		$this->data['continent_code'] = $continent_code;
		$this->data['country_id'] = $this->data['states']['country_id'];
		/*echo "<pre>";
		print_r($this->data); die;*/
			
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('name', 'name', 'required');

		if (!$this->form_validation->run() == FALSE) {
			$table='zone';
			$totalFormData = array( 
                                'country_id' => $this->data['country_id'],
				                'name' => $_POST['name'],
				                'status'  => $_POST['status']

				
			);

		/*	echo "<pre>";
		print_r($totalFormData); die;*/

		    if($this->model_general->updateRow($table,$totalFormData,'zone_id',$state_id)){

				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">state Successfully Added.</div>');
				$redirecturl = ADMIN_URL.'regions/editeStates/'.$continent_code.'/'.$state_id;
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add state.</div>');
				$redirecturl = ADMIN_URL.'regions/editeStates/'.$continent_code.'/'.$state_id;
				redirect($redirecturl,'refresh');
			}
		  
		}
	
		   $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}



	public function deleteState($state_id){
		$this->adminloginCheck();
	    if($this->model_general->deleteRow('zone','zone_id',$state_id)){
	    	
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">State Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}
  	

  	public function lga($continents_code,$country_id,$state_id)
	{
		$this->data['continents_details'] = $this->model_general->getcontinentsdetailsbyCode($continents_code);
		$this->data['country_details'] = $this->model_general->getcontrydetails($country_id);
		$this->data['states'] = $this->model_general->getStateDeatils($state_id);
		$this->data['state_id'] = $state_id;
		$this->data['lga'] = $this->model_general->getLga($state_id);
		
       /* echo "<pre>";
	    print_r($this->data); die;
*/
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}
		


       public function addlga($continent_code,$country_id,$state_id){
		$this->adminloginCheck();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('name', 'name', 'required');
	
        if (!$this->form_validation->run() == FALSE) {
			$table='lga';
			$totalFormData = array( 
                            'name' => $_POST['name'],
				            'state_id' => $state_id,
				            'status'  => $_POST['status'],
                        );
			/*echo "<pre>";
			print_r($totalFormData);  die;*/
		    if($member_result = $this->model_general->addRow($table,$totalFormData)){
                $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">lga Successfully Added.</div>');
				$redirecturl =ADMIN_URL.'regions/lga/'.$continent_code.'/'.$country_id.'/'.$state_id;
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add states.</div>');
				$redirecturl = ADMIN_URL.'regions/addlga/'.$continent_code.'/'.$country_id.'/'.$state_id;
				redirect($redirecturl,'refresh');
			}
		  
		}
        $this->data['continent_code'] = $continent_code;
        $this->data['country_id'] = $country_id;
        $this->data['state_id'] = $state_id;
	    $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}


	public function editlga($continent_code,$country_id,$state_id){
		$this->adminloginCheck();
		$this->data['lga'] = $this->model_general->editlgaDetails($state_id);
		$this->data['state_id'] = $state_id;
		$this->data['continent_code'] = $continent_code;
		$this->data['lga_id'] = $this->data['lga']['state_id'];
		// echo "<pre>";
		// print_r($this->data['state_id']); die;



		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('name', 'name', 'required');
	
        if (!$this->form_validation->run() == FALSE) {
			$table='lga';
			$totalFormData = array( 
                            'name' => $_POST['name'],
				            'state_id' => $this->data['lga_id'],
				            'status'  => $_POST['status'],
                        );
			// echo "<pre>";
			// print_r($totalFormData);  die;
		    if($member_result = $this->model_general->updateRow($table,$totalFormData,'id',$state_id)){
                $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">lga Successfully Added.</div>');
				$redirecturl =ADMIN_URL.'regions/editlga/'.$continent_code.'/'.$country_id.'/'.$state_id;
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add states.</div>');
				$redirecturl = ADMIN_URL.'regions/addlga/'.$continent_code.'/'.$country_id.'/'.$state_id;
				redirect($redirecturl,'refresh');
			}
		  
		}

        $this->data['continent_code'] = $continent_code;
        $this->data['country_id'] = $country_id;
        $this->data['state_id'] = $state_id;
	    $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}


	public function deletelga($state_id){
		$this->adminloginCheck();
	    if($this->model_general->deleteRow('lga','id',$state_id)){
	    	
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Lga Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}




  	public function editcommunity($state_id){
		$this->adminloginCheck();
		$this->data['Community'] = $this->model_general->editCommunityDetails($state_id);
		/*$this->data['state_id'] = $state_id;
		$this->data['country_id'] = $country_id;
		$this->data['continent_code'] = $continent_code;
		$this->data['city_id'] = $this->data['community']['city'];
		echo "<pre>";
		print_r($this->model_general->editCommunityDetails($state_id)); die;*/



		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('community_name', 'community_name', 'required');
	
        if (!$this->form_validation->run() == FALSE) {
			$table='community';
			$totalFormData = array( 
                            'community_name' => $_POST['community_name'],
				            // 'state_id' => $this->data['lga_id'],
				            'status'  => $_POST['status'],
                        );
			/*echo "<pre>";
			print_r($totalFormData);  die;*/
		    if($member_result = $this->model_general->updateRow($table,$totalFormData,'id',$state_id)){
                $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">community Successfully Added.</div>');
				$redirecturl =ADMIN_URL.'regions/editcommunity/'.$state_id;
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add community.</div>');
				$redirecturl = ADMIN_URL.'regions/addcommunity/'.$continent_code.'/'.$country_id.'/'.$state_id;
				redirect($redirecturl,'refresh');
			}
		  
		}

        // $this->data['continent_code'] = $continent_code;
        // $this->data['country_id'] = $country_id;
        // $this->data['state_id'] = $state_id;
	    $this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);		
	}

	

}