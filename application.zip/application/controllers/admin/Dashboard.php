<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

	public function __construct() {
           parent::__construct();
           $this->load->model('admin/general_modal','model_general');
    }
    
	public function  index(){
		$this->adminloginCheck();
		$this->data['membersCount'] = $this->model_general->getTotalMembers();
		$this->data['autoresCount'] = $this->model_general->getTotalAutores();
		$this->data['requestCategory'] = '';
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}
	
		



	

}