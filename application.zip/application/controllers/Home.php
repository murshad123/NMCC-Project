<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	
	public function index()
	{
		$this->data['stores'] = array();
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}
}
