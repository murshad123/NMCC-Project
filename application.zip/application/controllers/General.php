<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class General extends My_Controller {

	
        public function __construct() {
           parent::__construct();
           $this->load->model('generals','model_general');
       }
   
  
	public function index()
	{
		$this->data['stores'] = array();
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function seminars()
	{
		
		$this->data['currentseminars'] = $this->model_general->getcurrenetseminar();
		$this->data['previousseminars'] = $this->model_general->getpreviousseminar();
		
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function workshop()
	{
		
		$this->data['currentworkshop'] = $this->model_general->getcurrentworkshop();
		$this->data['previousworkshop'] = $this->model_general->getpreviousworkshop();
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function eventdetails($event_id)
	{
		$this->data['eventdetails'] = $this->model_general->geteventdetails($event_id);
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}

	public function news()
	{
		$this->data['news'] = $this->model_general->getactivenews();
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function newsdetails($newsid)
	{
		$this->data['newsdetail'] = $this->model_general->getnewsdetail($newsid);
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function contactus()
	{
		
       // echo "<pre>";
        //print_r($_POST);die; 
		//if($_POST){
			$this->load->library('form_validation');
            $this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
            $this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('subject', 'Subject', 'required');
            $this->form_validation->set_rules('message', 'Comment', 'required');
            if (!$this->form_validation->run() == FALSE) {
            	$data = array();
                $data['name'] =  $this->input->post('name');
                $data['email'] =  $this->input->post('email');
                $data['message'] =  $this->input->post('message');
                $data['subject'] =  $this->input->post('subject');
                $data['created_date'] =  date('Y-m-d H:i:s');
                if($this->model_general->addRow('inquiry',$data)){
					$subject = " Message from ".$data['name'];
					/*$data1['message'] = "Dear Admin <br/> ".$data['message'].' <br/> Thank You';*/
					//$msg = $this->load->view('email/contactUs',$data1,true);
					$msg = "Dear Admin <br/> ".$data['message'].' <br/> Thank You';
                    //$this->sendMail(ADMIN_EMAIL,$subject,$msg);
					$this->session->set_flashdata('response', "<div class='alert alert-info alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Thanks for contact us.</div>");
					$redirecturl = BASE_URL.'/general/contactus';
					redirect($redirecturl, 'refresh');
                } else {
                   	$this->session->set_flashdata('response', "<div class='alert alert-info alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Something Errors.</div>");
					$redirecturl = BASE_URL.'/general/contactus';
					redirect($redirecturl, 'refresh');
                }
            }
            $this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method());	

        //}	
       
	}

	public function sendinquiry()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('event_name', 'Event Name', 'required');
		$this->form_validation->set_rules('presenter', 'Presenter', 'required');
		$this->form_validation->set_rules('info', 'Short Info', 'required');
		$this->form_validation->set_rules('start_date', 'Start Date', 'required');
		$this->form_validation->set_rules('end_date', 'End Date', 'required');
		if (!$this->form_validation->run() == FALSE) {
			$table = 'events';
			$dataArray['event_name'] = $_POST['event_name'];
			$dataArray['event_type'] = $_POST['event_type'];
			$dataArray['info'] = $_POST['info'];
			$dataArray['presenter'] = $_POST['presenter'];
			$dataArray['presenter_designation'] = $_POST['presenter_designation'];
			$dataArray['presenter_image'] = '';
			$dataArray['start_date'] = $_POST['start_date'];
			$dataArray['end_date'] = $_POST['end_date'];
			$dataArray['event_year'] = $_POST['end_date'];
			$dataArray['description'] = $_POST['description'];
			$dataArray['event_files'] = '';
			$dataArray['status'] = $_POST['status'];
			$dataArray['created_date'] = date('Y-m-d h:i:s');
			if($this->model_general->updateRow($table,$dataArray,'id',$event_id)){
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Event successfully updated.</div>');
				$redirecturl = ADMIN_URL.'events/edit/'.$event_id;
				redirect($redirecturl,'refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to update Events.</div>');
			}
		}
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function personnel()
	{
		$this->data['personnel'] = $this->model_general->getpersonnel();
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}
}
