<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nmccdatabase extends CI_Controller {
	
    function __construct()
    {

        parent::__construct();

        $this->load->model('user');

		
    }
	
	public function index()
	{
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method());	
	}

	public function home()
	{
		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method());	
	}

	public function infin(){
		//echo $this->router->fetch_class().'/'.$this->router->fetch_method(); die; 
		$this->data['countries'] = $this->user->getactivecountries();

		
		

		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('firstname', 'Firstname', 'required');
		$this->form_validation->set_rules('lastname', 'Lastname', 'required');
		$this->form_validation->set_rules('institution_name', 'Institution', 'required');
		// $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[authors.email]');
		/*$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');*/
		//$this->form_validation->set_rules('check', '...', 'callback_accept_terms');
		
	           

		if (!$this->form_validation->run() == FALSE) {
			$totalFormData = array( 			
				'name'                  => $_POST['firstname']." ".$_POST['lastname'],
				'email'                 => $_POST['email'],
				'phonenumber'           => $_POST['phonenumber'],
				'affilication'          => $_POST['affilication'],
				'institution_name'      => $_POST['institution_name'],
				'institution_address'   => $_POST['institution_address'],
				'institution_address2'   => $_POST['institution_address2'],
				'institution_country'   => $_POST['institution_country'],
				'institution_state'     => $_POST['institution_state'],
				'institution_city'      => $_POST['institution_city'],
				'institution_zipcode'   => $_POST['institution_zipcode'],
				'institution_type'      => $_POST['institution_type'],
				'isolation_reason'      => $_POST['isolation_reason'],
				'journal_name'          => $_POST['journal_name'],

				'organisms_address'      => $_POST['organisms_address'],
				'organisms_address2'     => $_POST['organisms_address2'],
				'organisms_country'     => $_POST['organisms_country'],
				'organisms_state'       => $_POST['organisms_state'],
				'organisms_city'        => $_POST['organisms_city'],
				'biological_importance' => $_POST['biological_importance'],
				'isolation_date	'       => date('Y-m-d h:i:s'),
				'isolation_method'      => $_POST['isolation_method'],
				'depositor'            => $_POST['depositor'],
				'strain'            => $_POST['strain'],
				'preservation_procedure'            => $_POST['preservation_procedure'],
				'growth_media'            => $_POST['growth_media'],
				'regulatory_conditions'            => $_POST['regulatory_conditions'],
				'accession_number'            => $_POST['accession_number'],
				'other_information'            => $_POST['other_information'],
				'status'            => 1,
				'created_date'            => date('Y-m-d h:i:s')
			);
			if ($_POST['organisms_name']=='other1') {
				$totalFormData1 = array( 
                  'organisms_name' => $_POST['organisms_name1']

				);
			} else{
				$totalFormData1 = array( 
                  'organisms_name' => $_POST['organisms_name']

				);

			}

			if ($_POST['characterization']=='other2') {
				$totalFormData2 = array( 
                  'characterization'   => $_POST['characterization2']

				);
			} else{
				$totalFormData2 = array( 
                  'characterization'   => $_POST['characterization']

				);

			}

			if ($_POST['applications']=='other3') {
				$totalFormData3 = array( 
                  'applications'          => $_POST['applications3']

				);
			} else{
				$totalFormData3 = array( 
                  'applications'          => $_POST['applications']

				);

			}

			if ($_POST['other_associated']=='other4') {
				$totalFormData4 = array( 
                  'other_associated'       => $_POST['other_associated4'],

				);
			} else{
				$totalFormData4 = array( 
                  'other_associated'       => $_POST['other_associated'],

				);

			}

		


  //        echo "<pre>";
		// print_r($totalFormData);  
	 //    echo "<pre>";
		// print_r($totalFormDat1);
		// echo "<pre>";  
		// print_r($totalFormDat2);
		// echo "<pre>";
		// print_r($totalFormDat3);
		// echo "<pre>";
		// print_r($totalFormDat4);

		// 	die;


              $datamulti=array_merge($totalFormData,$totalFormData1,$totalFormData2,$totalFormData3,$totalFormData4);
        //       echo "<pre>";
		      // print_r( $datamulti); die;
			
                 
            
			if($authoriid = $this->user->addMultipleData('authors',$datamulti)){
		    
					
					$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Authores add successfully !!</div>');
					
			}else{
					$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add authors .</div>');
					
			}
		  
		}

		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	


	public function getajaxcountrystate()
	{
		$country_id = $this->input->post('country_id');

		if($country_id!=''){
			$this->data['states'] = $this->user->getcountrystate($country_id);
			// echo "<pre>";
			// print_r($this->data['states']); die;
        $this->load->view('nmccdatabase/getajaxcountrystate.php',$this->data);	
			
          
		}
	}

	public function getstatelga(){
		//$this->adminloginCheck();
		$state_id = $this->input->post('state_id');
		if($state_id!=''){
			$this->data['lga'] = $this->user->getnigeriastateslga($state_id);

		// echo "<pre>";
		// print_r($this->data['lga']);  die;

             $this->load->view('nmccdatabase/getstatelga.php',$this->data);
	}

  }

  public function getlgacommunity(){
		
		$state_id = $this->input->post('state_id');
		if($state_id!=''){
			$this->data['community'] = $this->user->getnigeriacommunity($state_id);

		echo "<pre>";
		print_r($this->data['community']);  

             $this->load->view('nmccdatabase/getlgacommunity.php',$this->data);
	}

  }

	public function region()
	{
		$this->data['authors'] = $this->user->getnigireaauthors(); 
		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function otherregion()
	{
		$this->data['authors'] = $this->user->getotherregionauthors(); 
		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function acronyms()
	{
		$this->data['acronyms'] = $this->user->getacronyms();

		// echo "<pre>";
		// print_r($this->data['acronyms']); die; 
		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}
	public function inquiry()
	{
		$this->data['inquiry'] = $this->user->getinquiry();

		// echo "<pre>";
		// print_r($this->data['acronyms']); die; 
		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function collectionsearch()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('searchcollection', 'Collection', 'required');
		if (!$this->form_validation->run() == FALSE) {
          $inputsearch = $this->input->post("searchcollection");
          $this->data['authors'] = $this->user->getcollectionauthors($inputsearch);
          $this->data['inputsearch'] =  $this->input->post("searchcollection");
		}else{
		  $this->data['authors'] = array(); 
		  $this->data['inputsearch'] =  array(); 

		}
		
		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function strainsearch()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('searchcollection', 'Collection', 'required');
		if (!$this->form_validation->run() == FALSE) {
          $collectionsearch = $this->input->post("searchcollection");
          $strainsearch = $this->input->post("searchstrain");
          $this->data['authors'] = $this->user->getcollectionwithstrainauthors($collectionsearch,$strainsearch);
          $this->data['collection'] =  $this->input->post("searchcollection");
          $this->data['strain'] =  $this->input->post("searchstrain");
		}else{
		  $this->data['authors'] = array(); 
		  $this->data['collection'] =  '';
          $this->data['strain'] =  '';
		}
		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function query()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('search_organism_type', 'Organism Type', 'required');
		if (!$this->form_validation->run() == FALSE) {
          $collectionsearch = $this->input->post("search_organism_type");
          //$strainsearch = $this->input->post("searchstrain");
          $this->data['authors'] = $this->user->getcollectionauthors($collectionsearch);
          $this->data['collection'] =  $this->input->post("search_organism_type");
         // $this->data['strain'] =  $this->input->post("searchstrain");
		}else{
		  $this->data['authors'] = array(); 
		  $this->data['collection'] =  '';
          $this->data['strain'] =  '';
		}
		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}
	
	public function login(){
    
        $this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('email', 'Email Address', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		if (!$this->form_validation->run() == FALSE){
            $email = $this->input->post('email');
			$password = $this->input->post('password');
			$newpassword = $password;
			
			$user_info = $this->user->user_login($email,$newpassword);
		
			if($user_info){
                $session = $user_info;
				$this->session->set_userdata('customer_logged_in', $session);
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Login Successfully</div>');			
				$redirecturl = BASE_URL.'nmccdatabase/infin';
				redirect($redirecturl,'refresh');
		    }else{
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Email or Password Invalid</div>');			
				$redirecturl = BASE_URL.'nmccdatabase';
				redirect($redirecturl,'refresh');
		    }
		}else{      
	    $this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method());	
	    $redirecturl = BASE_URL.'/nmccdatabase';
	    redirect($redirecturl,'refresh');
		
        }	

	}
	
    public function register()
	{
      
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('firstname', 'Firstname', 'required');
		$this->form_validation->set_rules('lastname', 'Lastname', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[user_register.email]');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
		//$this->form_validation->set_rules('check', '...', 'callback_accept_terms');
	           

		if (!$this->form_validation->run() == FALSE) {
            $arrData = array(
				        'first_name' => $this->input->post('firstname'),
				        'last_name' => $this->input->post('lastname'),
				        'email' => $this->input->post('email'),
				        'password' => $this->input->post('password'),
				        'status' =>  1,
				        'created_date' => date('Y-m-d H:i:s')
				    );
				
				if($useriid = $this->user->insert_regdata($arrData)){
					$email = $this->input->post('email');
					$newpassword = $this->input->post('password');
                    $user_info = $this->user->user_login($email,$newpassword);
					$session = $user_info;
				    $this->session->set_userdata('customer_logged_in', $session);
					$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">You have successfully registered.</div>');
					$addressurl = BASE_URL.'nmccdatabase/infin';
					redirect($addressurl,'refresh');
				}else{
					$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to registered .</div>');
					$addressurl = BASE_URL.'nmccdatabase/register';
					redirect($addressurl,'refresh');
				}
		  
		}else{
			
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method());	

		}
	}

	
	//user registration
	public function forgot()
	{
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method());	
	}

	public function logout(){
		$this->session->sess_destroy();
		$logouturl = BASE_URL.'nmccdatabase'; 
		redirect($logouturl,'index');

	}
	

	public function culture_held()
	{
		$this->data['culture_held']=$this->user->getCulture_held();
		/*echo "<pre>";
		print_r($this->data['culture_held']); die;*/

		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function culture_collection()
	{

	    $this->data['culture_collection']=$this->user->getculture_collection();
		// echo "<pre>";
		// print_r($this->data['culture_collection']); die;

		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);
	}
	public function numberCultureState()
	{

	     $this->data['numberCulture']=$this->user->getNumberCulture();
		/*echo "<pre>";
		print_r($this->data['numberCulture']); die;*/

		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}
	public function serviceProvidedByState()
	{

		$this->data['serviceprovided']=$this->user->getServiceProvided();
		// echo "<pre>";
		// print_r($this->data['serviceprovided']); die;

		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}
	public function rankStrainByState()
	{

		$this->data['serviceTypes']=$this->user->getServiceTypes();
		/*echo "<pre>";
		print_r($this->data['serviceTypes']); die;*/

		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

}
