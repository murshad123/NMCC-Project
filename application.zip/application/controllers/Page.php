<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Page extends CI_Controller
{

    /*public function __construct()
    {
        parent::__construct();
        $this->load->model('admin/catalog/categories','model_catalog_category');
        $this->load->model('Mcms', 'cms');
       
    }*/

    public function index()
    {



        $this->data['page_title'] = 'NMCC';
        $page_slug          = $this->uri->segment(2);
      /*  $this->data['pageData'] = $this->cms->get_page_by_slug($page_slug);
        $this->data['cur_page']   = $page_slug;*/

        if ($page_slug == 'faq') {
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }
        
        if ($page_slug == 'about-us') { 
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }

         if ($page_slug == 'how-to-use') {
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }

         if ($page_slug == 'why-magic-lockers') {
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }

         if ($page_slug == 'pricing') {
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }

         if ($page_slug == 'testimonials') {
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }

         if ($page_slug == 'terms-conditions') {
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }

        if ($page_slug == 'contact-us') {
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }

        if ($page_slug == 'help-users') {
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }

        if ($page_slug == 'help-buyers') {
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }

        if ($page_slug == 'help-suppliers') {
            $this->load->front($this->router->fetch_class().'/'.$page_slug,$this->data);
        }



     
        

    }

    
}
