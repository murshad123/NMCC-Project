<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title> NMCC | HOME PAGE  </title>
  <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto:300i,400,500" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo ASSETS_URL ?>vendor/themify-icons/themify-icons.css">
  <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
  <link rel="stylesheet" href="<?php echo ASSETS_URL ?>vendor/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="<?php echo ASSETS_URL ?>vendor/owl-carousel/owl.carousel.min.css">
  <link rel="stylesheet" href="<?php echo ASSETS_URL ?>vendor/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo ASSETS_URL ?>css/style.css">
</head>
<body>
  <!-- ================Offcanvus Menu Area =================-->
  <div class="side_menu">
      <ul class="list menu_right">
        <li>
          <a href="<?php echo BASE_URL; ?>">Home</a>
        </li>
        <li>
          <a href="<?php echo BASE_URL; ?>page/about-us">About Us </a>
        </li>
        <li>
          <a href="<?php echo BASE_URL; ?>general/personnel">Personnel</a>
        </li >
        <li class="dropdown">
          <a href="javascriptvoid(0);" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Events </a>
          <ul class="list " aria-labelledby="dropdownMenuButton">
            <li>
              <a href="<?php echo BASE_URL; ?>general/news">News</a>
            </li>
            <li>
              <a href="<?php echo BASE_URL; ?>general/seminars">Seminars/Workshops</a>
            </li>
            <!-- <li>
              <a href="workshops.php">Workshops</a>
            </li> -->
          </ul>
        </li>
        <li>
          <?php
            if(!empty($this->session->userdata('customer_logged_in'))){
              $dburl = BASE_URL.'nmccdatabase/infin';
            }else{
              $dburl = BASE_URL.'nmccdatabase/region';
            } ?>
          <a href="<?php echo $dburl; ?>">NMCC-DB</a>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Link to Related Sites </a>
          <ul class="list " aria-labelledby="dropdownMenuButton">
            <li>
              <a href="https://www.nabda.gov.ng" target="_blank">Nabda</a>
            </li>
            <li>
              <a href="https://www.ncbi.nim.nih.gov" target="_blank">Ncbi</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="<?php echo BASE_URL; ?>general/contactus">Contact Us</a>
        </li>
      </ul>
  </div>
  <!--================End Offcanvus Menu Area =================-->

  <!--================Canvus Menu Area =================-->
  <div class="canvus_menu">
    <div class="container">
      <div class="float-right">
        <div class="toggle_icon" title="Menu Bar">
          <span></span>
        </div>
      </div>
    </div>
  </div>
  <!--================End Canvus Menu Area =================-->
  <header class="hero-banner project-bg">

  <div class="navbar-header">
    <a class="navbar-brand" href="<?php echo BASE_URL; ?>">
      <img src="<?php echo ASSETS_URL; ?>img/logo.jpg" alt="logo">
    </a>
    </div>

   
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">NMCC-DB</h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">NMCC-DB</span>
      </div>
    </div>
  </header>
      

  <section class="dashboard-main">
    <div class="container">
      <div class="row">
        <div class="navbar navbar-expand-lg">
         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon">
            <i class="fa fa-bars"></i>
          </span>
      </button>
         <div class="dashboard-menu collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
      <?php if(!empty($this->session->userdata('customer_logged_in'))){ ?>           
      

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-hover="dropdown">
          INFIN
        </a>
        <ul class="dropdown-menu dropdownhover-bottom" aria-labelledby="navbarDropdown2">
          <li class="nav-item">
          <a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/home'; ?>">NMCC-Home</a></li>
          <li class="nav-item">
          <a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/infin'; ?>">Data Input Form </a></li>
        </ul>
      </li>
      <?php } ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="<?php echo BASE_URL.'nmccdatabase/region'; ?>" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-hover="dropdown">Region</a>
        <ul class="dropdown-menu dropdownhover-bottom" >
          <li class="nav-item "><a class="dropdown-item " href="<?php echo BASE_URL.'nmccdatabase/region'; ?>">Nigeria</a>
            
          </li>
           <li class="nav-item"><a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/otherregion'; ?>">Other/Country</a></li>
          <!--  <li class="nav-item"><a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/acronyms'; ?>">Acronyms</a></li> -->
        </ul>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-hover="dropdown">
          Search
        </a>
        <ul class="dropdown-menu dropdownhover-bottom" aria-labelledby="navbarDropdown2">
          <li class="nav-item">
          <a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/collectionsearch'; ?>">By Collection</a></li>
          <li class="nav-item">
          <a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/strainsearch'; ?>">By Strain</a></li>
        </ul>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-hover="dropdown">
         Basic Statistics
        </a>
        <ul class="dropdown-menu dropdownhover-bottom" aria-labelledby="navbarDropdown2">
          <li class="nav-item">
          <a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/culture_held'; ?>">Cultures Held</a></li>
          <li class="nav-item">
          <a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/culture_collection'; ?>">Culture Collections</a></li>
          <li class="nav-item">
          <a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/numberCultureState'; ?>">Numbers of culture collections registered with WDCM</a></li>
          <li class="nav-item">
          <a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/serviceProvidedByState'; ?>">Service Provided in addition to regular maintenance</a></li>
          <li class="nav-item">
          <a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/rankStrainByState'; ?>">Types Of Services </a></li>
        </ul>
      </li>
      <!-- <li class="nav-item dropdown">
        <a class="nav-link " href="#" >
          Basic Statistics
        </a>
       
      </li> -->
      <?php if(!empty($this->session->userdata('customer_logged_in'))){ ?>
      <li class="nav-item dropdown">
        <a class="nav-link " href="<?php echo BASE_URL.'nmccdatabase/query'; ?>" >
          Query
        </a>
      </li>
      <?php } ?>
        
      <li class="nav-item dropdown">
        <a class="nav-link " href="<?php echo BASE_URL.'nmccdatabase/infex'; ?>" >
          INFEX
        </a> 
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="<?php echo BASE_URL.'nmccdatabase/region'; ?>" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-hover="dropdown">General</a>
        <ul class="dropdown-menu dropdownhover-bottom" >
          <li class="nav-item "><a class="dropdown-item " href="<?php echo BASE_URL.'nmccdatabase/inquiry'; ?>">Inquiry</a>
            
          </li>
             <li class="nav-item"><a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/acronyms'; ?>">Acronyms</a></li>
        </ul>
      </li>

      <?php if(empty($this->session->userdata('customer_logged_in'))){ ?>
      <li class="nav-item dropdown">
        <a class="nav-link " href="<?php echo BASE_URL.'nmccdatabase/'; ?>" >
          Login
        </a>
      </li>
      <?php } ?>

    </ul>
    </div></div>

    <?php   
     if(!empty(($this->session->userdata('customer_logged_in')))){
       $members = $this->session->userdata('customer_logged_in'); ?>
      <div class="dropdown d-flex order-lg-2 ml-auto">
                  <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                    <span class="avatar" style="background-image: url(<?php echo ASSETS_URL; ?>/img/25.jpg)"></span>
                    <span class="ml-2 ">
                      <span class="text-default"><?php if(!empty($members)){ echo $members['first_name'].' '.$members['last_name']; } ?></span>
                      <!-- <small class="text-muted d-block mt-1">Administrator</small> -->
                    </span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                   <!--  <a class="dropdown-item" href="#">
                      <i class="dropdown-icon fe fe-user"></i> Profile
                    </a> -->
                    
                    <a class="dropdown-item" href="<?php echo BASE_URL.'nmccdatabase/logout'; ?>">
                      <i class="dropdown-icon fe fe-log-out"></i> Logout
                    </a>
                  </div>
                </div>
    <?php  }else{ $members = array(); }  ?>
       
     
 
   
    
      </div>
    </div>
  </section>