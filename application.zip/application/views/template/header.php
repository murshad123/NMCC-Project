<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>	NMCC | HOME PAGE  </title>
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300i,400,500" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo ASSETS_URL ?>vendor/themify-icons/themify-icons.css">
	<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
	<link rel="stylesheet" href="<?php echo ASSETS_URL ?>vendor/owl-carousel/owl.theme.default.min.css">
	<link rel="stylesheet" href="<?php echo ASSETS_URL ?>vendor/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo ASSETS_URL ?>vendor/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo ASSETS_URL ?>css/style.css">
</head>
<body>
	<!-- ================Offcanvus Menu Area =================-->
	<div class="side_menu">
			<ul class="list menu_right">
				<li>
					<a href="<?php echo BASE_URL; ?>">Home</a>
				</li>
				<li>
					<a href="<?php echo BASE_URL; ?>page/about-us">About Us </a>
				</li>
				<li>
					<a href="<?php echo BASE_URL; ?>general/personnel">Personnel</a>
				</li >
				<li class="dropdown">
					<a href="javascriptvoid(0);" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Events </a>
					<ul class="list " aria-labelledby="dropdownMenuButton">
						<li>
							<a href="<?php echo BASE_URL; ?>general/news">News</a>
						</li>
						<li>
							<a href="<?php echo BASE_URL; ?>general/seminars">Seminars</a>
						</li>
						<li>
							<a href="<?php echo BASE_URL; ?>general/workshop">Workshops</a>
						</li> 
					</ul>
				</li>
				<li>
				    <?php
				    if(!empty($this->session->userdata('customer_logged_in'))){
				    	$dburl = BASE_URL.'nmccdatabase/infin';
				    }else{
				    	$dburl = BASE_URL.'nmccdatabase/region';
				    } ?>
					<a href="<?php echo $dburl; ?>">NMCC-DB</a>
				</li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Link to Related Sites </a>
					<ul class="list " aria-labelledby="dropdownMenuButton">
						<li>
							<a href="https://www.nabda.gov.ng" target="_blank">Nabda</a>
						</li>
						<li>
							<a href="https://www.ncbi.nim.nih.gov" target="_blank">Ncbi</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="<?php echo BASE_URL; ?>general/contactus">Contact Us</a>
				</li>
			</ul>
	</div>
	<!--================End Offcanvus Menu Area =================-->

	<!--================Canvus Menu Area =================-->
	<div class="canvus_menu">
		<div class="container">
			<div class="float-right">
				<div class="toggle_icon" title="Menu Bar">
					<span></span>
				</div>
			</div>
		</div>
	</div>
	<!--================End Canvus Menu Area =================-->
  <header>
    <div class="hero ">
      <a class="navbar-brand" href="<?php echo BASE_URL; ?>">
        <img src="<?php echo ASSETS_URL ?>img/logo.jpg" alt="">
      </a>
      