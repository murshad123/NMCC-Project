<footer class="footer footer-bg">
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-lg-5 mb-4 mb-lg-0 text-left address-main">
					<h3 class="footer__title">Get in touch</h3>
					
                            <a href="tel:+234-803-4007152"><i class="fa fa-phone" aria-hidden="true"></i> +234-803-4007152</a>
                            <a href="mailto:gobioh@yahoo.com"><i class="fa fa-envelope" aria-hidden="true"></i>  gobioh@yahoo.com</a>
                             <a href="" target="_blank" rel="noopener"><i class="fa fa-map-marker"></i>Environmental Biotechnology &Bioconservation Department, National Biotechnology Development Agency (Federal Ministry of Science & Technology), Umar Musa Yar’adua Expressway, Lugbe, Abuja, FCT, Nigeria.P.M.B. 511, Wuse, Abuja</a>
                             <ul class="social-icons">
								<li><a href="#/"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="#/"><i class="fab fa-twitter"></i></a></li>
								<li><a href="#/"><i class="fab fa-linkedin-in"></i></a></li>
								<li><a href="#/"><i class="fab fa-google-plus-g"></i></a></li>					
				</ul>
                        </div>
				<div class="col-sm-4 col-lg-3 mb-4 mb-lg-0 text-left">
					<h3 class="footer__title">Quick Links</h3>
					<ul class="footer__link">
						<li><a href="news.php">News</a></li>
						<li><a href="seminars.php">Seminars</a></li>
						<li><a href="workshops.php">Workshop</a></li>
						<li><a href="database.php">Database</a></li>
						<li><a href="contact.php">Contact</a></li>
					</ul>
				</div>
				
				
				<div class="col-sm-8 col-lg-4 mb-4 mb-lg-0 text-left">
					<h3 class="footer__title">Newsletter</h3>
					<p>You can trust us. we only send promo offers,</p>
					<form action="" class="form-subscribe">
						<div class="input-group">
							<input type="email" class="form-control" placeholder="Your email address" required>
							<div class="input-group-append">
								<button class="btn-append" type="submit"><i class="lnr lnr-arrow-right"></i></button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<div class=" footer__bottom top-border">
				<p>
				Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved <span class="flaot">Powered by <a href="https://www.equalinfotech.com/" target="_blank">Equal Infotech</a></span></p>
				
			</div>
		</div>
	</footer>



	<script src="<?php echo ASSETS_URL ?>vendor/jquery/jquery-3.2.1.min.js"></script>	
		<script src="<?php echo ASSETS_URL ?>js/jquery-1.12.1.min.js"></script>	
	<script src="<?php echo ASSETS_URL ?>vendor/bootstrap/bootstrap.bundle.min.js"></script>
	<script src="<?php echo ASSETS_URL ?>vendor/owl-carousel/owl.carousel.min.js"></script>
		<!-- <script src="<?php echo ASSETS_URL ?>js/validation.js"></script> -->


<script>
		

    var heroCarousel = $('.heroCarousel');
      heroCarousel.owlCarousel({
      loop:true,
      margin:10,
      nav: false,
      autoplay: 4000,
      smartSpeed: 1000,
      startPosition: 1,
      responsiveClass:true,
      responsive:{
        0:{
            items:1
        }
      }
	});

	var dropToggle = $('.menu_right > li').has('ul').children('a');
	dropToggle.on('click', function() {
		dropToggle.not(this).closest('li').find('ul').slideUp(200);
		$(this).closest('li').children('ul').slideToggle(200);
		return false;
	});

	$( ".toggle_icon" ).on('click', function() {
		$( 'body' ).toggleClass( "open" );
	});

	</script>
</body>
</html>