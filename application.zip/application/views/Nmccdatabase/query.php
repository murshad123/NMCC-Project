<section class="form-bg">
    <div class="container">
        <div class="row center">
            <div class=" col-md-12 col-xs-12">
                <form class="form-horizontal" action="" method="post">
                    <div class="form-content">
                    <?php echo $this->session->flashdata('response'); ?>  

                         <form method="post" action="">
<div class="row">

   <!--  <div class="col-md-4">
    <input type="text" name="search_organism_name" class="form-control" placeholder="Organism Name"> 
    </div> -->

    <div class="col-md-4">
    <select name="search_organism_type" class="form-control">
                            <option value="">-select Organism Type-</option>
                            <option value="Plant" >Plant</option>
                            <option value="Animal" <?php if(!empty($collection) && $collection == 'Animal'){ echo "selected"; } ?>>Animal</option>
                            <option value="Protozoan" <?php if(!empty($collection) && $collection == 'Protozoan'){ echo "selected"; } ?>>Protozoan</option>
                            <option value="Fungus" <?php if(!empty($collection) && $collection == 'Fungus'){ echo "selected"; } ?>>Fungus</option>
                            <option value="Bacterium" <?php if(!empty($collection) && $collection == 'Bacterium'){ echo "selected"; } ?>>Bacterium</option>
                            <option value="Virus" <?php if(!empty($collection) && $collection == 'Virus'){ echo "selected"; } ?>>Virus</option>

                          </select>
                          <span class="help-block m-b-none"><?php echo form_error('search_organism_type'); ?></span>
    </div>
    <div class="col-md-4">
                          <select name="search_sequence_type" class="form-control">
                            <option value="">-Select Characterization-</option>
                            <option value="rRNA" <?php if(!empty($collection) && $collection == 'rRNA'){ echo "selected"; } ?>>rRNA</option>
                            <option value="Genomic DNA" <?php if(!empty($collection) && $collection == 'Genomic DNA'){ echo "selected"; } ?>>Genomic DNA</option>
                            <option value="Any Gene" <?php if(!empty($collection) && $collection == 'Any Gene'){ echo "selected"; } ?>>Any Gene</option>
                            <option value="ITS Gene" <?php if(!empty($collection) && $collection == 'ITS Gene'){ echo "selected"; } ?>>ITS Gene</option>
                          </select>
                          <span class="help-block m-b-none"><?php echo form_error('searchcollection'); ?></span>
                        </div>
                          <div class="col-md-4">
                          <select name="search_identification_level" class="form-control">
                            <option value="">-Select Applications-</option>
                            <option value="Morphological only" <?php if(!empty($strain) && $strain == 'Morphological only'){ echo "selected"; } ?>>Morphological only</option>
                            <option value="Morphological, Biochemical & Molecular" <?php if(!empty($strain) && $strain == 'Morphological, Biochemical & Molecular'){ echo "selected"; } ?>>Morphological, Biochemical & Molecular</option>
                            <option value="Molecular only" <?php if(!empty($strain) && $strain == 'Molecular only'){ echo "selected"; } ?>>Molecular only</option>
                            
                            
                          </select>
                          <span class="help-block m-b-none"><?php echo form_error('searchstrain'); ?></span>
                        </div>

     <!-- <div class="col-md-4">
    <input type="text" name="search_isolation_method" class="form-control" placeholder="Isolation Method"> 
    </div> -->
</div>
<!-- 
                        <div class="row">
                        <div class="col-md-4">
                          <select name="search_sequence_type" class="form-control">
                            <option value="">-Select Sequence Type-</option>
                            <option value="rRNA" <?php if(!empty($collection) && $collection == 'rRNA'){ echo "selected"; } ?>>rRNA</option>
                            <option value="Genomic DNA" <?php if(!empty($collection) && $collection == 'Genomic DNA'){ echo "selected"; } ?>>Genomic DNA</option>
                            <option value="Any Gene" <?php if(!empty($collection) && $collection == 'Any Gene'){ echo "selected"; } ?>>Any Gene</option>
                            <option value="ITS Gene" <?php if(!empty($collection) && $collection == 'ITS Gene'){ echo "selected"; } ?>>ITS Gene</option>
                          </select>
                          <span class="help-block m-b-none"><?php echo form_error('searchcollection'); ?></span>
                        </div>

                        <div class="col-md-4">
                          <select name="search_identification_level" class="form-control">
                            <option value="">-Select Identification Level-</option>
                            <option value="Morphological only" <?php if(!empty($strain) && $strain == 'Morphological only'){ echo "selected"; } ?>>Morphological only</option>
                            <option value="Morphological, Biochemical & Molecular" <?php if(!empty($strain) && $strain == 'Morphological, Biochemical & Molecular'){ echo "selected"; } ?>>Morphological, Biochemical & Molecular</option>
                            <option value="Molecular only" <?php if(!empty($strain) && $strain == 'Molecular only'){ echo "selected"; } ?>>Molecular only</option>
                            
                            
                          </select>
                          <span class="help-block m-b-none"><?php echo form_error('searchstrain'); ?></span>
                        </div>

                        <div class="col-md-4">
    <input type="text" name="search_isolation_purpose" class="form-control" placeholder="Purpose(s) for isolation"> 
    </div>

                        
                          
                        </div>

                        <div class="row">
                          <div class="col-md-4">
    <input type="text" name="search_special_properties" class="form-control" placeholder="Special Properties"> 
    </div>

    <div class="col-md-4">
                          <select name="search_application_areas" class="form-control">
                            <option value="">-Select Application Areas-</option>
                            <option value="Bioassay" <?php if(!empty($strain) && $strain == 'Bioassay'){ echo "selected"; } ?>>Bioassay</option>
                            <option value="Quality control" <?php if(!empty($strain) && $strain == 'Quality control'){ echo "selected"; } ?>>Quality control</option>
                            <option value="Resistance test" <?php if(!empty($strain) && $strain == 'Resistance test'){ echo "selected"; } ?>>Resistance test</option>
                            <option value="Degradation" <?php if(!empty($strain) && $strain == 'Degradation'){ echo "selected"; } ?>>Degradation</option>
                            
                            
                          </select>
                          <span class="help-block m-b-none"><?php echo form_error('searchstrain'); ?></span>
                        </div>

                         <div class="col-md-4">
                          <select name="search_preservation_method" class="form-control">
                            <option value="">-Select Preservation Method-</option>
                            <option value="Most appropriate growth/preservation media" <?php if(!empty($strain) && $strain == 'Most appropriate growth/preservation media'){ echo "selected"; } ?>>Most appropriate growth/preservation media</option>
                            <option value="Any special requirement" <?php if(!empty($strain) && $strain == 'Any special requirement'){ echo "selected"; } ?>>Any special requirement</option>
                            
                            
                            
                          </select>
                          <span class="help-block m-b-none"><?php echo form_error('searchstrain'); ?></span>
                        </div>
                        </div> -->

                        <div class="row">
                          <div class="col-md-4">
                            <select name="search_pathogenic" class="form-control">
                              <option value="">-Other Associated-</option>
                              <option value="No" <?php if(!empty($strain) && $strain == 'No'){ echo "selected"; } ?>>No</option>
                              <option value="Yes" <?php if(!empty($strain) && $strain == 'Yes'){ echo "selected"; } ?>>Yes</option>
                            </select>
                          </div>
                       

                        
                          <!-- <div class="col-md-4">
                            <select name="search_modification" class="form-control">
                              <option value="">-Select Modification-</option>
                              <option value="Laboratory evolution" <?php if(!empty($strain) && $strain == 'Laboratory evolution'){ echo "selected"; } ?>>Laboratory evolution</option>
                              <option value="Genetical" <?php if(!empty($strain) && $strain == 'Genetical'){ echo "selected"; } ?>>Genetical</option>
                            </select>
                          </div> -->
                        

                     
                          <div class="col-md-4"><button type="submit" name="search"  class="search-btn">Search</button></div>
                   
                        </div>

                      </form>

                      <br>
                      <br>
                      <br>

                      <?php  if(!empty($collection)){  ?>

                        <table style="width:100%">
                        <thead>
                          <tr>
                            <th>Accession Number</th>
                            <th>Author's Name</th>
                            <th>Email</th> 
                            <th>Country</th> 
                            <th>Affiliation</th>
                            <th>Institition</th>
                            <th>Organism</th>
                            <th>Comminity</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php
                          if(!empty($authors)){
                          foreach ($authors as $authorskey => $authorsvalue) { ?>
                          <tr>
                          <td><?php echo $authorsvalue['accession_number']; ?></td>
                          <td><?php echo $authorsvalue['name']; ?></td>
                          <td><?php echo $authorsvalue['email']; ?></td> 
                          <td><?php echo $authorsvalue['country_name']; ?></td>
                          <td><?php echo $authorsvalue['affilication']; ?></td>
                          <td><?php echo $authorsvalue['institution_name']; ?></td>
                          <td><?php echo $authorsvalue['organisms_name']; ?></td>
                          <td><?php echo $authorsvalue['community']; ?></td>
                        </tr>

                        <?php } }else{?>
                         <tr>
                          <td colspan="8" style="color: red;"> No record found</td>
                          
                        </tr>
                        <?php } ?>
                         
                        </tbody>
                    </table>

                    <?php } ?>

                        
                       
                  
                
              
             
        
              
       
                        
                        
                        
                      
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>