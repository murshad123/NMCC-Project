<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="<?php echo ASSETS_URL; ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">Register</h2>
      <div class=" breadcrumb">
        <a href="index.php" class="btn">Home</a>
        <span class="btn btn--rightBorder">Register</span>
      </div>
    </div>
  </header>
 <section class=" comman-main">
    <div class="container">
        <div class="row justify-center">
            <div class=" col-md-8">
                <div class="tab">
                        
                        <h3 class="member-head1">Register</h3>
						<?php echo $this->session->flashdata('response'); ?>

                            <form class="form-horizontal" id="registerForm" action="<?php echo BASE_URL.'nmccdatabase/register'; ?>" method="post">
                                <div class="row">
                                <div class="col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label >First name </label>
                                    <input type="text" name="firstname" class="form-control" >
                                </div>
								<span class="help-block m-b-none"><?php echo form_error('firstname'); ?></span>
                                </div>

                                 <div class="col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label >Last name</label>
                                    <input type="text" name="lastname" class="form-control" >
                                </div>
							    <span class="help-block m-b-none"><?php echo form_error('lastname'); ?></span>
								</div></div>
                                 <div class="row">
                                     <div class="col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <label >Email</label>
                                            <input type="email"  name="email" class="form-control" >
                                        </div>
									 <span class="help-block m-b-none"><?php echo form_error('email'); ?></span>

                                     </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label >Password</label>
                                            <input type="password" name="password" class="form-control" >
                                        </div>
									   <span class="help-block m-b-none"><?php echo form_error('password'); ?></span>

                                    </div>
                                    <div class="col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label >Confirm password</label>
                                            <input type="password" name="confirm_password" class="form-control" >
                                        </div>
									    <span class="help-block m-b-none"><?php echo form_error('confirm_password'); ?></span>

                                    </div></div>
                                    
                                <div class="row justify-center">
                                    <div class="col-md-6">
                                <div class="form-group">
                                    <button type="submit" name="registration" class="btn btn-default">Register</button>
                                </div>
                                </div>
                                </div>
                            </form>
                       
                </div>
            </div>
        </div>
    </div>

  </section>