
 <section class="form-bg form-horizontal">
  <div class="container">
    <div class="row center">
       <div class=" col-md-12 col-xs-12">
        <div class="form-content text-center">
      <h2 class="head">Welcome to the Nigeria Microbial Cultures Collections</h2>
      <p>Welcome to the Nigeria Microbial Cultures Collections Database, set up to provide information and services to users in the academia, industry, among others. The database mission is to organise collected information on microbial cultures collected in Nigeria as the default region covered by our work and make it universally accessible and useful. However, where data of any other region is available through either collaborative research or other engagements with scientists from those regions, such information shall be made accessible on the platform.</p>
    </div>
  </div>
  </div>
  </div>
</section>