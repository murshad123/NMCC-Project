<section class="form-bg">
    <div class="container">
        <div class="row center">
            <div class=" col-md-10 col-xs-12">
                <form class="form-horizontal" action="" method="post">
                    <div class="form-content">
                    <?php echo $this->session->flashdata('response'); ?>  
                      <h2 class="text-center main-head">Region</h2>
                        <h4 class="heading" style="text-align: center">Nigeria</h4>
                        
                        <table style="width:100%">
                        <thead>
                          <tr>
                            <th>Accession Number</th>
                            <th>Author's Name</th>
                            <th>Email</th> 
                            <th>Country</th> 
                            <th>Affiliation</th>
                            <th>Institition</th>
                            <th>Organism</th>
                            <th>Comminity</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php
                        if(!empty($authors)){ 
                          foreach ($authors as $authorskey => $authorsvalue) { ?>
                          <tr>
                          <td><?php echo $authorsvalue['accession_number']; ?></td>
                          <td><?php echo $authorsvalue['name']; ?></td>
                          <td><?php echo $authorsvalue['email']; ?></td> 
                          <td><?php echo $authorsvalue['country_name']; ?></td>
                          <td><?php echo $authorsvalue['affilication']; ?></td>
                          <td><?php echo $authorsvalue['institution_name']; ?></td>
                          <td><?php echo $authorsvalue['organisms_name']; ?></td>
                          <td><?php echo $authorsvalue['community']; ?></td>
                        </tr>

                        <?php } } ?>
                         
                        </tbody>
                    </table>
                        
                       
                  
                
              
             
        
              
       
                        
                        
                        
                      
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>