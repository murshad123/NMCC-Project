<?php foreach ($lga as $value) { ?>
<option value='<?php echo $value['state_id']; ?>'><?php echo $value['name']; ?></option> 
 <?php } ?>