<?php foreach ($community as $value) { ?>
<option value='<?php echo $value['state_id']; ?>'><?php echo $value['community_name']; ?></option> 
 <?php } ?>