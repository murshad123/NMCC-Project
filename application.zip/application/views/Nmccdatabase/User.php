<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class User extends CI_Model {

    	public function __construct(){
	       	parent::__construct();
    }

    public function addRow($tab, $array, $disp = false) {
	        $this->db->insert($tab, $array);

	        $insert_id = $this->db->insert_id();
	        if($disp){
	            return $this->db->last_query();
	        }
	        return $insert_id;
    }

	public function updateRow($tab, $array, $where_field, $where_value,$disp = false) {
	    $this->db->where($where_field, $where_value);
	    $result = $this->db->update($tab, $array);
	    //echo $this->db->last_query(); die;
	  
	    if($disp){
	        return $this->db->last_query();
	    }
	    return $result;
	}
    //user login
    public function user_login($username, $password){
		
		$user=$this->db->get_where('user_register',array('email'=>$username,'password'=>$password,'status'=>1));
		
		if($user->num_rows()){
			return $user->row_array();
		}else {
			return false;
		}
		
	}
	public function insert_regdata($arrData){
		
		
		$result = $this->db->insert('user_register',$arrData);
		if($result == 1){
			return true;
		}else{
			return false;
		}
	}
	
}