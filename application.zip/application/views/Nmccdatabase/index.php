<header class="hero-banner project-bg">
      <img src="<?php echo BASE_URL?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">NMCC-DB</h2>
      <div class="btn-group breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">NMCC-DB</span>
      </div>
    </div>
  </header>
 <section class="form-mr comman-main" >
    <div class="container">
        <div class="row justify-center">
            <div class=" col-md-6">
                <div class="tab">
                        <div class="member-icon">
                          <i class="fa fa-user"></i>
                        </div>
                        <h3 class="member-head">Member Login</h3>
						   <?php echo $this->session->flashdata('response'); ?>
                            <form class="form-horizontal" id="loginForm" action="<?php echo BASE_URL.'nmccdatabase/login'; ?>" method="post">
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
								<span class="help-block m-b-none"><?php echo form_error('email'); ?></span>

                                <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
							    <span class="help-block m-b-none"><?php echo form_error('password'); ?></span>

                                <!-- <div class="form-group">
                                    <div class="main-checkbox">
                                        <input value="None" id="checkbox1" name="check" type="checkbox">
                                        <label for="checkbox1"></label>
                                    </div>
                                    <span class="text">Remember me</span>
                                </div> -->
                                <div class="form-group">
                                    <button type="submit" name="verify" class="btn btn-default">Sign in</button>
                                </div>
                                <div class="form-group forgot-pass">
                                    <a href="<?php echo BASE_URL; ?>nmccdatabase/forgot" class="btn btn-default">Forgot password</a>
                                    <a href="<?php echo BASE_URL; ?>nmccdatabase/register" class="btn btn-default">Register Here</a>
                                </div>
                            </form>
                       
                </div>
            </div>
        </div>
    </div>

  </section>