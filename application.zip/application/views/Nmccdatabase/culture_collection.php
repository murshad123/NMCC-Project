<section class="form-bg">
    <div class="container">
        <div class="row center">
            <div class=" col-md-12 col-xs-12">
                <form class="form-horizontal" action="" method="post">
                    <div class="form-content">
                    <?php echo $this->session->flashdata('response'); ?>
                    <input type="button" value="Print Details" onclick="printDiv()">  
                      <h2 class="text-center main-head">BASIC STATISTICS</h2>
                      <div id="GFG">
                        <h4 class="heading" style="text-align: center">Culture Collections</h4>
                        
                        <table style="width:100%">
                        <thead>
                          <tr>
                            <th>S.No.</th>
                            <th>Supported by</th>
                            <th>No. of collections</th> 
                           
                          </tr>
                        </thead>
                        <tbody>
                  <?php
                    $i=1;
                    if(!empty($culture_collection)){ 
                      foreach ($culture_collection as $culture_collectionkey => $culture_collection) { ?>
                      <tr>
                       <td><?php echo $i; ?></td> 
                      <td><?php echo $culture_collection['supported_by']; ?></td>
                      <td><?php echo $culture_collection['no_of_collection']; ?></td> 
                    
                    </tr>
                    
                    <?php  $i++;} } ?> 
                         
                        </tbody>
                    </table> 
                    </div>   
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

 <script> 
        function printDiv() { 
            var divContents = document.getElementById("GFG").innerHTML; 
            var a = window.open('', '', 'height=500, width=500'); 
            a.document.write('<html>'); 
            a.document.write('<body > <h1>BASIC STATISTICS <br>'); 
            a.document.write(divContents); 
            a.document.write('</body></html>'); 
            a.document.close(); 
            a.print(); 
        } 
    </script> 