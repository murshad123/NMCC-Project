<section class="form-bg">
    <div class="container">
        <div class="row center">
            <div class=" col-md-12 col-xs-12">
                <form class="form-horizontal" action="" method="post">
                    <div class="form-content">
                    <?php echo $this->session->flashdata('response'); ?>  
                      <h2 class="text-center main-head">Region</h2>
                        <h4 class="heading" style="text-align: center">Acronyms</h4>
                        
                        <table style="width:100%">
                        <thead>
                          <tr>
                            <th>S.No.</th>
                            <th>Acronyms's Name</th>
                            <th>Definitions</th> 
                            <!-- <th>Date</th>  -->
                            <!-- <th>Affiliation</th>
                            <th>Institition</th>
                            <th>Organism</th>
                            <th>Comminity</th> -->
                          </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i=1;
                        if(!empty($acronyms)){ 
                          foreach ($acronyms as $acronymskey => $acronymsvalue) { ?>
                          <tr>
                           <td><?php echo $i; ?></td> 
                          <td><?php echo $acronymsvalue['acronym']; ?></td>
                          <td><?php echo $acronymsvalue['definition']; ?></td> 
                         <!--  <td><?php echo $acronymsvalue['created_date']; ?></td> -->
                          <!-- <td><?php echo $acronymsvalue['affilication']; ?></td>
                          <td><?php echo $$acronymsvalue['institution_name']; ?></td>
                          <td><?php echo $acronymsvalue['organisms_name']; ?></td>
                          <td><?php echo $acronymsvalue['community']; ?></td> -->
                        </tr>
                        
                        <?php  $i++;} } ?>
                         
                        </tbody>
                    </table>
                        
                       
                  
                
              
             
        
              
       
                        
                        
                        
                      
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>