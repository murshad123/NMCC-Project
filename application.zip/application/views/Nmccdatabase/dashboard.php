<?php include 'header.php'; ?>

        <!-- Content -->
        <div class="content">
            <!-- Animated -->
            <div class="animated fadeIn">
               coming soon..
            </div>
            <!-- .animated -->
        </div>
        <!-- /.content -->

    <?php include 'footer.php'; ?>