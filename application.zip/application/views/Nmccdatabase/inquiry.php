<section class="form-bg">
    <div class="container">
        <div class="row center">
            <div class=" col-md-12 col-xs-12">
                <form class="form-horizontal" action="" method="post">
                    <div class="form-content">
                    <?php echo $this->session->flashdata('response'); ?>  
                      <h2 class="text-center main-head">Region</h2>
                        <h4 class="heading" style="text-align: center">Inquiry</h4>
                        
                        <table style="width:100%">
                        <thead>
                          <tr>
                            <th>S.No.</th>
                            <th>Name</th>
                            <th>Email</th> 
                            <th>Subject</th>
                            <th>Message</th>
                          
                          </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i=1;
                        if(!empty($inquiry)){ 
                          foreach ($inquiry as $inquirykey => $inquiryvalue) { ?>
                          <tr>
                           <td><?php echo $i; ?></td> 
                          <td><?php echo $inquiryvalue['name']; ?></td>
                          <td><?php echo $inquiryvalue['email']; ?></td> 
                         <td><?php echo $inquiryvalue['subject']; ?></td> 
                          <td><?php echo $inquiryvalue['message']; ?></td>  
                        </tr>
                        
                        <?php  $i++;} } ?>
                         
                        </tbody>
                    </table>           
                      
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>