<section class="form-bg">
    <div class="container">
        <div class="row center">
            <div class=" col-md-12 col-xs-12">
                <form class="form-horizontal" action="" method="post">
                    <div class="form-content">
                    <?php echo $this->session->flashdata('response'); ?>  
                      <h2 class="text-center main-head">Search By Strain</h2>

                         <form method="post" action="">
                        <div class="row">
                        <div class="col-md-5">
                          <select name="searchcollection" class="form-control">
                            <option value="">-select-</option>
                            <option value="Fungus" <?php if(!empty($collection) && $collection == 'Fungus'){ echo "selected"; } ?>>Fungus</option>
                            <option value="Bacterium" <?php if(!empty($collection) && $collection == 'Bacterium'){ echo "selected"; } ?>>Bacterium</option>
                            <option value="Virus" <?php if(!empty($collection) && $collection == 'Virus'){ echo "selected"; } ?>>Virus</option>
                          </select>
                          <span class="help-block m-b-none"><?php echo form_error('searchcollection'); ?></span>
                        </div>

                        <div class="col-md-5">
                          <select name="searchstrain" class="form-control">
                            <option value="">-select-</option>
                            <option value="pathogenic" <?php if(!empty($strain) && $strain == 'pathogenic'){ echo "selected"; } ?>>Pathogenic</option>
                            <option value="non-pathogenic" <?php if(!empty($strain) && $strain == 'non-pathogenic'){ echo "selected"; } ?>>Non-pathogenic</option>
                            
                          </select>
                          <span class="help-block m-b-none"><?php echo form_error('searchstrain'); ?></span>
                        </div>

                        <div class="col-md-2">
                          <button type="submit" name="search"  class="search-btn">Search</button>
                        </div>
                          
                        </div>

                      </form>

                      <br>
                      <br>
                      <br>

                        <table style="width:100%">
                        <thead>
                          <tr>
                            <th>Accession Number</th>
                            <th>Author's Name</th>
                            <th>Email</th> 
                            <th>Country</th> 
                            <th>Affiliation</th>
                            <th>Institition</th>
                            <th>Organism</th>
                            <th>Comminity</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php
                        if(!empty($authors)){ 
                          foreach ($authors as $authorskey => $authorsvalue) { ?>
                          <tr>
                          <td><?php echo $authorsvalue['accession_number']; ?></td>
                          <td><?php echo $authorsvalue['name']; ?></td>
                          <td><?php echo $authorsvalue['email']; ?></td> 
                          <td><?php echo $authorsvalue['country_name']; ?></td>
                          <td><?php echo $authorsvalue['affilication']; ?></td>
                          <td><?php echo $authorsvalue['institution_name']; ?></td>
                          <td><?php echo $authorsvalue['organisms_name']; ?></td>
                          <td><?php echo $authorsvalue['community']; ?></td>
                        </tr>

                        <?php } } ?>
                         
                        </tbody>
                    </table>
                        
                       
                  
                
              
             
        
              
       
                        
                        
                        
                      
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>