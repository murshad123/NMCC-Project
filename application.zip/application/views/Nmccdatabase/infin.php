<script src="http://localhost/NMCC/assets/vendor/jquery/jquery-3.2.1.min.js"></script> 

<section class="form-bg">
    <div class="container">
        <div class="row center">
            <div class=" col-md-10 col-xs-12">
                <form class="form-horizontal" action="" method="post">
                    <div class="form-content">
                    <?php echo $this->session->flashdata('response'); ?>  
                      <h2 class="text-center main-head">INFIN Structure</h2>
                        <h4 class="heading">Author/Person Isolating</h4>
                        <div class="form-group">
                        <div class="row">
                            <div class="col-sm-6 col-xs-12">
                               <input class="form-control" id="exampleInputName2" placeholder="First Name" name="firstname"  type="text">
                                <span class="help-block m-b-none"><?php echo form_error('firstname'); ?></span>
                            </div>
                            <div class="col-sm-6 col-xs-12">
                              <input class="form-control" id="exampleInputName2" placeholder="Last Name" name="lastname" type="text">
                              <span class="help-block m-b-none"><?php echo form_error('lastname'); ?></span>
                            </div>
                        </div></div>
                         <div class="form-group">
                        <div class="row">
                         
                            <div class="col-sm-6 col-xs-12">
                                
                                <input class="form-control" id="exampleInputName2" placeholder="Telephone" name="phonenumber" type="text">
                                <span class="help-block m-b-none"><?php echo form_error('phonenumber'); ?></span>
                            </div>
                            <div class="col-sm-6 col-xs-12">
                                
                                <input class="form-control" id="exampleInputName2" placeholder="Email" name="email" type="email">
                                <span class="help-block m-b-none"><?php echo form_error('firstname'); ?></span>
                            </div>
                        </div></div>
                        <div class="form-group">
                        <div class="row">
                          
                            <div class="col-sm-6 col-xs-12">
                                
                                <input class="form-control" id="exampleInputName2" placeholder="Affiliation" name="affilication" type="text">
                            </div>
                            <div class="col-sm-6 col-xs-12">     
                                <input class="form-control" id="exampleInputName2" placeholder="Name of Institution" name="institution_name" type="text">
                                <span class="help-block m-b-none"><?php echo form_error('institution_name'); ?></span>
                            </div>
                        </div></div>
                       
                        <h4 class="heading">Location of Institution</h4>
                        <div class="form-group"><div class="row">
                            <div class="col-sm-6 col-xs-12">    
                                <input class="form-control" id="exampleInputName2" placeholder="Address" name="institution_address" type="text">
                            </div>
 
                            <div class="col-sm-6 col-xs-12">
                               
                                <input class="form-control" id="exampleInputName2" placeholder="Address 2" name="institution_address2" type="text">
                            </div>
                        </div></div>
                        <div class="form-group">
                          <div class="row">
                            <div class="col-sm-3 col-xs-12">

                                      <select name="institution_country" class="form-control" onchange="getStates(this.value)">
                                                <option value="">Please Select</option>
                                                <?php 
                                                if(!empty($countries)){
                                                    foreach ($countries as $countrykey => $countryvalue) { ?>   
                                                    <option value="<?php echo $countryvalue['country_id']; ?>"><?php echo $countryvalue['name']; ?></option>
                                                
                                                <?php } } ?>
                                            </select>
                                            
                                            </div>
                                            <span class="help-block m-b-none"><?php echo form_error('country'); ?></span>
                                        
                                
                                <!-- <input class="form-control" id="exampleInputName2" placeholder="Country" name="institution_country" type="text">
                            </div> -->
                            <!-- <div class="col-sm-3 col-xs-12">
                                
                                <input class="form-control" id="exampleInputName2" placeholder="LGA" name="institution_city" type="text">
                            </div> -->
                            <div class="col-sm-3 col-xs-12">

                              <select name="institution_state" class="form-control" onchange="getZone(this.value)" id="select-state" >
                                                <option value="">Please Select</option>
                                               
                                            </select>
                                            
                                            
                                            <span class="help-block m-b-none"><?php echo form_error('state'); ?></span>
                                      
                                
                                <!-- <input class="form-control" id="exampleInputName2" placeholder="State" name="institution_state" type="text"> -->
                            </div>
 
                            <!-- <div class="col-sm-3 col-xs-12">
                                
                                <input class="form-control" id="exampleInputName2" placeholder="Country" name="institution_country" type="text">
                            </div> -->
                            <div class="col-sm-3 col-xs-12">

                              <select name="institution_city" id="select-lga" class="form-control">
                              <option value="">Select LGA</option>
                                                
                                </select>
                                
                                <!-- <input class="form-control" id="exampleInputName2" placeholder="LGA" name="institution_city" type="text"> -->
                            </div>
                            <div class="col-sm-3 col-xs-12">
                                
                                <input class="form-control" id="exampleInputName2" placeholder="Zip Code" name="institution_zipcode" type="text">
                            </div>
                        </div></div>
                        <div class="form-group">
                          <div class="row">
                            <div class="col-sm-12 ">
                                <select name="institution_type">
                                  <option value="">Type of Institution</option>
                                  <option value="University">University</option>
                                  <option value="Research Institution">Research Institution</option>
                                  <option value="Other-Government Institution">Other-Government Institution</option>
                                  <option value="Private Institution">Private Institution</option>
                                  <option value="Industry">Industry</option>
                                 </select>
                            </div>
                            
                        </div></div>
                           <div class="form-group">
                            <div class="row">
                                  <div class="col-sm-6 col-xs-12">
                                      <input class="form-control" name="isolation_reason" id="exampleInputName2" placeholder="Research study / Reason for Isolation" type="text">
                                  </div>
                                  <div class="col-sm-6 col-xs-12">
                                      <input class="form-control" name="journal_name" id="exampleInputName2" placeholder="Exact citation of Work if published" type="text">
                                  </div>
                              </div>
                            </div>
                    <h4 class="heading">Organisms</h4>
                   <div class="form-group"><div class="row">
                            <div class="col-sm-3 col-xs-12">
                                <input class="form-control" name="organisms_name1" id="othervalue1" placeholder="Enter Other Name">
                              <select class="form-control" name="organisms_name" id="originalvalue1">
                                <option value="">Select Organism</option>
                                <option value="Protozoan">Protozoan</option>
                                <option value="Fungus">Fungus</option>
                                <option value="Bacterium">Bacterium</option>
                                <option value="Virus">Virus</option>
                                <option value="Animal">Animal</option>
                                <option value="Plant">Plant</option>
                                <option value="other1">Other</option>
                              </select>
                            </div>
                             <div class="col-sm-3 col-xs-12">
                              <input class="form-control" name="characterization2" id="othervalue2" placeholder="Enter Other Name" type="text">
                              <select class="form-control" name="characterization" id="originalvalue2">
                                <option value="">Characterization</option>
                                <option value="No by Species">No by Species</option>
                                <option value="Sequencing by type/species">Sequencing by type/species</option>
                                <option value="identification level">identification level</option>
                                <option value="Preservation types">Preservation types</option>
                                <option value="Special Properties">Special Properties</option>
                                <option value="other2">Other</option>
                              </select> 
                            </div>
                             <div class="col-sm-3 col-xs-12">
                              <input class="form-control" name="applications3" id="othervalue3" placeholder="Enter Other Name" type="text">
                              <select class="form-control" name="applications" id="originalvalue3">
                                <option value="">Applications</option>
                                <option value="Bioassay">Bioassay</option>
                                <option value="Quality control">Quality control</option>
                                <option value="Resistance test">Resistance test</option>
                                <option value="Degradation">Degradation</option>
                                <option value="other3">Other</option>
                              </select> 
                            </div>
                             <div class="col-sm-3 col-xs-12">
                              <input class="form-control" name="other_associated4" id="othervalue4" placeholder="Enter Other Name" type="text">
                              <select class="form-control" name="other_associated" id="originalvalue4">
                                <option value="">Other Associated</option>
                                <option value="Intented">Intented</option>
                                <option value="Purpose For Isolation">Purpose For Isolation</option>
                                <option value="what Modifications">what Modifications</option>
                                <option value="other4">Other</option>
                              </select>
                            </div>
                        </div>
                      </div>
                        <div class="form-group"><div class="row">
                            <div class="col-sm-6 col-xs-12">
                                
                                <input class="form-control" name="organisms_address" id="exampleInputName2" placeholder="Address" type="text">
                            </div>
 
                            <div class="col-sm-6 col-xs-12">
                               
                                <input class="form-control" name="organisms_address2" id="exampleInputName2" placeholder="Address 2" type="text">
                            </div>
                        </div></div>
                        <div class="form-group">
                          <div class="row">

                          <div class="col-sm-3 col-xs-12">
                                
                                <select name="organisms_country" class="form-control" onchange="getStates2(this.value)">
                                                <option value="">Please Select</option>
                                                <?php 
                                                if(!empty($countries)){
                                                    foreach ($countries as $countrykey => $countryvalue) { ?>   
                                                    <option value="<?php echo $countryvalue['country_id']; ?>"><?php echo $countryvalue['name']; ?></option>
                                                
                                                <?php } } ?>
                                            </select>

                               <!--  <input class="form-control" id="exampleInputName2" placeholder="Country" name="organisms_country" type="text"> -->
                            </div>
                            <div class="col-sm-3 col-xs-12">

                              <select name="organisms_state" class="form-control" onchange="getZone2(this.value)" id="select-state2" >
                                                <option value="">Please Select</option>
                                               
                                            </select>
                                            
                                <!-- <input class="form-control" id="exampleInputName2" placeholder="State" name="organisms_state" type="text"> -->
                            </div>
                            <div class="col-sm-3 col-xs-12">
                              <select name="organisms_city" onchange="getCommunity(this.value)" id="select-lga2" class="form-control">
                              <option value="">Select LGA</option>
                                                
                                </select>
                                
                                <!-- <input class="form-control" id="exampleInputName2" placeholder="LGA" name="organisms_city" type="text"> -->
                            </div> 
                            <div class="col-sm-3 col-xs-12">

                               <select name="community" id="select-community" class="form-control">
                              <option value="">Select Community</option>
                                                
                                </select>
                                
                                <!-- <input class="form-control" id="exampleInputName2" placeholder="Community" name="community"  type="text"> -->
                            </div>
                        </div></div>
                        <div class="form-group"><div class="row">
                            <div class="col-sm-6 col-xs-12">
                                
                                <input class="form-control" id="exampleInputName2" placeholder="Biological Importance / Substrate or Host " type="text" name="biological_importance">
                            </div>
 
                            <div class="col-sm-6 col-xs-12">
                               
                                <input class="form-control" id="exampleInputName2" placeholder="" type="date" name="isolation_date">
                            </div>
                        </div></div>
                        <div class="form-group">
                          <div class="row">
                            <div class="col-sm-12 ">
                                <select name="isolation_method">
                                  <option value="">Method of Isolation</option>
                                  <option value="Conventional">Conventional</option>
                                  <option value="Molecular">Molecular</option>
                                 
                                 </select>
                            </div>
                            
                        </div></div>
                         <h4 class="heading">Depository</h4>
                        <div class="form-group"> <div class="row">
                            <div class="col-sm-6 col-xs-12">
                                
                                <input class="form-control" id="exampleInputName2" placeholder="Depositor" name="depositor" type="text">
                            </div>
 
                            <div class="col-sm-6 col-xs-12">
                               
                                <input class="form-control" id="exampleInputName2" placeholder="Person Identifying the Strain" name="strain" type="text">
                            </div>
                        </div></div>
                        <div class="form-group"><div class="row">
                            <div class="col-sm-6 col-xs-12">
                                
                                <input class="form-control" name="preservation_procedure" id="exampleInputName2" placeholder="Preservation Procedure" type="text">
                            </div>
 
                            <div class="col-sm-6 col-xs-12">
                               
                                <input class="form-control" id="exampleInputName2" placeholder="Optimal Growth Media" name="growth_media" type="text">
                            </div>
                        </div></div>
                        <div class="form-group">
                          <div class="row">
                            <div class="col-sm-12 ">
                                <select name="regulatory_conditions">
                                  <option value="">Regulatory Conditions</option>
                                  <option value="Quarantine">Quarantine</option>
                                  <option value="Containment Level">Containment Level</option>
                                 <option value="Patent Status">Patent Status</option>
                                 </select>
                            </div>
                            
                        </div></div>
                        <div class="form-group"><div class="row">
                            <div class="col-sm-6 col-xs-12">
                                
                                <input class="form-control" id="exampleInputName2" placeholder="Accession Number" name="accession_number" type="text">
                                
                            </div>
                            <div class="col-sm-6 col-xs-12">
                            <input class="form-control" id="exampleInputName2" placeholder="Other Relevant Information (Please specify)" type="text" name="other_information">
                            </div>
                               
 
                            
                        </div></div>
                       <div class="clearfix">
                        <div class="row center">
                        <div class="col-sm-3">
                            <button type="submit" class="btn btn-default "> Save</button></div></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>



<script type="text/javascript">
    function getZone(state_id){
      // alert(state_id);
       
        $.ajax({
              url:'<?php echo BASE_URL; ?>'+'nmccdatabase/getstatelga',
              data:{state_id:state_id},
              type: 'POST',
              success :function(data){
               console.log(data);
                $('#select-lga').html(data);
              }
        });
    }

     function getZone2(state_id){
      //alert(state_id);
       
        $.ajax({
              url:'<?php echo BASE_URL; ?>'+'nmccdatabase/getstatelga ',
              data:{state_id:state_id},
              type: 'POST',
              success :function(data){
               //console.log(data);
                $('#select-lga2').html(data);
              }
        });
    }

    function getCommunity(state_id){
      //alert(state_id);
       
        $.ajax({
              url:'<?php echo BASE_URL; ?>'+'nmccdatabase/getlgacommunity',
              data:{state_id:state_id},
              type: 'POST',
              success :function(data){
               //console.log(data);
                $('#select-community').html(data);
              }
        });
    }

    function getStates(country_id) {
       var target_url = '<?php echo BASE_URL; ?>'+'nmccdatabase/getajaxcountrystate';
        $.ajax({
              type: 'POST',
              url:target_url,
              data:{country_id:country_id},
             success :function(data){
                $('#select-state').html(data);
              }
        });
    }

    function getStates2(country_id) {
       var target_url = '<?php echo BASE_URL; ?>'+'nmccdatabase/getajaxcountrystate';
        $.ajax({
              type: 'POST',
              url:target_url,
              data:{country_id:country_id},
             success :function(data){
                $('#select-state2').html(data);
              }
        });
    }
</script>

<script>
$(document).ready(function(){
        $("#othervalue1").hide();

        $("#originalvalue1").change(function()
        {
        if($(this).val() == "other1")
        {
            $("#othervalue1").show();
        }
        else
        {
            $("#othervalue1").hide();
        }
      }).change();
           
});

$(document).ready(function(){
        $("#othervalue2").hide();

        $("#originalvalue2").change(function()
        {
        if($(this).val() == "other2")
        {
            $("#othervalue2").show();
        }
        else
        {
            $("#othervalue2").hide();
        }
      }).change();
           
});

$(document).ready(function(){
        $("#othervalue3").hide();

        $("#originalvalue3").change(function()
        {
        if($(this).val() == "other3")
        {
            $("#othervalue3").show();
        }
        else
        {
            $("#othervalue3").hide();
        }
      }).change();
           
});

$(document).ready(function(){
        $("#othervalue4").hide();

        $("#originalvalue4").change(function()
        {
        if($(this).val() == "other4")
        {
            $("#othervalue4").show();
        }
        else
        {
            $("#othervalue4").hide();
        }
      }).change();
           
});





              
</script>