<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">Database</h2>
      <div class=" breadcrumb">
        <a href="index.php" class="btn">Home</a>
        <span class="btn btn--rightBorder">Database</span>
      </div>
    </div>
  </header>
 <section class="form-mr comman-main" >
    <div class="container">
        <div class="row justify-center">
            <div class=" col-md-6">
                <div class="tab">
                        <div class="member-icon">
                          <i class="fa fa-user"></i>
                        </div>
                        <h3 class="member-head">Member Login</h3>
                            <form class="form-horizontal">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">username</label>
                                    <input type="email" class="form-control" id="exampleInputEmail1">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Password</label>
                                    <input type="password" class="form-control" id="exampleInputPassword1">
                                </div>
                                <div class="form-group">
                                    <div class="main-checkbox">
                                        <input value="None" id="checkbox1" name="check" type="checkbox">
                                        <label for="checkbox1"></label>
                                    </div>
                                    <span class="text">Remember me</span>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-default">Sign in</button>
                                </div>
                                <div class="form-group forgot-pass">
                                    <a href="forgot.php" class="btn btn-default">forgot password</a>
                                    <a href="register.php" class="btn btn-default">New Register Here</a>
                                </div>
                            </form>
                       
                </div>
            </div>
        </div>
    </div>

  </section>