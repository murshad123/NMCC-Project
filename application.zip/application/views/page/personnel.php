     <header class="hero-banner project-bg">
    <a class="navbar-brand" href="<?php echo BASE_URL; ?>">
      <img src="<?php echo ASSESTS_URL; ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">About Us</h2>
      <div class="btn-group breadcrumb">
        <a href="index.php" class="btn">Home</a>
        <span class="btn btn--rightBorder">About</span>
      </div>
    </div>
  </header>

  <section class="comman-main">
  	<div class="container">
  		<div class="row">
  			<div class="col-md-12">
  			<h2>Coming Soon..</h2>
  		</div>
  		</div>
  	</div>
  </section>