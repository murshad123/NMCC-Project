     <header class="hero-banner project-bg">
    <a class="navbar-brand" href="<?php echo BASE_URL; ?>">
      <img src="<?php echo ASSETS_URL; ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">About Us</h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">About</span>
      </div>
    </div>
  </header>

<section class="about ">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-5">
          <div class="about__img text-center text-md-left mb-5 mb-md-0">
            <img class="img-fluid" src="<?php echo ASSETS_URL; ?>img/about.png" alt="">
            
          </div>
        </div>
        <div class="col-md-7 pl-xl-5">
          <div class="section-intro">
            <h2 class="section-intro__subtitle">About us</h2>
          </div>
          <p>The Nigerian Microbial Culture Collections (NMCC) programme is funded mainly by the Federal Government of Nigeria through the National Biotechnology Development Agency (NABDA), an Agency under the Federal Ministry of Science and Technology (FMST), which is established to develop and apply biotechnology tools to enhance sustainable national development. The NMCC Programme is one of NABDA’s efforts aimed at characterisation, authentication, preservation, maintenance and distribution of microbial cultures to support of conservation and economic development”.</p>
          <h4>The key objectives are to:</h4>
          <ul>
            <li>Put in place a coordinated programme for acquisition, authentication, production, preservation of strain holdings and cataloguing of all microbial resources nationally.</li>
            <li>Develop and manage a depository for conserving all microbial genetic resources as may be available from Nigeria and other parts of the world.</li>
            <li>Provide authentic microbial cultures and genetic materials required for various applications.</li>
            <li>Provide data services, support training, research and such otherservices as may be required from time to time within and outside the community.</li>
          </ul>
        </div>
      </div>
    </div>
  </section>