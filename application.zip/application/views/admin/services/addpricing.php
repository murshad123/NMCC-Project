                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                        
                        <!-- END THEME PANEL -->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="<?php echo ADMIN_URL.'dashboard' ?>">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span>Services</span>
                                </li>
                                <li>
                                    <span>Add Pricing</span>
                                </li>
                                
                            </ul>


                            
                        </div>

                        <div class="pull-right">
                        <ol>
                        <div class="title-action">
                        <a href="<?php echo ADMIN_URL.'services/pricing' ?>" class="btn btn-primary">Back</a>
                       
                    </div></ol>
                        </div>


                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> Add Pricing 
                            <small>&nbsp;</small>
                        </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                        <!-- BEGIN DASHBOARD STATS 1-->
                        <div class="row">
                            
                     <div class="col-lg-12">
                    <div class="portlet light bordered">
                                    <div class="portlet-title">
                                              
                        <div class="ibox-content">
                            <?php echo form_open_multipart('admin/services/addpricing',array('class'=>'form-horizontal')); ?>
                                <?php echo $this->session->flashdata('response'); ?>
                                <div class="form-group"><label class="col-sm-2 control-label">Services</label>

                                    <div class="col-sm-10">
                                        <select name="service_id" class="form-control">
                                           <?php if(!empty($services)){
                                              foreach ($services as $serviceskey => $servicesvalue) { ?>
                                                  <option value="<?php echo $servicesvalue['id']; ?>"><?php echo $servicesvalue['name']; ?></option>
                                            <?php  }  } ?>    
                                        </select>  
                                        <span class="help-block m-b-none"><?php echo form_error('service_id'); ?></span>
                                    </div>
                                </div>

                                <div class="form-group"><label class="col-sm-2 control-label">Comment</label>
                                    <div class="col-sm-10 " >
                                          <input type="text" name="comment" class="form-control"  placeholder="comment" ></td>                                
                                    </div>
                                </div> 


                                <div class="form-group"><label class="col-sm-2 control-label">Description</label>

                                    <div class="col-sm-10 " >
                                          <textarea class="form-control" rows="5" placeholder="Description" name="description" ></textarea>                                    </div>
                                    </div>

                                <div class="form-group"><label class="col-sm-2 control-label">Status</label>
                                    <div class="col-sm-10 " >
                                          <select name="status" class="form-control">
                                              <option value="1">Active</option>
                                              <option value="2">Inactive</option>
                                          </select>                                 
                                    </div>
                                </div> 

                                <div class="form-group"><label class="col-sm-2 control-label">Items</label>
                                <div class="col-sm-10 " >
                                        <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Price</th> 
                                                <th>Description</th> 
                                                <th>&nbsp;&nbsp;</th>
                                               
                                            </tr>
                                        </thead>
                                            <tbody class="input_fields_wrap">
                                            
                                            <tr >
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td> 
                                                <td><button class="btn btn-primary" id="addmore" Title="Add More"  type="button"><i class="fa fa-plus-circle"></i></button></td>
                                               
                                            </tr>
                                           
                                            </tbody>
                                        </table>
                                    </div>       
                                    </div>       
                                
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>


$(document).ready(function() {
    var max_fields      = 20; 
    var wrapper         = $(".input_fields_wrap"); 
    //var add_button      = $("#addmore"); 
   
    var x = 0; 
    $("#addmore").click(function(e){ 
        
        e.preventDefault();
        if(x < max_fields){ 
            
            var name1 = "items["+x+"][name]";
            var name2 = "items["+x+"][price]";
            var name3 = "items["+x+"][description]";
            var triid = "tr"+x;
            //alert(name1);
           // $(wrapper).append("<tr id='"+triid+"' ><td><input type='ext' class='form-control' name='"+name1+"' placeholder='Filter Name' required/></td> <td><input type='number' min='0' value='0' class='form-control' name='"+name2+"' placeholder='Order'/></td><td><button class='btn btn-danger remove_field' onclick='removetr("+x+")' type='button' title='Remove'><i class='fa fa-minus-circle'></i></button></td></tr>"); //add input box
            $(wrapper).append("<tr id='"+triid+"' ><td><input type='text' class='form-control' name='"+name1+"' placeholder='Name' required/></td><td><input type='number' class='form-control' name='"+name2+"' placeholder='price' required/></td><td><textarea class='form-control' name='"+name3+"' placeholder='Description'></textarea></td> <td><button class='btn btn-danger remove_field' onclick='removetr("+x+")' type='button' title='Remove'><i class='fa fa-minus-circle'></i></button></td></tr>"); //add input box
             x++; 
        }
    });
   
    /*$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('tr').remove(); x--;
    })*/
});


function removetr(id){
    $('#tr'+id).remove();
}


  </script>
