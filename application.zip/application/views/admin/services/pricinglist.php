<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                   <span>Services</span>
                </li>
                <li>
                   <span>Item Pricing List</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                   <a href="<?php echo ADMIN_URL.'services/additempricing' ?>" class="btn btn-primary">Add</a>
                </div>
            </ol>
        </div>
           
        <h1 class="page-title"> Item Pricing List
            <small>&nbsp;</small>
        </h1>
                       
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>S.No.</th>
                                        <th>Item</th>
                                        <th>Price</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Created Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i = 1;
                                    foreach ($itemprincinglist as $itempricing) { ?>
                                    <tr>
                                        <td><?php echo  $i; ?></td>
                                        <td><?php echo $itempricing['item']; ?></td>
                                        <td><?php echo '$'.$itempricing['price']; ?></td>
                                        <td><?php echo $itempricing['comments']; ?></td>
                                        <td>
                                        <?php if($itempricing['status'] == '1'){ ?>
                                        <a href="javascript:void(0)" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a>
                                        <?php }else if($itempricing['status'] == '0'){?>
                                        <a href="<?php echo ADMIN_URL.'services/add' ?>" class="btn btn-danger"><i class="fa fa-thumbs-down" aria-hidden="true"></i></a>
                                        <?php } ?>
                                        </td>
                                        <td><?php echo $itempricing['added_date']; ?></td>
                                        <td> Edit | Delete</td>
                                     
                                    </tr>
                                    <?php $i++;} ?>     
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>