<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashoard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL.'customers' ?>" class="btn btn-primary"><span>Customers</span></a>
                </li>
                <li>
                    <span>Add Customer</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'customers' ?>" class="btn btn-primary">Back</a></div>
            </ol>
        </div>


        <h1 class="page-title"> Add Customer 
            <small>&nbsp;</small>
        </h1>
                        
        <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
                            <?php echo form_open_multipart('admin/customers/add',array('class'=>'form-horizontal')); ?>
                                <?php echo $this->session->flashdata('response'); ?>
                                <div><label class="col-sm-2 control-label">Personal Information</label></div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">First Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="First Name" name="firstname" type="text" value="<?php echo set_value('firstname'); ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('firstname'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">Last Name</label>
                                                <div class="col-sm-10"><input class="form-control" placeholder="Last Name" name="lastname" value="<?php echo set_value('lastname'); ?>" type="text"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                      <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Email</label>
                                            <div class="col-sm-10"><input class="form-control" name="email" type="text" placeholder="Email">
                                            <span class="help-block m-b-none"><?php echo form_error('email'); ?></span>
                                            </div>
                                          </div>
                                        </div>

                                        <!-- <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">DOB</label>
                                              <div class="col-sm-10"><input class="form-control" name="dateofbirth" type="text" placeholder="DOB"> </div>
                                            </div>
                                          </div> -->
                                        </div>
                                    </div>

                                
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Phone Number</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="phonenumber" type="text" placeholder="Phone Number" value="<?php echo set_value('phone_number'); ?>">
                                            <span class="help-block m-b-none"><?php echo form_error('firstname'); ?></span>
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Alternate Phone Number</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="alternatephonenumber" type="text" placeholder="Alternate Phone Number" value="<?php echo set_value('alternatephonenumber'); ?>">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div><label class="col-sm-2 control-label">Residentail Address</label></div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="residentails[address]" type="text" placeholder="Address" value="">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address 2</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="residentails[address2]" type="text" placeholder="Address 2" value="">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">City</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="residentails[city]" type="text" placeholder="City" value="">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">State</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="residentails[state]" type="text" placeholder="State" value="">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Zip</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="residentails[postal_code]" type="text" placeholder="City" value="">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <!-- <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Status</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="state" type="text" placeholder="State" value="<?php echo set_value('state'); ?>">    
                                            </div>
                                          </div>
                                        </div> -->
                                      </div>
                                </div>

                                <div><label class="col-sm-2 control-label">Billing Address</label></div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="billing[address]" type="text" placeholder="Address" value="">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address 2</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="billing[address2]" type="text" placeholder="Address 2" value="">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">City</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="billing[city]" type="text" placeholder="City" value="">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">State</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="billing[state]" type="text" placeholder="State" value="">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Zip</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="billing[postal_code]" type="text" placeholder="City" value="">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <!-- <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Status</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="state" type="text" placeholder="State" value="<?php echo set_value('state'); ?>">    
                                            </div>
                                          </div>
                                        </div> -->
                                      </div>
                                </div>

                                <div><label class="col-sm-2 control-label">Payment Details</label></div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Card Number</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="cardnumber" type="text" placeholder="Card Number" value="<?php echo set_value('city'); ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">CVV</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="cvv" type="text" placeholder="State" value="<?php echo set_value('state'); ?>">    
                                            </div>
                                          </div>
                                        </div> 
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Exipry Month</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="expirymonth" type="text" placeholder="City" value="<?php echo set_value('city'); ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Exipry year</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="expiryyear" type="text" placeholder="State" value="<?php echo set_value('state'); ?>">    
                                            </div>
                                          </div>
                                        </div> 
                                      </div>
                                </div>
                                

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Notification</label>

                                            <div class="col-sm-10">
                                            <select name="email_notification" class="form-control">
                                                <option value="1">Yes</option>
                                                <option value="0">No</option>
                                            </select>
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Status</label>

                                            <div class="col-sm-10">
                                                <select name="status" class="form-control">
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                            </select>    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>


                                    
                                
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>