<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'authors' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Authors</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                   <a href="<?php echo ADMIN_URL.'authors/add' ?>" class="btn btn-primary">Add</a>
                </div>
            </ol>
        </div>

        <h1 class="page-title"> Authors List
            <small>&nbsp;</small>
        </h1>
          <?php echo $this->session->flashdata('response'); ?>              
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">

                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>S.No.</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone Number</th>
                                        <!-- <th>Institution Name</th> -->
                                        <th>Added Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
                                    $i = 1;
                                    foreach ($authors as $authorslist) { ?>
                                    <tr>
                                        <td> <?php echo $i; ?> </td>
                                        <td> <?php echo ucfirst($authorslist['name']); ?> </td>
                                        <td> <?php echo $authorslist['email']; ?> </td>
                                        <td> <?php echo $authorslist['phonenumber']; ?> </td>
                                        <!-- <td> <?php echo $authorslist['institution_name']; ?> </td> -->
                                        
                                        <td> <?php echo date('d/m/Y' ,strtotime($authorslist['created_date'])); ?> </td>

                                        <!-- <td><a href="javascript:void(0)" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a></td> -->
                                        <td><?php if($authorslist['status'] == '1'){ ?>
                                        <a href="<?=ADMIN_URL?>authors/updateStatus/deactive/<?=$authorslist['id'];?>" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a>
                                        <?php }else if($authorslist['status'] == '0'){ ?>
                                        <a href="<?=ADMIN_URL?>authors/updateStatus/active/<?=$authorslist['id'];?>" class="btn btn-danger"><i class="fa fa-thumbs-down" aria-hidden="true"></i></a>
                                        <?php } ?> </td> 
                                        
                                        <td> <a href="<?php echo ADMIN_URL.'authors/view/'.$authorslist['id'] ?>" class="btn btn-primary"><i class="fa fa-eye" aria-hidden="true"></i></a>|  <a href="<?php echo ADMIN_URL.'authors/edit/'.$authorslist['id'] ?>" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a> | <a href="javascript:void(0)" onclick="checkdelete('<?php echo $authorslist['id']; ?>')" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>

                                        <!-- <a href="javascript:void(0)" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a> | <a href="javascript:void(0)" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a> -->
                                     </td>
                                    </tr>
                                    <?php $i++; } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<script type="text/javascript">
    function checkdelete(id) {
        var url = '<?php echo  ADMIN_URL.'authors/delete/'; ?>';
        if (confirm('Are you sure to delete ?')) {
           window.location.href = url+id;
        } else {
           return false;
        }
        
    }
</script>