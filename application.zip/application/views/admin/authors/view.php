<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Authors</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                   <a href="<?php echo ADMIN_URL.'authors' ?>" class="btn btn-primary">Back</a>
                </div>
            </ol>
        </div>

        <h1 class="page-title"> Authors Details
            <small>&nbsp;</small>
        </h1>

        
                       
        <div class="row">
            <div class="col-md-6">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                               <thead><tr><th>Personal Details</th></tr></thead>
                                <tbody>
                                    <tr>
                                        <td>Name :</td>
                                        <td><?php echo $authors['name']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Email : </td>
                                        <td><?php echo  $authors['email']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Phone Number : </td>
                                        <td><?php echo  $authors['phonenumber']; ?></td>
                                    </tr>

                                    <tr>
                                        <td>Status : </td>
                                        <td><?php   if($authors['status'] == 1 ){ echo "Active"; }else{ echo "Inactive"; } ?></td>
                                    </tr>

                                    <tr>
                                        <td>Affiliation : </td>
                                        <td><?php echo  $authors['affilication']; ?></td>
                                    </tr>

                                     <tr>
                                        <td>Added Date : </td>
                                        <td><?php echo  date('d/m/Y',strtotime($authors['created_date'])); ?></td>
                                    </tr>

                                    
                                    </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                               <thead><tr><th>Institution Details</th></tr></thead>
                                <tr>
                                        <td>Institution  Name: </td>
                                        <td><?php echo  $authors['institution_name']; ?></td>
                                    </tr>

                                    <tr>
                                        <td>Institution Location : </td>
                                        <td><?php echo  $authors['institution_address']." ".$authors['institution_address2']; ?><br/>
                                        <?php echo $authors['institution_city']." ".$authors['institution_state']; ?><br/>
                                        <?php echo $authors['institution_country']." ".$authors['institution_zipcode']; ?>


                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Institution Type: </td>
                                        <td><?php echo  $authors['institution_type']; ?></td>
                                    </tr>

                                    <tr>
                                        <td>Isolation Reason: </td>
                                        <td><?php echo  $authors['isolation_reason']; ?></td>
                                    </tr>

                                    <tr>
                                    <td>Journal Name </td>
                                    <td><?php echo $authors['institution_country']; ?></td>
                                </tr>
                                
                          
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                               <thead><tr><th>Organisms Details</th></tr></thead>
                                <tr>
                                    <td>Organisms Name</td>
                                    <td><?php echo $authors['organisms_name']; ?></td>
                                </tr>

                                <tr>
                                    <td>Organisms Address</td>
                                    <td><?php echo  $authors['organisms_address']." ".$authors['organisms_address2']; ?><br/>
                                        <?php echo $authors['organisms_city']." ".$authors['organisms_state']; ?><br/>
                                        <?php echo $authors['organisms_country']; ?></td>
                                </tr>

                                <tr>
                                    <td>Community</td>
                                    <td><?php echo $authors['community']; ?></td>
                                </tr>

                                <tr>
                                    <td>Biological </td>
                                    <td><?php echo $authors['biological_importance']; ?></td>
                                </tr>

                                <tr>
                                    <td>Isolation Date </td>
                                    <td><?php echo $authors['isolation_date']; ?></td>
                                </tr>

                                <tr>
                                    <td>Isolation Method </td>
                                    <td><?php echo $authors['isolation_method']; ?></td>
                                </tr>

                                
                          
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                               <thead><tr><th>Depository</th></tr></thead>
                                <tr>
                                    <td>Depositor</td>
                                    <td><?php echo $authors['depositor']; ?></td>
                                </tr>

                                <tr>
                                    <td>Person Identifiny the Strain</td>
                                    <td><?php echo $authors['strain']; ?></td>
                                </tr>

                                <tr>
                                    <td>Preservation Procedure </td>
                                    <td><?php echo $authors['preservation_procedure']; ?></td>
                                </tr>

                                <tr>
                                    <td>Optimal Growth Media </td>
                                    <td><?php echo $authors['growth_media']; ?></td>
                                </tr>

                                <tr>
                                    <td>Regulatory Conditions </td>
                                    <td><?php echo $authors['regulatory_conditions']; ?></td>
                                </tr>

                                <tr>
                                    <td>Accession Number </td>
                                    <td><?php echo $authors['accession_number']; ?></td>
                                </tr>

                                <tr>
                                    <td>Other Relevant Information </td>
                                    <td><?php echo $authors['other_information']; ?></td>
                                </tr>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="clearfix"></div>
    </div>
</div>