<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashoard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL.'authors' ?>" ><span>Authors</span></a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Edit Authors</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'authors' ?>" class="btn btn-primary">Back</a></div>
            </ol>
        </div>


        <h1 class="page-title"> Edit Authors
            <small>&nbsp;</small>
        </h1>
                        
        <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
                             <form action="<?php echo ADMIN_URL.'authors/edit/'.$author_id;?>" class="form-horizontal" method="post" accept-charset="utf-8">
                                <?php echo $this->session->flashdata('response'); ?>
                                <div class="text-center"><label>Personal Information</label></div><br/>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">First Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="First Name" name="name" type="text" value="<?php echo $authors['name']; ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('name'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">Last Name</label>
                                                <div class="col-sm-10"><input class="form-control" placeholder="Last Name" name="last_name" value="<?php echo $authors['last_name']; ?>" type="text"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                      <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Phone Number</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="phonenumber" type="text" placeholder="Phone Number" value="<?php echo $authors['phonenumber']; ?>">
                                            <span class="help-block m-b-none"><?php echo form_error('phonenumber'); ?></span>
                                            </div>
                                          </div>
                                        </div>

                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Email</label>
                                            <div class="col-sm-10"><input class="form-control" name="email" type="text" placeholder="Email" value="<?php echo $authors['email']; ?>">
                                            <span class="help-block m-b-none"><?php echo form_error('email'); ?></span>
                                            </div>
                                          </div>
                                        </div>
                                        </div>
                                    </div>

                                
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Affiliation</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="affilication" type="text" placeholder="Affiliation" value="<?php echo $authors['affilication']; ?>"
                                            <span class="help-block m-b-none"><?php echo form_error('affilication'); ?></span>
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Name of Institution</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="institution_name" type="text" placeholder="Name of Institution" value="<?php echo $authors['institution_name']; ?>">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div><br/>

                                <div class="text-center"><label>Location Of Institution</label></div><br/>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="institution_address" type="text" placeholder="Address" value="<?php echo $authors['institution_address']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address 2</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="institution_address2" type="text" placeholder="Address 2" value="<?php echo $authors['institution_address2']; ?>">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">LGA</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="institution_city" type="text" placeholder="LGA" value="<?php echo $authors['institution_city']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">State</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="institution_state" type="text" placeholder="State" value="<?php echo $authors['institution_state']; ?>">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Country</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="institution_country" type="text" placeholder="Country" value="<?php echo $authors['institution_country']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Zip Code</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="institution_zipcode" type="text" placeholder="Zip Code" value="<?php echo $authors['institution_zipcode']; ?>">    
                                            </div>
                                          </div>
                                        </div> 
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Type of Institution</label>

                                            <div class="col-sm-10">
                                            <select class="form-control" name="institution_type">
                                              <option value="<?php echo $authors['institution_type']; ?>">Type of Institution</option>
                                              <option value="University">University</option>
                                              <option value="Research Institution">Research Institution</option>
                                              <option value="Other-Government Institution">Other-Government Institution</option>
                                              <option value="Private Institution">Private Institution</option>
                                              <option value="Industry">Industry</option>
                                            </select>
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Research Study</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="isolation_reason" type="text" placeholder="Research study / Reason for Isolation" value="<?php echo $authors['isolation_reason']; ?>">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Exact Situation</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="journal_name" type="text" placeholder="Exact Situation of Work if published" value="<?php echo $authors['journal_name']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <!-- <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">State</label>
                                        
                                            <div class="col-sm-10">
                                                <input class="form-control" name="billing[state]" type="text" placeholder="State" value="">    
                                            </div>
                                          </div> -->
                                        </div>
                                      </div>
                                </div>
                                 <br/><br/>
                               
                                <div class="text-center"><label>Organisms</label></div><br/>
                               

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Organisms</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="organisms_name" type="text" placeholder="Name" value="<?php echo $authors['organisms_name']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="  organisms_address" type="text" placeholder="Address" value="<?php echo $authors['organisms_address']; ?>">    
                                            </div>
                                          </div>
                                        </div> 
                                      </div>
                                </div><br>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address2</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="organisms_address2" type="text" placeholder="Address2" value="<?php echo $authors['organisms_address2']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Country</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="organisms_country" type="text" placeholder="Country" value="<?php echo $authors['organisms_country']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        </div> 
                                      </div>
                                </div>
                                

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">State</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="organisms_state" type="text" placeholder="State" value="<?php echo $authors['organisms_state']; ?>">    
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">LGA</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="organisms_city" type="text" placeholder="LGA" value="<?php echo $authors['organisms_city']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        </div>
                                      </div><br/>

                                      <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Community</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="  community" type="text" placeholder="Community" value="<?php echo $authors['community']; ?>">    
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Biological Importance</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="biological_importance" type="text" placeholder="Biological Importance / Substrate or Host " value="<?php echo $authors['biological_importance']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        </div>
                                      </div>

                                      <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Date</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="  isolation_date" type="date" placeholder="Community" value="<?php echo $authors['isolation_date']; ?>">    
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Method of Isolation</label>
                                            <div class="col-sm-10">
                                            <select class="form-control" name="isolation_method">
                                            <option value="<?php echo $authors['isolation_method']; ?>">Method of Isolation</option>
                                            <option value="Conventional">Conventional</option>
                                            <option value="Molecular">Molecular</option>
                                           </select>
                                            </div>
                                          </div>
                                        </div>
                                        </div>
                                      </div><br/>
                                     
                                     <div class="text-center"><label class="text-center" class="col-sm-2 control-label">Depository</label></div><br/>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Depositor</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="depositor" type="text" placeholder="Depositor"value="<?php echo $authors['depositor']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Person Identifying</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="strain" type="text" placeholder="Person Identifying the Strain" value="<?php echo $authors['strain']; ?>">    
                                            </div>
                                          </div>
                                        </div> 
                                      </div>
                                </div><br>


                                   <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Preservation Procedure</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="  preservation_procedure" type="text" placeholder="Preservation Procedure" value="<?php echo $authors['preservation_procedure']; ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Optimal Growth Media</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="growth_media" type="text" placeholder="Optimal Growth Media" value="<?php echo $authors['growth_media']; ?>">    
                                            </div>
                                          </div>
                                        </div> 
                                      </div>
                                </div><br>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Regulatory Conditions</label>

                                            <div class="col-sm-10">
                                             <select class="form-control" name="regulatory_conditions">
                                              <option value="<?php echo $authors['regulatory_conditions']; ?>">Regulatory Conditions</option>
                                              <option value="Quarantine">Quarantine</option>
                                              <option value="Containment Level">Containment Level</option>
                                             <option value="Patent Status">Patent Status</option>
                                             </select>
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Accession Number</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="accession_number" type="text" placeholder="Accession Number" value="<?php echo $authors['accession_number']; ?>">    
                                            </div>
                                          </div>
                                        </div> 
                                      </div>
                                </div><br>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Other Relevant Information</label>

                                            <div class="col-sm-10">
                                             <input class="form-control" name="other_information" type="text" placeholder="Other Relevant Information (Please specify)" value="<?php echo $authors['other_information']; ?>">  
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div><br>


                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <input class="btn btn-primary" type="submit" name="submit" value="Update">
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>