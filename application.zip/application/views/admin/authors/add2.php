<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashoard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL.'customers' ?>" class="btn btn-primary"><span>Customers</span></a>
                </li>
                <li>
                    <span>Add Customer</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'customers' ?>" class="btn btn-primary">Back</a></div>
            </ol>
        </div>


        <h1 class="page-title"> Add Customer 
            <small>&nbsp;</small>
        </h1>
                        
        <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
                            <?php echo form_open_multipart('admin/customers/add',array('class'=>'form-horizontal')); ?>
                                <?php echo $this->session->flashdata('response'); ?>
                                <div><label class="col-sm-2 control-label">Personal Information</label></div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">First Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="First Name" name="firstname" type="text" value="<?php echo set_value('firstname'); ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('firstname'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">Last Name</label>
                                                <div class="col-sm-10"><input class="form-control" placeholder="Last Name" name="lastname" value="<?php echo set_value('lastname'); ?>" type="text"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                      <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Phone Number</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="phonenumber" type="text" placeholder="Phone Number" value="<?php echo set_value('phone_number'); ?>">
                                            <span class="help-block m-b-none"><?php echo form_error('firstname'); ?></span>
                                            </div>
                                          </div>
                                        </div>

                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Email</label>
                                            <div class="col-sm-10"><input class="form-control" name="email" type="text" placeholder="Email">
                                            <span class="help-block m-b-none"><?php echo form_error('email'); ?></span>
                                            </div>
                                          </div>
                                        </div>
                                        </div>
                                    </div>

                                
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Affiliation</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="affilication" type="text" placeholder="Affiliation" value="<?php echo set_value('affilication'); ?>">
                                            <span class="help-block m-b-none"><?php echo form_error('affilication'); ?></span>
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Name of Institution</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="institution_name" type="text" placeholder="Name of Institution" value="<?php echo set_value('institution_name'); ?>">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div><label class="col-sm-2 control-label">Location Of Institution</label></div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="residentails[address]" type="text" placeholder="Address" value="">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address 2</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="residentails[address2]" type="text" placeholder="Address 2" value="">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">LGA</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="city" type="text" placeholder="LGA" value="">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">State</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="institution_state" type="text" placeholder="State" value="">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Country</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="institution_country" type="text" placeholder="Country" value="">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Zip Code</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="institution_zipcode" type="text" placeholder="Zip Code" value="<?php echo set_value('institution_zipcode'); ?>">    
                                            </div>
                                          </div>
                                        </div> 
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Type of Institution</label>

                                            <div class="col-sm-10">
                                            <select class="form-control" name="institution_type">
                                              <option value="">Type of Institution</option>
                                              <option value="University">University</option>
                                              <option value="Research Institution">Research Institution</option>
                                              <option value="Other-Government Institution">Other-Government Institution</option>
                                              <option value="Private Institution">Private Institution</option>
                                              <option value="Industry">Industry</option>
                                            </select>
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Research Study</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="billing[address2]" type="text" placeholder="Research study / Reason for Isolation" value="">    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Exact Situation</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="billing[city]" type="text" placeholder="Exact Situation of Work if published" value="">
                                            </div>
                                          </div>
                                        </div>
                                        
                                        <!-- <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">State</label>
                                        
                                            <div class="col-sm-10">
                                                <input class="form-control" name="billing[state]" type="text" placeholder="State" value="">    
                                            </div>
                                          </div> -->
                                        </div>
                                      </div>
                                </div>
                                 <br/><br/>
                               

                               <h4 class="heading">Organisms</h4>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Organisms</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="Organisms" type="text" placeholder="Name" value="<?php echo set_value('Organisms'); ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="cvv" type="text" placeholder="Address" value="<?php echo set_value('state'); ?>">    
                                            </div>
                                          </div>
                                        </div> 
                                      </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Address2</label>

                                            <div class="col-sm-10">
                                            <input class="form-control" name="expirymonth" type="text" placeholder="Address2" value="<?php echo set_value('city'); ?>">
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Country</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="institution_country" type="text" placeholder="Country" value="">
                                            </div>
                                          </div>
                                        </div>
                                        </div> 
                                      </div>
                                </div>
                                

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">State</label>

                                            <div class="col-sm-10">
                                                <input class="form-control" name="institution_state" type="text" placeholder="State" value="">    
                                            </div>
                                          </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">LGA</label>
                                            <div class="col-sm-10">
                                            <input class="form-control" name="city" type="text" placeholder="LGA" value="">
                                            </div>
                                          </div>
                                        </div>
                                        </div>
                                      </div>
                                </div>


                                    
                                
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>