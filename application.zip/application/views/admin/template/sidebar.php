<?php
    $this->db->select('*');
    $query = $this->db->get('continents');
    if($query->num_rows()){
       $regoins =  $query->result_array();
    }else {
        $regoins = array();
    }

    ?>

<ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
                        
    <li class="nav-item start active open">
        <a href="<?= ADMIN_URL ?>dashboard" class="nav-link nav-toggle">
            <i class="icon-home"></i>
            <span class="title">Dashboard</span>
            <span class="selected"></span>
            <span class="arrow open"></span>
        </a>
    </li>

    <li class="nav-item  ">
        <a href="<?= ADMIN_URL ?>members" class="nav-link nav-toggle">
            <i class="icon-user"></i>
            <span class="title">Members</span>
            <span class="arrow"></span>
        </a>
    </li>

    <li class="nav-item  ">
        <a href="<?= ADMIN_URL ?>personnel" class="nav-link nav-toggle">
            <i class="icon-user"></i>
            <span class="title">Personnel</span>
            <span class="arrow"></span>
        </a>
    </li>

   

    <li class="nav-item  ">
        <a href="<?= ADMIN_URL ?>authors" class="nav-link nav-toggle">
            <i class="icon-user"></i>
            <span class="title">Authors</span>
            <span class="arrow"></span>
        </a>
    </li>

     <li class="nav-item  ">
        <a href="javascript:;" class="nav-link nav-toggle">
            <i class="icon-social-dribbble"></i>
            <span class="title">Events</span>
            <span class="arrow"></span>
        </a>
        <ul class="sub-menu">
            <li class="nav-item  ">
                <a href="javascript:;" class="nav-link nav-toggle">
            <i class="icon-social-dribbble"></i>
            <span class="title">Seminar/Workshop</span>
            <span class="arrow"></span>
             </a>
                
                <ul class="sub-menu">
                     <li class="nav-item  ">
                        <a href="<?= ADMIN_URL ?>events/currentevents" class="nav-link ">
                        <i class="icon-info"></i>
                        <span class="title">Current Events</span>
                        </a>
                      </li>
                       <li class="nav-item  ">
                        <a href="<?= ADMIN_URL ?>events/pastevents" class="nav-link ">
                        <i class="icon-info"></i>
                        <span class="title">Events Archive</span>
                        </a>
                     </li>                  
                </ul>
            </li> 

            <li class="nav-item  ">
                <a href="javascript:;" class="nav-link nav-toggle">
            <i class="icon-social-dribbble"></i>
            <span class="title">News</span>
            <span class="arrow"></span>
             </a>
                
                <ul class="sub-menu">
                     <li class="nav-item  ">
                        <a href="<?= ADMIN_URL ?>news/currentnews" class="nav-link ">
                        <i class="icon-info"></i>
                        <span class="title">Current News</span>
                        </a>
                      </li>
                       <li class="nav-item  ">
                        <a href="<?= ADMIN_URL ?>news/pastnews" class="nav-link ">
                        <i class="icon-info"></i>
                        <span class="title">News Archive</span>
                        </a>
                     </li>                  
                </ul>
            </li> 
            <!-- <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>news" class="nav-link ">
                    <i class="icon-call-end"></i>
                    <span class="title">News</span>
                </a>
            </li> -->
         
        </ul>
    </li> 

    <li class="nav-item  ">
        <a href="javascript:;" class="nav-link nav-toggle">
            <i class="icon-social-dribbble"></i>
            <span class="title">Regions</span>
            <span class="arrow"></span>
        </a>
        <ul class="sub-menu">

            <?php 
            if(!empty($regoins)){
               foreach ($regoins as $regoinskey => $regoinsvalue) {
                $href_url = ADMIN_URL.'regions/countries/'.$regoinsvalue['code'];
                   ?>
                   <li class="nav-item  ">
                <a href="<?php echo $href_url; ?>" class="nav-link ">
                    <i class="icon-info"></i>
                    <span class="title"><?php echo $regoinsvalue['name']; ?> </span>
                </a>
            </li>

            <?php    } } ?>
           
           <!--  <li class="nav-item  ">
               <a href="<?= ADMIN_URL ?>regions/otherregion" class="nav-link ">
                   <i class="icon-info"></i>
                   <span class="title">Other Region</span>
               </a>
           </li> -->
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>regions/nigeriancommunity" class="nav-link ">
                    <i class="icon-info"></i>
                    <span class="title">Communities</span>
                </a>
            </li>
          <!--   <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>general/banner" class="nav-link ">
                    <i class="icon-call-end"></i>
                    <span class="title">Other Regions</span>
                </a>
            </li>
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>general/faq" class="nav-link ">
                    <i class="icon-wrench"></i>
                    <span class="title">Acronyms</span>
                </a>
            </li>  -->
        </ul>
    </li>

     <li class="nav-item  ">
        <a href="" class="nav-link nav-toggle">
            <i class="icon-social-dribbble"></i>
            <span class="title">Basic Statistics</span>
            <span class="arrow"></span>
        </a>
         <ul class="sub-menu">
            <li class="nav-item  ">
                 <a href="<?= ADMIN_URL ?>basicStatistics/countries" class="nav-link nav-toggle">
                    <i class="icon-info"></i>
                    <span class="title">All Cultures</span>
                    <span class="arrow"></span>
                </a>
            </li>
            <li class="nav-item  ">
                 <a href="<?= ADMIN_URL ?>basicStatistics/straincultures" class="nav-link nav-toggle">
                    <i class="icon-info"></i>
                    <span class="title">Add Strains</span>
                    <span class="arrow"></span>
                </a>
            </li>
         </ul>
    </li>
     <!-- <li class="nav-item  ">
        <a href="javascript:;" class="nav-link nav-toggle">
            <i class="icon-social-dribbble"></i>
            <span class="title">Basic Statistics</span>
            <span class="arrow"></span>
        </a>
        <ul class="sub-menu">
            <li class="nav-item  ">
                 <a href="<?= ADMIN_URL ?>basicStatistics/countries" class="nav-link nav-toggle">
                    <i class="icon-info"></i>
                    <span class="title">Country</span>
                    <span class="arrow"></span>
                </a>
            </li>
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>basicStatistics/culturesHeld" class="nav-link ">
                    <i class="icon-info"></i>
                    <span class="title">Cultures Held</span>
                    <span class="arrow"></span>
                </a>
            </li>
            <li class="nav-item  ">
               <a href="<?= ADMIN_URL ?>basicStatistics/cultureCollection" class="nav-link nav-toggle">
               <i class="icon-info"></i>
                <span class="title">Culture Collections</span>
                <span class="arrow"></span>
              </a>
            </li> 
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>basicStatistics/numberCultureState" class="nav-link ">
                    <i class="icon-info"></i>
                    <span class="title">Numbers of culture</span>
                    <span class="arrow"></span>
                </a>
            </li> 
            <li class="nav-item  ">
               <a href="<?= ADMIN_URL ?>basicStatistics/serviceProvidedByState" class="nav-link nav-toggle">
               <i class="icon-info"></i>
                <span class="title">Service Provided</span>
                <span class="arrow"></span>
              </a>
            </li> 
            <li class="nav-item  ">
               <a href="<?= ADMIN_URL ?>basicStatistics/rankStrainByState" class="nav-link nav-toggle">
              <i class="icon-info"></i>
                <span class="title">Rank of strain</span>
                <span class="arrow"></span>
              </a>
            </li> 
        </ul>
         </li>  -->



    <li class="nav-item  ">
        <a href="javascript:;" class="nav-link nav-toggle">
            <i class="icon-social-dribbble"></i>
            <span class="title">General</span>
            <span class="arrow"></span>
        </a>
        <ul class="sub-menu">
           <!--  <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>general/cms" class="nav-link ">
                    <i class="icon-info"></i>
                    <span class="title">CMS</span>
                </a>
            </li> -->
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>admingeneral/inquiry" class="nav-link ">
                    <i class="icon-call-end"></i>
                    <span class="title">Inquiry</span>
                </a>
            </li>
            <li class="nav-item  ">
               <a href="<?= ADMIN_URL ?>acronyms" class="nav-link nav-toggle">
                <i class="icon-social-dribbble"></i>
                <span class="title">Acronyms</span>
                <span class="arrow"></span>
              </a>
            </li> 
           <!--  <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>general/faq" class="nav-link ">
                    <i class="icon-wrench"></i>
                    <span class="title">FAQ</span>
                </a>
            </li>  -->
        </ul>
    </li> 

</ul>