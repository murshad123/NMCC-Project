<ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
                        
    <li class="nav-item start active open">
        <a href="<?= ADMIN_URL ?>dashboard" class="nav-link nav-toggle">
            <i class="icon-home"></i>
            <span class="title">Dashboard</span>
            <span class="selected"></span>
            <span class="arrow open"></span>
        </a>
    </li>

    <li class="nav-item  ">
        <a href="<?= ADMIN_URL ?>members" class="nav-link nav-toggle">
            <i class="icon-user"></i>
            <span class="title">Members</span>
            <span class="arrow"></span>
        </a>
    </li>

    <li class="nav-item  ">
        <a href="<?= ADMIN_URL ?>personnel" class="nav-link nav-toggle">
            <i class="icon-user"></i>
            <span class="title">Personnel</span>
            <span class="arrow"></span>
        </a>
    </li>

   

    <li class="nav-item  ">
        <a href="<?= ADMIN_URL ?>authors" class="nav-link nav-toggle">
            <i class="icon-user"></i>
            <span class="title">Authors</span>
            <span class="arrow"></span>
        </a>
    </li>

     <li class="nav-item  ">
        <a href="javascript:;" class="nav-link nav-toggle">
            <i class="icon-social-dribbble"></i>
            <span class="title">Events</span>
            <span class="arrow"></span>
        </a>
        <ul class="sub-menu">
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>events" class="nav-link ">
                    <i class="icon-info"></i>
                    <span class="title">Seminar/Workshop</span>
                </a>
            </li> 
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>news" class="nav-link ">
                    <i class="icon-call-end"></i>
                    <span class="title">News</span>
                </a>
            </li>
         
        </ul>
    </li> 

    <li class="nav-item  ">
        <a href="javascript:;" class="nav-link nav-toggle">
            <i class="icon-social-dribbble"></i>
            <span class="title">Regions</span>
            <span class="arrow"></span>
        </a>
        <ul class="sub-menu">
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>regions/otherregion" class="nav-link ">
                    <i class="icon-info"></i>
                    <span class="title">Other Regions</span>
                </a>
            </li>
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>regions/nigeriancommunity" class="nav-link ">
                    <i class="icon-info"></i>
                    <span class="title">Communities</span>
                </a>
            </li>
          <!--   <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>general/banner" class="nav-link ">
                    <i class="icon-call-end"></i>
                    <span class="title">Other Regions</span>
                </a>
            </li>
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>general/faq" class="nav-link ">
                    <i class="icon-wrench"></i>
                    <span class="title">Acronyms</span>
                </a>
            </li>  -->
        </ul>
    </li>



    <li class="nav-item  ">
        <a href="javascript:;" class="nav-link nav-toggle">
            <i class="icon-social-dribbble"></i>
            <span class="title">General</span>
            <span class="arrow"></span>
        </a>
        <ul class="sub-menu">
           <!--  <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>general/cms" class="nav-link ">
                    <i class="icon-info"></i>
                    <span class="title">CMS</span>
                </a>
            </li> -->
            <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>admingeneral/inquiry" class="nav-link ">
                    <i class="icon-call-end"></i>
                    <span class="title">Inquiry</span>
                </a>
            </li>
           <!--  <li class="nav-item  ">
                <a href="<?= ADMIN_URL ?>general/faq" class="nav-link ">
                    <i class="icon-wrench"></i>
                    <span class="title">FAQ</span>
                </a>
            </li>  -->
        </ul>
    </li> 

</ul>