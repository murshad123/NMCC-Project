<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashboard'; ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Events</span>
                </li>
            </ul>
        </div>

        <?php 
        if($event_time == 1){
            $eventstimes = 'Past';
            $eventreturnurl = ADMIN_URL.'events/pastevents';
        }else if($event_time == 2){
            $eventstimes = 'Current';
            $eventreturnurl = ADMIN_URL.'events/currentevents';
        } ?>

        <div class="pull-right">
            <ol>
            <div class="title-action">
            <a href="<?php echo $eventreturnurl; ?>" class="btn btn-primary">Back</a>      
            </div>
            </ol>
        </div>

        

        <h1 class="page-title"> Add <?php echo $eventstimes; ?> Event 
            <small>&nbsp;</small>
        </h1>
                    
        <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
                            <?php 
                            $addurl = ADMIN_URL.'events/add/'.$event_time;

                            echo form_open_multipart($addurl,array('class'=>'form-horizontal')); ?>
                                <?php echo $this->session->flashdata('response'); ?>

                                <div class="row">
                                <div class="col-md-12">
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Title</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" placeholder="Event Title" name="event_name" type="text" value="<?php echo set_value('event_name'); ?>" required>
                                        <span class="help-block m-b-none"><?php echo form_error('event_name'); ?></span>
                                    </div>
                                </div>
                                </div>

                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Event Type</label>
                                    <div class="col-sm-10">
                                        <select id='dropdown' name="event_type" class="form-control" onchange="getduration(this.value)">
                                            <option value="">Select Event</option>
                                            <option value="1">Seminar</option>
                                            <option value="2">Workshop</option>

                                              
                                        </select> </div>
                                </div>
                                </div>

                                
                                
                               
                                </div>
                                

                                <div class="row">
                                <div class="col-md-12">
                                 <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Presenter</label>
                                    <div class="col-sm-10"><input class="form-control" placeholder="Presenter" name="presenter" value="<?php echo set_value('presenter'); ?>" type="text" required><span class="help-block m-b-none"><?php echo form_error('presenter'); ?></span></div>
                                </div>
                                </div>

                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Presenter Designation</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="presenter_designation" type="text" placeholder="Presenter Designation" value="<?php echo set_value('presenter_designation'); ?>"> </div>
                                </div>
                                </div>
                                
                                


                                </div>
                                </div>
                                

                                <div class="row">
                                <div class="col-md-12">
                                
                                

                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Presenter Image</label>
                                  <div class="col-sm-10"><input class="form-control" name="presenter_image" type="file"></div>
                                </div>
                                </div>

                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Fee</label>
                                    <div class="col-sm-10"><input class="form-control" name="info" type="text" placeholder="Fee" value="<?php echo set_value('info'); ?>" required><span class="help-block m-b-none"><?php echo form_error('info'); ?></span></div>
                                </div>
                                </div>
                                </div>
                                </div>

                                <?php
                                $now = time(); // or your date as well
                                $lastyear = date('Y')-1;
                                $end_last_date = strtotime($lastyear."-12-31");
                                $datediff = $now - $end_last_date;
                                $dayend =  round($datediff / (60 * 60 * 24)); ?>

                                
                                <div class="row">
                                <div class="col-md-12">
                                <div class="col-md-6">
                                    <div class="form-group"><label class="col-sm-2 control-label">Start Date</label>
                                        <div class="col-sm-10">
                                            <input class="form-control date-picker" name="start_date" <?php if($event_time == 1){ ?> data-date-end-date="-<?php echo $dayend; ?>d" <?php } ?> <?php if($event_time == 2){ ?> data-date-start-date="-<?php echo $dayend-2; ?>d" <?php } ?>   type="text" id="datepicker" placeholder="Start Date" value="<?php echo set_value('start_date'); ?>" required readonly><span class="help-block m-b-none"><?php echo form_error('start_date'); ?></span> </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Entry Time</label>
                                    <div class="col-sm-10">
                                        <input class="form-control timepicker timepicker-no-seconds" name="entry_time" type="text"  id="textInput" placeholder="Entry Time" value="<?php echo set_value('Entry Time'); ?>" required readonly><span class="help-block m-b-none"><?php echo form_error('entry_time'); ?></span> </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                
                                <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-6" id="workshopeventduration">
                                <div class="form-group"><label class="col-sm-2 control-label">Duration</label>
                                    <div class="col-sm-5">
                                        <select name="duration" class="form-control">
                                         <?php
                                         for($i=1; $i<=30; $i++){ ?>
                                            <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                            <?php } ?>
                                        </select>

                                    </div>
                                    <div class="col-sm-5">
                                        <select name="duration_period" class="form-control">
                                         <option value="">Please Select</option>
                                         <option value="Hours">Hours</option>
                                         <option value="Days">Days</option>
                                         <option value="Weeks">Weeks</option>
                                         <option value="Months">Months</option>
                                         <option value="Year">Year</option>
                                        </select>

                                    </div>
                                </div>
                                </div>

                                <div class="col-md-6" id="seminareventduration" style="display: none;">
                                <div class="form-group"><label class="col-sm-2 control-label">Duration</label>
                                    <div class="col-sm-5">
                                        
                                        <input type="text" name="duration" class="form-control" value="1" readonly="readonly">

                                    </div>
                                    <div class="col-sm-5">
                                        <select name="duration_period" class="form-control">
                                        <option value="Day">Day</option>
                                        </select>

                                    </div>
                                </div>
                                </div>
                                
                                
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Files</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="event_files" type="file" > <p style="color: red"><small>PDF files only </small></p></div>
                                        
                                </div>
                                </div>
                                </div>
                                </div>
                                
                         

                                    <div class="row">
                                <div class="col-md-12">

                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Descripition</label>
                                    <div class="col-sm-10">
                                       <textarea class="form-control" name="description"><?php echo set_value('description'); ?></textarea>
                                         </div>
                                </div>
                                </div>
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Status</label>
                                    <div class="col-sm-10">
                                        <select name="status" class="form-control">
                                              <option value="1">Active</option>
                                              <option value="0">Inactive</option>
                                        </select>   
                                </div>
                                </div>
                                </div>
                                </div>
                                
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>


     <script>
              $( function() {
              $( ".date-picker" ).datepicker({ minDate: 0});
              } );

              function getduration(event) {
                 if(event == 1){
                    $("#seminareventduration").show();
                    $("#workshopeventduration").hide();
                 }else if(event == 2){
                    $("#seminareventduration").hide();
                    $("#workshopeventduration").show();
                }else{
                    $("#seminareventduration").hide();
                    $("#workshopeventduration").show();
                }
              }
             


           

</script>

                        

                       
    