
<style type="text/css">
    #accordion .panel{
    border: none;
    border-radius: 5px;
    box-shadow: none;
    margin-bottom: 10px;
    background: transparent;
}
#accordion .panel-heading{
    padding: 0;
    border: none;
    border-radius: 5px;
    background: transparent;
    position: relative;
}
#accordion .panel-title a {
    display: block;
    padding: 20px 30px;
    margin: 0;
    background: rgb(54, 65, 80);
    font-size: 17px;
    font-weight: bold;
    color: #fff;
    text-transform: uppercase;
    letter-spacing: 1px;
    border: none;
    border-radius: 5px;
    position: relative;
}
#accordion .panel-title a.collapsed{ border: none; }
#accordion .panel-title a:before,
#accordion .panel-title a.collapsed:before{
    content: "\f107";
    font-family: "FontAwesome";
    width: 30px;
    height: 30px;
    line-height: 27px;
    text-align: center;
    font-size: 25px;
    font-weight: 900;
    color: #fff;
    position: absolute;
    top: 15px;
    right: 30px;
    transform: rotate(180deg);
    transition: all .4s cubic-bezier(0.080, 1.090, 0.320, 1.275);
}
#accordion .panel-title a.collapsed:before{
    color: #fff;
    transform: rotate(0deg);
}
#accordion .panel-body{
    font-size: 15px;
    line-height: 28px;
    letter-spacing: 1px;
    border-top: none;

padding: 0;    border-radius: 5px;
}
.portlet.light.portlet-fit>.portlet-body {
    padding: 10px 10px 20px!important;
}
</style>
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashboard'; ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Events</span><i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Past Events</span></i>
                </li>    
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'events/add/1' ?>" class="btn btn-primary">Add</a>   
                </div>
            </ol>
        </div>

        <h1 class="page-title">Past Events List
            <small>&nbsp;</small>
        </h1>

              <?php echo $this->session->flashdata('response'); ?>
                       
        
        <div class="row">
            <div class="col-md-12">
               <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                     <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                    <?php 
                    if(!empty($events)){
                        foreach ($events as $pasteventskey => $pasteventsvalue) { ?>
                          
                     <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="headingThree">
                            <h4 class="panel-title">
                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $pasteventskey; ?>" aria-expanded="false" aria-controls="collapseThree">
                                    <?php echo $pasteventskey; ?>
                                </a>
                            </h4>
                        </div>
                        <div id="collapse<?php echo $pasteventskey; ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                            <div class="panel-body">
                                 <div class="table-scrollable">
                    
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th> S.No.</th>
                                    <th> Event Type </th>
                                    <th> Event Name </th>
                                    <th> Presenter </th>
                                    <!-- <th> Info </th> -->
                                    <th> Start Date </th>
                                    <!-- <th> Created Date </th> -->
                                    <th> Status </th>
                                    <th> Action </th>
                                </tr>
                            </thed>
                            <tbody>
                            <?php 
                                $i = 1;
                                foreach ($pasteventsvalue as $eventslist) { ?>
                                <tr>
                                    <td> <?php echo $i; ?></td>
                                    <td> <?php  if($eventslist['event_type'] == '1'){ echo "Seminar"; }else{ echo "Workshop"; } ?> </td>
                                    <td> <?php echo $eventslist['event_name']; ?> </td>
                                    <td> <?php echo $eventslist['presenter'].'('.$eventslist['presenter_designation'].')'; ?> </td>
                                   <!--  <td> <?php echo $eventslist['info']; ?> </td> -->
                                    <td> <?php echo date('d/m/Y',strtotime($eventslist['start_date'])); ?>  <?php echo $eventslist['entry_time'] ?></td>
                                    
                                    <!-- <td> <?php echo date('d/m/Y',strtotime($eventslist['created_date'])); ?> </td> -->
                                    <td><?php if($eventslist['status'] == '1'){ ?>
                                        <a href="<?=ADMIN_URL?>events/updateStatus/deactive/<?=$eventslist['id'];?>" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a>
                                        <?php }else if($eventslist['status'] == '0'){ ?>
                                        <a href="<?=ADMIN_URL?>events/updateStatus/active/<?=$eventslist['id'];?>" class="btn btn-danger"><i class="fa fa-thumbs-down" aria-hidden="true"></i></a>
                                        <?php } ?>   
                                    </td>
                                    
                                    <td>  <a href="<?php echo ADMIN_URL.'events/edit/'.$eventslist['id'] ?>" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a> | <a href="javascript:void(0)" onclick="checkdelete('<?php echo $eventslist['id']; ?>')" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>  </td>   
                                </tr>
                                <?php  $i++; } ?>
                            </tbody>
                        </table>
                    </div>
                            </div>
                        </div>
                    </div>

                    <?php } } ?>



                </div>
                    

                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    </div>
</div>

<script type="text/javascript">
    function checkdelete(id) {
        var url = '<?php echo  ADMIN_URL.'events/delete/'; ?>';
        if (confirm('Are you sure to delete ?')) {
           window.location.href = url+id;
        } else {
           return false;
        }
        
    }
</script>