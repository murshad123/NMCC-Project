<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashoard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL.'regions/nigeriancommunity' ?>" ><span> Community</span></a><i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Edit Community</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'regions/nigeriancommunity' ?>" class="btn btn-primary">Back</a></div>
            </ol>
        </div>


        <h1 class="page-title"> Edit Community 
            <small>&nbsp;</small>
        </h1>
                       
        <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
                        <?php echo $this->session->flashdata('response'); ?>
                           
                                <form method="post" action="<?php echo ADMIN_URL; ?>/regions/editnigeriancommunity/<?php echo $community_id; ?>" class="form-horizontal">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">Community Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="Community Name" name="community_name" type="text" value="<?php echo $community_detail['community_name']; ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('community_name'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">Country</label>
                                                <div class="col-sm-10"><div class="col-sm-10"><select name="country" class="form-control" onchange="getStates(this.value)">
                                                <option value="">Please Select</option>
                                                <?php 
                                                if(!empty($countries)){
                                                    foreach ($countries as $countrykey => $countryvalue) { ?>   
                                                    <option value="<?php echo $countryvalue['country_id']; ?>" <?php if($community_detail['country_id'] == $countryvalue['country_id']){ echo "selected"; } ?>><?php echo $countryvalue['name']; ?></option>
                                                
                                                <?php } } ?>
                                            </select>
                                            
                                            </div>
                                            <span class="help-block m-b-none"><?php echo form_error('country'); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                      <div class="col-md-12">

                                      <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">State</label>
                                                <div class="col-sm-10"><div class="col-sm-10"><select name="state" class="form-control" id="select-state" >
                                                <option value="">Please Select</option>
                                                <?php 
                                                if(!empty($states)){
                                                    foreach ($states as $stateskey => $statesvalue) { ?>   
                                                    <option value="<?php echo $statesvalue['zone_id']; ?>" <?php if($community_detail['state_id'] == $statesvalue['zone_id']){ echo "selected"; } ?>><?php echo $statesvalue['name']; ?></option>
                                                
                                                <?php } } ?>
                                            </select>
                                            
                                            </div>
                                            <span class="help-block m-b-none"><?php echo form_error('state'); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">LGA/City/Division</label>
                                            <div class="col-sm-10"><div class="col-sm-10"><!-- <select name="lga" id="select-lga" class="form-control">
                                                <option value="">Please Select LGA</option>
                                                
                                            </select> -->
                                             <input type="text" name="lga" class="form-control" value="<?php echo $community_detail['city']; ?>" placeholder="LGA/City/Division"> 

                                            </div>
                                            <span class="help-block m-b-none"><?php echo form_error('lga'); ?></span>
                                            </div>
                                          </div>
                                        </div>

                                        
                                        </div>
                                    </div>

                                    <div class="row">
                                      <div class="col-md-12">
                                        

                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Status</label>
                                              <div class="col-sm-10"><select name="status" class="form-control">
                                                <option value="1" <?php if($community_detail['status'] == 1){ echo "selected"; } ?>>Active</option>
                                                <option value="0" <?php if($community_detail['status'] == 0){ echo "selected"; } ?>>Inactive</option>
                                            </select></div>
                                            </div>
                                          </div> 
                                        </div>
                                    </div>


                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">Update</button>
                                    </div>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>


<script type="text/javascript">
    function getZone(state_id){
       
        $.ajax({
              url:'<?php echo ADMIN_URL; ?>'+'/Regions/getstatelga',
              data:{state_id:state_id},
              type: 'POST',
              success :function(data){
               // console.log(data);
                $('#select-lga').html(data);
              }
        });
    }

    function getStates(country_id) {
        $.ajax({
              url:'<?php echo ADMIN_URL; ?>'+'/Regions/getajaxcountrystate',
              data:{country_id:country_id},
              type: 'POST',
              success :function(data){
               // console.log(data);
                $('#select-state').html(data);
              }
        });
    }
</script>
