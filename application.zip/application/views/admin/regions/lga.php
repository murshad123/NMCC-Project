<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL; ?>/dashboard">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    
                   <a href="javascript:void(0)">Continents</a>
                    <i class="fa fa-circle"></i>
                </li> 
                <li>
                    <span>Countries</span>
                    <i class="fa fa-circle"></i>
                </li> 
                <li>
                    <span>States</span>
                    <i class="fa fa-circle"></i>
                </li> 
                <li>
                    <span>LGAs/Counties/Divisions</span>
                </li>      
            </ul>
        </div>

      <div class="pull-right">
            <ol>
                <div class="title-action">
                 <a href="<?php echo ADMIN_URL.'regions/addlga/'.$continents_details['code'].'/'.$country_details['country_id'].'/'.$state_id ?>" class="btn btn-primary">Add</a>  
                  <a href="<?php echo ADMIN_URL.'regions/countries/'.$continents_details['code']; ?>" class="btn btn-primary">Back</a>   
                </div>
               
            </ol>
            
        </div> 

        <h1 class="page-title"> <?php echo $continents_details['name']; ?>
            <small><i class="fa fa-angle-double-right" aria-hidden="true"></i>&nbsp;<?php echo $country_details['name']; ?> &nbsp;<i class="fa fa-angle-double-right" aria-hidden="true"></i>&nbsp;States/Provinces
                &nbsp;<i class="fa fa-angle-double-right" aria-hidden="true"></i>&nbsp;LGAs/Counties/Divisions
            </small>
        </h1>
                       
        
        <div class="row">
            <div class="col-md-12">
               <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                  <?php echo $this->session->flashdata('response'); ?>
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th> S.No.</th>
                                    <th> LGAs/Counties/Divisions Name </th>
                                    <th> Action </th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                                $i = 1;
                                if(!empty($lga)){
                                foreach ($lga as $lgalist) { ?>
                                <tr>
                                    <td> <?php echo $i; ?></td>
                                    <td> <?php echo $lgalist['name']; ?> </td>
                                    <td>  
                                         <!-- <a class="btn btn-info" title="Community" href="<?=ADMIN_URL?>regions/addcommunity/<?=$stateslist['zone_id'];?>" ><i class="fa fa-users" aria-hidden="true"></i></a> -->
                                       <a class="btn btn-info" title="Community" href="<?=ADMIN_URL?>regions/addcommunity/<?=$lgalist['state_id'];?>/<?php echo $lgalist['id']; ?>" ><i class="fa fa-users" aria-hidden="true"></i></a> |
                                        <a href="<?php echo ADMIN_URL.'regions/editlga/'.$continents_details['code'].'/'.$country_details['country_id'].'/'.$lgalist['id'] ?>" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a>|<a href="javascript:void(0)" onclick="checkdelete('<?php echo $lgalist['id']; ?>')" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                     </td>   
                                </tr>
                                <?php  $i++; }}else{ ?>
                                <tr><td colspan="8" style="color: red"><center>No record found</center></td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    </div>
</div>

<script type="text/javascript">
    function checkdelete(id) {
        var url = '<?php echo  ADMIN_URL.'regions/deletelga/'; ?>';
        if (confirm('Are you sure to delete ?')) {
           window.location.href = url+id;
        } else {
           return false;
        }
        
    }
</script>