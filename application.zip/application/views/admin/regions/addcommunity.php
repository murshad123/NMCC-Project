<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashoard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL; ?>/regions/otherregion">Continents</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL; ?>/regions/counties/<?php echo $regiondetails['continents_code']; ?>">County</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL; ?>/regions/states/<?php echo $regiondetails['continents_code']; ?>/<?php echo $regiondetails['country_id']; ?>">State</a>
                    <i class="fa fa-circle"></i>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'/regions/states/'.$regiondetails['continents_code'].'/'.$regiondetails['country_id']; ?>" class="btn btn-primary">Back</a></div>
            </ol>
        </div>


        <h1 class="page-title"> Add Community 
            <small>&nbsp;</small>
        </h1>
                       
        <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
                        <?php echo $this->session->flashdata('response'); ?>
                           
                                <form method="post" action="<?php echo ADMIN_URL; ?>/regions/addcommunity/<?php echo $regiondetails['zone_id']; ?>/<?php echo $lga_id; ?>" class="form-horizontal">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">Community Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="Community Name" name="community_name" type="text" value="<?php echo set_value('community_name'); ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('community_name'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Status</label>
                                              <div class="col-sm-10"><select name="status" class="form-control">
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                            </select></div>
                                            </div>
                                          </div> 

                                        <!-- <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">State</label>
                                                <div class="col-sm-10"><div class="col-sm-10">
                                                <input type="text" name="state" value="<?php echo $regiondetails['zone_name']; ?>" class="form-control" readonly>
                                            
                                            </div>
                                            <span class="help-block m-b-none"><?php echo form_error('state'); ?></span>
                                        </div>
                                                                            </div>
                                                                        </div> -->

                       

                                <input type="hidden" name="country" value="<?php echo $regiondetails['country_id']; ?>">
                                <input type="hidden" name="state_id" value="<?php echo $regiondetails['zone_id']; ?>">
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>

        <div class="row">
            <div class="col-md-12">
               <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th> S.No.</th>
                                    <th> Community</th>
                                    <th> Country </th>
                                    <th> State </th>
                                    <th> LGA/City </th>
                                    <th> Status </th>
                                    <th> Action </th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                                $i = 1;
                                if(!empty($community)){
                                foreach ($community as $communitylist) { ?>
                                <tr>
                                    <td> <?php echo $i; ?></td>
                                    <td> <?php echo $communitylist['community_name']; ?> </td>
                                    <td> <?php echo $communitylist['country_name']; ?> </td>
                                    <td> <?php echo $communitylist['state_name']; ?> </td>
                                    <td> <?php echo $communitylist['city']; ?> </td>
                                    
                                     <td><?php if($communitylist['status'] == '1'){ ?>
                                        <a href="<?=ADMIN_URL?>regions/updateCommunityStatus/deactive/<?=$communitylist['id'];?>" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a>
                                        <?php }else if($communitylist['status'] == '0'){ ?>
                                        <a href="<?=ADMIN_URL?>regions/updateCommunityStatus/active/<?=$communitylist['id'];?>" class="btn btn-danger"><i class="fa fa-thumbs-down" aria-hidden="true"></i></a>
                                        <?php } ?> </td>  
                                        
                                         

                                       <td> 
                                       <a href="<?php echo ADMIN_URL.'regions/editcommunity/'.$communitylist['id'] ?>" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a> | <a href="<?php echo ADMIN_URL.'regions/deleteCommunity/'.$communitylist['id'] ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                        
                                       </td>
                                    
                                </tr>
                                <?php  $i++; }}else{ ?>
                                <tr><td colspan="8" style="color: red"><center>No record found</center></td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
          </div>
        </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>


<script type="text/javascript">
    function getZone(state_id){
       
        $.ajax({
              url:'<?php echo ADMIN_URL; ?>'+'/Regions/getstatelga',
              data:{state_id:state_id},
              type: 'POST',
              success :function(data){
               // console.log(data);
                $('#select-lga').html(data);
              }
        });
    }
</script>
