<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL; ?>/dashboard">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    
                    <!-- <a href="<?php echo ADMIN_URL; ?>/regions/otherregion">Continents</a> -->
                    <a href="javascript:void(0)">Continents</a>
                    <i class="fa fa-circle"></i>
                </li> 
                <li>
                    <span>Countries</span>
                </li>    
            </ul>
        </div>

         <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'regions/addcountries/'.$continents_details['code'] ?>" class="btn btn-primary">Add</a> 
                 <!--   <a href="<?php echo ADMIN_URL.'regions/otherregion' ?>" class="btn btn-primary">Back</a> -->   
                </div>
            </ol>
        </div> 

        <h1 class="page-title"><?php echo $continents_details['name']; ?>
            <small><i class="fa fa-angle-double-right" aria-hidden="true"></i>&nbsp;Countries</small>
        </h1>
                       
        <?php echo $this->session->flashdata('response'); ?> 
        <div class="row">
            <div class="col-md-12">
               <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th> S.No.</th>
                                    <th>Country Name </th>
                                    <th> Action </th>
                                </tr>
                                    
                            </thead>
                            <tbody>
                            <?php 
                                $i = 1;
                                if(!empty($countries)){
                                foreach ($countries as $countrieslist) { ?>
                                <tr>
                                    <td> <?php echo $i; ?></td>
                                    
                                    <td> <?php echo $countrieslist['name']; ?> </td>
                                    <td> <a class="btn btn-info" title="States/Provinces" href="<?=ADMIN_URL?>regions/states/<?php echo $continents_details['code']; ?>/<?=$countrieslist['country_id'];?>" ><i class="fa fa-globe" aria-hidden="true"></i></a>|
                                        <a href="<?php echo ADMIN_URL.'regions/editeCountry/'.$countrieslist['country_id'] ?>" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a>|<a href="<?php echo ADMIN_URL.'regions/deletecountry/'.$countrieslist['country_id'] ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                      </td>   
                                </tr>
                                <?php  $i++; }}else{ ?>
                                <tr><td colspan="8" style="color: red"><center>No record found</center></td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    </div>
</div>