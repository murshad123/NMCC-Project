<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL; ?>/dashboard">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Community</span>
                </li>    
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                   <a href="<?php echo ADMIN_URL.'regions/addnigeriancommunity' ?>" class="btn btn-primary">Add</a>
                </div>
            </ol>
        </div>

        <h1 class="page-title"> Community
            <small>&nbsp;</small>
        </h1>
                       
        
        <div class="row">
            <div class="col-md-12">
               <div class="portlet light portlet-fit bordered">
                <?php echo $this->session->flashdata('response'); ?>
                  <div class="portlet-body">
                    <div class="table-scrollable">

                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th> S.No.</th>
                                    <th> Community</th>
                                    <th> Country </th>
                                    <th> State </th>
                                    <th> LGA/City </th>
                                    <th> Status </th>
                                    <th> Action </th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                                $i = 1;
                                if(!empty($community)){
                                foreach ($community as $communitylist) { ?>
                                <tr>
                                    <td> <?php echo $i; ?></td>
                                    <td> <?php echo $communitylist['community_name']; ?> </td>
                                    <td> <?php echo $communitylist['country_name']; ?> </td>
                                    <td> <?php echo $communitylist['state_name']; ?> </td>
                                    <td> <?php echo $communitylist['city']; ?> </td>
                                    
                                     <td><?php if($communitylist['status'] == '1'){ ?>
                                        <a href="<?=ADMIN_URL?>regions/updateCommunityStatus/deactive/<?=$communitylist['id'];?>" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a>
                                        <?php }else if($communitylist['status'] == '0'){ ?>
                                        <a href="<?=ADMIN_URL?>regions/updateCommunityStatus/active/<?=$communitylist['id'];?>" class="btn btn-danger"><i class="fa fa-thumbs-down" aria-hidden="true"></i></a>
                                        <?php } ?> </td>  
                                        
                                         

                                       <td> 
                                       <a href="<?php echo ADMIN_URL.'regions/editnigeriancommunity/'.$communitylist['id'] ?>" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a> | <a href="<?php echo ADMIN_URL.'regions/deleteCommunity/'.$communitylist['id'] ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                        
                                       </td>
                                    
                                </tr>
                                <?php  $i++; }}else{ ?>
                                <tr><td colspan="8" style="color: red"><center>No record found</center></td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    </div>
</div>