<?php foreach ($states as $value) { ?>
<option value='<?php echo $value['zone_id']; ?>'><?php echo $value['name']; ?></option> 
 <?php } ?>