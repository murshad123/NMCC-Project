<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Discount</span>
                </li>    
            </ul>
        </div>

        <h1 class="page-title"> Customer Discount
            <small>&nbsp;</small>
        </h1>
                       
        
        <div class="row">
            <div class="col-md-12">
               <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th> S.No.</th>
                                    <th> Customer </th>
                                    <th> Order No </th>
                                    <th> Discount </th>
                                    <th> Coupon Code </th>
                                    <th> Max. Use </th>
                                    <th> Date </th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                                $i = 1;
                                if(!empty($stores)){
                                foreach ($stores as $storeslist) { ?>
                                <tr>
                                    <td> <?php echo $i; ?></td>
                                    <td> <?php echo $storeslist['store_name']; ?> </td>
                                    <td> <?php echo $storeslist['city']; ?> </td>
                                    <td> <?php echo $storeslist['state']; ?> </td>
                                    <td> <?php echo $storeslist['state']; ?> </td>
                                    <td> <?php echo $storeslist['status']; ?> </td>
                                    <td> <?php echo $storeslist['created_date']; ?> </td>
                                </tr>
                                <?php  $i++; }}else{ ?>
                                <tr><td colspan="8" style="color: red"><center>No record found</center></td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    </div>
</div>