<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashoard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL.'regions/nigeriancommunity' ?>" ><span> Community</span></a><i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Add Community</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'regions/nigeriancommunity' ?>" class="btn btn-primary">Back</a></div>
            </ol>
        </div>


        <h1 class="page-title"> Add Community 
            <small>&nbsp;</small>
        </h1>
                       
        <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
                        <?php echo $this->session->flashdata('response'); ?>
                           
                                <form method="post" action="<?php echo ADMIN_URL; ?>/regions/addnigeriancommunity" class="form-horizontal">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">Community Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="Community Name" name="community_name" type="text" value="<?php echo set_value('community_name'); ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('community_name'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">Country</label>
                                                <div class="col-sm-10"><div class="col-sm-10"><select name="country" class="form-control" onchange="getStates(this.value)">
                                                <option value="">Please Select</option>
                                                <?php 
                                                if(!empty($countries)){
                                                    foreach ($countries as $countrykey => $countryvalue) { ?>   
                                                    <option value="<?php echo $countryvalue['country_id']; ?>"><?php echo $countryvalue['name']; ?></option>
                                                
                                                <?php } } ?>
                                            </select>
                                            
                                            </div>
                                            <span class="help-block m-b-none"><?php echo form_error('country'); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                      <div class="col-md-12">

                                      <div class="col-md-6">
                                            <div class="form-group"><label class="col-sm-2 control-label">Province/State 
                                            </label>
                                                <div class="col-sm-10"><div class="col-sm-10"><select name="state" class="form-control" onchange="getZone(this.value)" id="select-state" >
                                                <option value="">Please Select</option>
                                               
                                            </select>
                                            
                                            </div>
                                            <span class="help-block m-b-none"><?php echo form_error('state'); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">LGA/<br>County/Division</label>
                                            <div class="col-sm-10"><div class="col-sm-10"><select name="lga" id="select-lga" class="form-control">
                                                <option value="">Please Select LGA</option>
                                                
                                            </select>
                                             <!-- <input type="text" name="lga" class="form-control" placeholder="LGA/City/Division">  -->

                                            </div>
                                            <span class="help-block m-b-none"><?php echo form_error('lga'); ?></span>
                                            </div>
                                          </div>
                                        </div>

                                        
                                        </div>
                                    </div>

                                    <div class="row">
                                      <div class="col-md-12">
                                        

                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Status</label>
                                              <div class="col-sm-10"><select name="status" class="form-control">
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                            </select></div>
                                            </div>
                                          </div> 
                                        </div>
                                    </div>


                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>


<script type="text/javascript">
    function getZone(state_id){
        // alert(state_id);
       
        $.ajax({
              url:'<?php echo ADMIN_URL; ?>'+'/regions/getstatelga',
              data:{state_id:state_id},
              type: 'POST',
              success :function(data){
               // console.log(data);
                $('#select-lga').html(data);
              }
        });
    }

    function getStates(country_id) {
        $.ajax({
              url:'<?php echo ADMIN_URL; ?>'+'/Regions/getajaxcountrystate',
              data:{country_id:country_id},
              type: 'POST',
              success :function(data){
               // console.log(data);
                $('#select-state').html(data);
              }
        });
    }
</script>
