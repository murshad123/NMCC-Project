<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL; ?>/dashboard">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Regions</span>
                </li>    
            </ul>
        </div>

        <!-- <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'discount/addcoupon' ?>" class="btn btn-primary">Add</a>   
                </div>
            </ol>
        </div> -->

        <h1 class="page-title"> Nigeria
            <small>&nbsp;</small>
        </h1>
                       
        
        <div class="row">
            <div class="col-md-12">
               <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th> S.No.</th>
                                    <th> States </th>
                                    <th> Action </th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                                $i = 1;
                                if(!empty($nigeriaStates)){
                                foreach ($nigeriaStates as $storeslist) { ?>
                                <tr>
                                    <td> <?php echo $i; ?></td>
                                    <td> <?php echo $storeslist['name']; ?> </td>
                                    <td> <a href="<?=ADMIN_URL?>regions/nigeriaStatesLga/<?=$storeslist['state_id'];?>" >LGA</a>  </td>   
                                </tr>
                                <?php  $i++; }}else{ ?>
                                <tr><td colspan="8" style="color: red"><center>No record found</center></td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    </div>
</div>