<?php foreach ($lga as $value) { ?>
<option value='<?php echo $value['local_id']; ?>'><?php echo $value['local_name']; ?></option> 
 <?php } ?>