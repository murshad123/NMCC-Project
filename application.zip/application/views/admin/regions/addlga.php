<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashboard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="javascript:void(0)" class="btn btn-primary"><span>LGAs/Counties/Divisions</span></a>
                </li>
                <li>
                    <span>Add LGAs/Counties/Divisions</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                 <!--  <a href="<?php echo ADMIN_URL.'regions/lga/'.$continent_code.'/'.$country_id ?>" class="btn btn-primary">Back</a></div> -->
            </ol>
        </div>


        <h1 class="page-title"> Add LGAs/Counties/Divisions 
            <small>&nbsp;</small>

        </h1>

     <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
			            <div class="ibox-content">
             <form action="<?php echo ADMIN_URL.'regions/addlga/'.$continent_code.'/'.$country_id.'/'.$state_id ;?>" class="form-horizontal" method="post" accept-charset="utf-8">                           
                                <?php echo $this->session->flashdata('response'); ?>
                                <div><label class="col-sm-2 control-label"></label></div>
                                <div class="row">
                                    <div class="col-md-12">
                                      

                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label"> Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="Please  Enter LGAs/Counties/Divisions" name="name" type="text" value="<?php echo set_value('name'); ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('name'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <!--  <div class="col-md-6">
                                           <div class="form-group">
                                             <label class="col-sm-2 control-label">State ID</label>
                                               <div class="col-sm-10">
                                                   <input class="form-control" placeholder="Please  Enter state_id  " name="state_id" type="text" value="<?php echo set_value('state_id'); ?>" required>
                                                   <span class="help-block m-b-none"><?php echo form_error('state_id'); ?></span>
                                               </div>
                                           </div>
                                                                                </div> -->
                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label"> Status</label>
                                              <div class="col-sm-10">
                                                <select name="status" class="form-control">
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                              </select>
                                          </div>
                                                </div>
                                            </div>
                                        
                                    </div>
                                </div>


                                <!--  <div class="row">
                                   <div class="col-md-12">
                                     
                                       <div class="col-md-6">
                                           <div class="form-group">
                                             <label class="col-sm-2 control-label"> Status</label>
                                             <div class="col-sm-10">
                                               <select name="status" class="form-control">
                                               <option value="1">Active</option>
                                               <option value="0">Inactive</option>
                                             </select>
                                         </div>
                                               </div>
                                           </div>
                                
                                       
                                   </div>
                                                                </div>
                                 -->
                                
                                </div>


                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <input class="btn btn-primary" type="submit" name="submit" value="submit">
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>