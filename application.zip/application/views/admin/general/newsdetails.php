
<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="<?php echo ASSETS_URL ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">News Details</h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">News Details</span>
      </div>
    </div>
  </header>

  <?php //echo "<pre>";
  //print_r($newsdetails); die; ?>

 <section class="post-content-area single-post-area comman-main">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 posts-list">
          <div class="single-post row">
            <div class="col-lg-12">
              <div class="feature-img">
                <img class="img-fluid" src="<?php echo ASSETS_URL ?>img/hero-2.png" alt="">
              </div>
            </div>
            <div class="col-lg-2  col-md-2 meta-details">
              <!-- <ul class="tags">
                <li><a href="#">Food,</a></li>
                <li><a href="#">Technology,</a></li>
                <li><a href="#">Politics,</a></li>
                <li><a href="#">Lifestyle</a></li>
              </ul> -->
              <div class="user-details row">
<!--                 <p class="user-name col-lg-12 col-md-12 col-6"><a href="#">Mark wiens</a> <span class="lnr lnr-user"></span></p>
 -->                <p class="date col-lg-12 col-md-12 col-6"><a href="#"><?php echo date('d/m/Y',strtotime($newsdetails['created_date'])); ?></a> <span class="lnr lnr-calendar-full"></span></p>
<!--                 <p class="view col-lg-12 col-md-12 col-6"><a href="#">1.2M Views</a> <span class="lnr lnr-eye"></span></p>
 -->                <p class="comments col-lg-12 col-md-12 col-6"><a href="#">06 Comments</a> <span class="lnr lnr-bubble"></span></p>
                <!-- <ul class="social-links col-lg-12 col-md-12 col-6">
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-github"></i></a></li>
                  <li><a href="#"><i class="fa fa-behance"></i></a></li>
                </ul> -->
              </div>
            </div>
            <div class="col-lg-10 col-md-10">
             <h3><?php echo $newsdetails['title']; ?></h3>
              <p class="excert">
                MCSE boot camps have its supporters and its detractors. Some people do not understand why you should have to spend money
                on boot camp when you can get the MCSE study materials yourself at a fraction.
              </p>
              <p>
                Boot camps have its supporters and its detractors. Some people do not understand why you should have to spend money on boot
                camp when you can get the MCSE study materials yourself at a fraction of the camp price. However, who has the willpower
                to actually sit through a self-imposed MCSE training. who has the willpower to actually sit through a self-imposed
              </p>
              <p>
                Boot camps have its supporters and its detractors. Some people do not understand why you should have to spend money on boot
                camp when you can get the MCSE study materials yourself at a fraction of the camp price. However, who has the willpower
                to actually sit through a self-imposed MCSE training. who has the willpower to actually sit through a self-imposed
              </p>
            </div>
            
          </div>
          
         <!--  <div class="comment-form">
            <h4 class="text-white">Leave a Comment</h4>
            <form>
              <div class="form-group form-inline">
                <div class="form-group col-lg-6 col-md-12 name">
                  <input type="text" class="form-control" id="name" placeholder="Enter Name" >
                </div>
                <div class="form-group col-lg-6 col-md-12 email">
                  <input type="email" class="form-control" id="email" placeholder="Enter email address" >
                </div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" id="subject" placeholder="Subject">
              </div>
              <div class="form-group">
                <textarea class="form-control mb-10" rows="5" name="message" placeholder="Messege" 
                 required=""></textarea>
              </div>
              <a href="#" class="primary-btn">Post Comment</a>
            </form>
          </div>-->
        </div> 
       
      </div>
    </div>
  </section>

