<?php include 'header.php'; ?>

<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">Events</h2>
      <div class=" breadcrumb">
        <a href="index.php" class="btn">Home</a>
        <span class="btn btn--rightBorder">Events</span>
      </div>
    </div>
  </header>

 <div class="comman-main">
     <div class="container">
         <div class="row">
             <div class="col-md-5 col-sm-12">
                 <div class="event-imgs">
                     <img src="img/event_9.jpg" width="100%">
                     <div class="content-event">
                         <span>16</span>
                         <p>Nov</p>
                     </div>
                 </div>
             </div>
             <div class="col-md-7 col-sm-12">
                 <div class="discripation">
                     <h3 class="head">Marketing Solutions in 2018</h3>
                     <p>Donec quis metus ac arcu luctus accumsan. Nunc in justo tincidunt, sodales nunc id, finibus nibh. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce nec ante vitae lacus aliquet vulputate. Donec scelerisque accu msan molestie. Vestibulum ante ipsum primis in faucibus orci luctus.</p>
                     <p>Donec quis metus ac arcu luctus accumsan. Nunc in justo tincidunt, sodales nunc id, finibus nibh. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce nec ante vitae lacus aliquet vulputate. Donec scelerisque accu msan molestie. Vestibulum ante ipsum primis in faucibus orci luctus.</p>
                     <p>Donec quis metus ac arcu luctus accumsan. Nunc in justo tincidunt, sodales nunc id, finibus nibh. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce nec ante vitae lacus aliquet vulputate. Donec scelerisque accu msan molestie. Vestibulum ante ipsum primis in faucibus orci luctus.</p>
                 </div>
             </div>
         </div>
     </div>
 </div>

<?php include 'footer.php'; ?>