                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                        
                        <!-- END THEME PANEL -->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="index.html">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span>General</span>
                                </li>
                                
                            </ul>


                            
                        </div>

                        <div class="pull-right">
                        <ol>
                        <div class="title-action">
                        <a href="<?php echo ADMIN_URL.'general/faq' ?>" class="btn btn-primary">Back</a>
                       
                    </div></ol>
                        </div>


                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> Add FAQ 
                            <small>&nbsp;</small>
                        </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                        <!-- BEGIN DASHBOARD STATS 1-->
                        <div class="row">
                            
                     <div class="col-lg-12">
                    <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        
                        <div class="ibox-content">
                            <?php echo form_open_multipart('admin/general/faq/add',array('class'=>'form-horizontal')); ?>
                                <?php echo $this->session->flashdata('response'); ?>
                                <div class="form-group"><label class="col-sm-2 control-label">Title</label>

                                    <div class="col-sm-10">
                                        <input class="form-control" placeholder="Page Title" name="title" type="text" value="<?php echo set_value('title'); ?>" required>
                                        <span class="help-block m-b-none"><?php echo form_error('title'); ?></span>
                                    </div>
                                </div>

                                
                                <div class="hr-line-dashed"></div>

                                <div class="form-group"><label class="col-sm-2 control-label">Content</label>

                                    <div class="col-sm-10">
                                        <textarea class="form-control" name="content"  placeholder="Content"><?php echo set_value('content'); ?></textarea>
                                         
                                    </div>
                                </div>



                              
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>