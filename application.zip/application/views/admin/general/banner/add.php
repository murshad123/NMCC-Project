                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                        
                        <!-- END THEME PANEL -->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="index.html">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span>General</span>
                                </li>
                                
                            </ul>


                            
                        </div>

                        <div class="pull-right">
                        <ol>
                        <div class="title-action">
                        <a href="<?php echo ADMIN_URL.'general/cms' ?>" class="btn btn-primary">Back</a>
                       
                    </div></ol>
                        </div>


                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> Add CMS Page 
                            <small>&nbsp;</small>
                        </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                        <!-- BEGIN DASHBOARD STATS 1-->
                        <div class="row">
                            
                     <div class="col-lg-12">
                    <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        
                        <div class="ibox-content">
                            <?php echo form_open_multipart('admin/cms/add',array('class'=>'form-horizontal')); ?>
                                <?php echo $this->session->flashdata('response'); ?>
                                <div class="form-group"><label class="col-sm-2 control-label">Page Title</label>

                                    <div class="col-sm-10">
                                        <input class="form-control" placeholder="Page Title" name="title" type="text" value="<?php echo set_value('title'); ?>" required>
                                        <span class="help-block m-b-none"><?php echo form_error('title'); ?></span>
                                    </div>
                                </div>

                           

                                <div class="hr-line-dashed"></div>

                                <div class="form-group"><label class="col-sm-2 control-label">Meta Title</label>

                                    <div class="col-sm-10"><input class="form-control" placeholder="Meta Title" name="meta_title" value="<?php echo set_value('meta_title'); ?>" type="text"></div>
                                </div>

                                
                                <div class="hr-line-dashed"></div>

                                <div class="form-group"><label class="col-sm-2 control-label">Meta Keyword</label>

                                    <div class="col-sm-10"><input class="form-control" name="meta_keyword" type="text" placeholder="Meta Keyword" value="<?php echo set_value('meta_keyword'); ?>"></div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>

                                <div class="form-group"><label class="col-sm-2 control-label">Meta Description</label>

                                    <div class="col-sm-10">
                                        <input class="form-control" name="meta_desc" type="text" placeholder="Meta Description" value="<?php echo set_value('meta_desc'); ?>">    
                                    </div>
                                </div>



                                <div class="hr-line-dashed"></div>
                                
                                <div class="form-group"><label class="col-sm-2 control-label">Image</label>

                                    <div class="col-sm-10"><input class="form-control" name="image" type="file"></div>
                                </div>

                                 <div class="hr-line-dashed"></div>

                                <div class="form-group"><label class="col-sm-2 control-label">Page Content</label>

                                    <div class="col-sm-10 " >
                                          <textarea class="form-control summernote" rows="5" placeholder="Page Content" name="content" ></textarea>                                    </div>
                                    </div>
                                
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>