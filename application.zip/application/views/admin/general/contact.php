<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="<?php echo ASSETS_URL ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">Contact Us </h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">Contact</span>
      </div>
    </div>
  </header>

  <section class="comman-main contact-bg">
  	<div class="container">
  		<div class="row">
  			<div class="col-md-5">
       <div class="media contact-info">
            <span class="contact-info__icon"><i class="lnr lnr-home"></i></span>
            <div class="media-body">
              <h3>Environmental Biotechnology &Bioconservation Department, National Biotechnology Development Agency (Federal Ministry of Science & Technology), Umar Musa Yar’adua Expressway, Lugbe, Abuja, FCT, Nigeria.P.M.B. 511, Wuse, Abuja
</h3>
              
            </div>
          </div>
          <div class="media contact-info">
            <span class="contact-info__icon"><i class="lnr lnr-phone-handset"></i></span>
            <div class="media-body">
              <h3><a href="tel:+234-803-4007152">+234-803-4007152</a></h3>
             
            </div>
          </div>
          <div class="media contact-info">
            <span class="contact-info__icon"><i class="lnr lnr-envelope"></i></span>
            <div class="media-body">
              <h3><a href="mailto:gobioh@yahoo.com">gobioh@yahoo.com</a><br><a href="mailto:g.i.obioh@nabda.gov.ng">g.i.obioh@nabda.gov.ng</a></h3>
             
            </div>
          </div>   
        </div>
        <div class="col-md-7 margin-top">

          <h3 class="contact-head">Send Us Message</h3>
          <form action="#/" class="form-contact">
            <div class="row">
              <div class="col-lg-5">
                <div class="form-group">
                  <input class="form-control" name="name" type="text" placeholder="Enter your name" required>
                </div>
                <div class="form-group">
                  <input class="form-control" name="email" type="email" placeholder="Enter email address" required>
                </div>
                <div class="form-group">
                  <input class="form-control" name="subject" type="text" placeholder="Enter Subject">
                </div>
              </div>
              <div class="col-lg-7">
                <div class="form-group">
                    <textarea class="form-control different-control w-100" name="textarea" id="textarea" cols="30" rows="6" placeholder="Enter Message"></textarea>
                </div>
              </div>
            </div>
            <div class="form-group text-center text-md-right">
              <button type="submit" class="btn active btn--leftBorder">Send Message</button>
            </div>
          </form>
        </div>
  		</div>
  	</div>
  </section>
<div class="container-fluid">
  <div class="row map-main">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3940.2167929034954!2d7.500159214713785!3d9.043979191244548!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x104e0b952807ef3f%3A0x98a28ef26c773921!2sNational+Biotechnology+Development+Agency+-+NABDA!5e0!3m2!1sen!2sin!4v1560942794935!5m2!1sen!2sin" width="100%" height="550px" frameborder="0" style="border:0" allowfullscreen></iframe>
  </div>
</div>


