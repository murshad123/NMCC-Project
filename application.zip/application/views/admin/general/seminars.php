

<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="<?php echo ASSETS_URL ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">Events</h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">Seminars/Workshops</span>
      </div>
    </div>
  </header>

 <div class="event-schedule-area-two bg-color comman-main">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-text">
                            <h2>Seminars</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <div class="title-text">
                                <h4 class="head">PREVIOUS YEAR EVENTS</h4>
                            </div>
                           
                        </div>
                    </div>
                    <!-- /.col end-->
                </div>
                <!-- row end-->
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="nav custom-tab" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-taThursday" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">2014</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">2015</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">2016</a>
                            </li>
                            <li class="nav-item d-none d-lg-block">
                                <a class="nav-link" id="sunday-tab" data-toggle="tab" href="#sunday" role="tab" aria-controls="sunday" aria-selected="false">2017</a>
                            </li>
                            <li class="nav-item mr-0 d-none d-lg-block">
                                <a class="nav-link" id="monday-tab" data-toggle="tab" href="#monday" role="tab" aria-controls="monday" aria-selected="false">2018</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="text-center" scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th  scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                             <th  scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="sunday" role="tabpanel" aria-labelledby="sunday-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th  scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="monday" role="tabpanel" aria-labelledby="monday-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                 <th  scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                   
                </div>
            </div>
        </div>

        <!-- future section start -->
        <div class="event-schedule-area-two bg-color comman-main">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <div class="title-text">
                                <h4 class="head">CURRENT/FUTURE SEMINARS</h4>
                            </div>
                           
                        </div>
                    </div>
                    <!-- /.col end-->
                </div>
                <!-- row end-->
                <div class="row">
                    <div class="col-lg-12">
                    <?php
                        if(!empty($currentseminars)){
                        foreach ($currentseminars as $currsemkey => $currsemvalue) { ?>
                        <ul class="nav custom-tab" id="myTab" role="tablist">
                        
                              
                        <?php if(!empty($currsemvalue)){
                                foreach($currsemvalue as $csmiikey => $csmiivalue){ ?>
                            
                            <li class="nav-item">
                                <a class="nav-link active" id="home-taThursday" data-toggle="tab" href="#currentsem-<?php echo $csmiikey; ?>" role="tab" aria-controls="home1" aria-selected="true"><?php echo $csmiikey; ?></a>
                            </li>

                            
                            
                        </ul>
                        <div class="tab-content" id="myTabContent">
                           <?php 
                           if(!empty($csmiivalue)){
                             //echo "<pre>";
                               //print_r($csmiivalue); die; 
                           foreach($csmiivalue as $csfusminarkey => $csfusminarvalue){ ?>
                            <div class="tab-pane fade show active" id="#currentsem-<?php echo $csfusminarkey; ?>" role="tabpanel" aria-labelledby="home-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="text-center" scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <?php } } 
                            ?>
                            
                            
                            
                        </div>
                       
                    </div>
 <?php } } ?>

                </div>
                <?php } } ?>
            </div>
        </div>
        <!-- future section end -->


<!-- workshop html start -->
<div class="event-schedule-area-two bg-color comman-main ">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-text">
                            <h2>Workshops</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <div class="title-text">
                                <h4 class="head">PREVIOUS YEAR EVENTS</h4>
                            </div>
                           
                        </div>
                    </div>
                    <!-- /.col end-->
                </div>
                <!-- row end-->
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="nav custom-tab" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-taThursday" data-toggle="tab" href="#home-1" role="tab" aria-controls="home" aria-selected="true">2014</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile-1" role="tab" aria-controls="profile" aria-selected="false">2015</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact-1" role="tab" aria-controls="contact" aria-selected="false">2016</a>
                            </li>
                            <li class="nav-item d-none d-lg-block">
                                <a class="nav-link" id="sunday-tab" data-toggle="tab" href="#sunday-1" role="tab" aria-controls="sunday" aria-selected="false">2017</a>
                            </li>
                            <li class="nav-item mr-0 d-none d-lg-block">
                                <a class="nav-link" id="monday-tab" data-toggle="tab" href="#monday-1" role="tab" aria-controls="monday" aria-selected="false">2018</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home-1" role="tabpanel" aria-labelledby="home-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="text-center" scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="profile-1" role="tabpanel" aria-labelledby="profile-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th  scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="contact-1" role="tabpanel" aria-labelledby="contact-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                             <th  scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="sunday-1" role="tabpanel" aria-labelledby="sunday-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th  scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="monday-1" role="tabpanel" aria-labelledby="monday-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                 <th  scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                   
                </div>
            </div>
        </div>

        <!-- future section start -->
        <div class="event-schedule-area-two bg-color comman-main padding ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <div class="title-text">
                                <h4 class="head">CURRENT/FUTURE EVENTS</h4>
                            </div>
                           
                        </div>
                    </div>
                    <!-- /.col end-->
                </div>
                <!-- row end-->
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="nav custom-tab" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-taThursday-1" data-toggle="tab" href="#home1-1" role="tab" aria-controls="home1" aria-selected="true">2019</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab-1" data-toggle="tab" href="#profile1-1" role="tab" aria-controls="profile1" aria-selected="false">2020</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="contact-tab-1" data-toggle="tab" href="#contact1-1" role="tab" aria-controls="contact1" aria-selected="false">2021</a>
                            </li>
                            
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home1-1" role="tabpanel" aria-labelledby="home-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="text-center" scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="profile1-1" role="tabpanel" aria-labelledby="profile-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th  scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="contact1-1" role="tabpanel" aria-labelledby="contact-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                             <th  scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span>16 to 25</span>
                                                        <p>Novembar</p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="events-details.php">Marketing Solutions</a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <img src="<?php echo ASSETS_URL ?>img/1.jpg">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#">Aslan Lingker</a><span>Director</span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="#">pdf</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- future section end -->
<!-- workshop html end -->