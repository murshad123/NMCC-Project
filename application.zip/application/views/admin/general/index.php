      <div class="owl-carousel owl-theme heroCarousel">
        <div class="item">
          <div class="hero__slide">
            <img src="<?php echo ASSETS_URL ?>img/hero-2.png" alt="">
            <div class="hero__slideContent text-center">
              <h1>Nigerian Microbial Culture Collections</h1>
              <p>The WFCC-MIRCEN world data centre for microorganisms (WDCM) was set up as a data center of the world federation for culture collections(WFCC).</p>
							<a class="btn btn--leftBorder btn--rightBorder" href="#/">Details</a>							
							<span class="hero__slideContent--right"></span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="hero__slide">
            <img src="<?php echo ASSETS_URL ?>img/hero-1.png" alt="">
            <div class="hero__slideContent text-center">
              <h1>Nigerian Microbial Culture Collections</h1>
              <p>The WFCC-MIRCEN world data centre for microorganisms (WDCM) was set up as a data center of the world federation for culture collections(WFCC).   </p>
							<a class="btn btn--leftBorder btn--rightBorder" href="#/">Details</a>
							<span class="hero__slideContent--right"></span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="hero__slide">
            <img src="<?php echo ASSETS_URL ?>img/hero-3.png" alt="">
            <div class="hero__slideContent text-center">
             <h1>Nigerian Microbial Culture Collections</h1>
              <p>The WFCC-MIRCEN world data centre for microorganisms (WDCM) was set up as a data center of the world federation for culture collections(WFCC).   </p>
							<a class="btn btn--leftBorder btn--rightBorder" href="#/">Details</a>							
							<span class="hero__slideContent--right"></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>

	<section class="about ">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-5">
					<div class="about__img text-center text-md-left mb-5 mb-md-0">
						<img class="img-fluid" src="<?php echo ASSETS_URL ?>img/about.png" alt="">
						<!-- <a href="#/" class="about__img__date text-center">
							<h3>26</h3>
							<p>Years <br> of Creativity</p>
						</a> -->
					</div>
				</div>
				<div class="col-md-7 pl-xl-5">
					<div class="section-intro">
						<h4 class="section-intro__title">History</h4>
						<h2 class="section-intro__subtitle">Nigerian Microbial Culture Collections</h2>
					</div>
					<p>Microorganisms play vital roles in natural cycles in ecosystems as producers and consumers. They form the bedrock of modern biotechnology and are considered more diverse than plants and animals globally. However, microbial culture collections and conservation especially in the Sub-Saharan Africa have been very limited. </p>
					<p>The current rate of biodiversity loss due to anthropogenic activities places a premium on the need to urgently collect, conserve and develop Nigeria’s microbial heritage.</p>
					<a class="btn btn--rightBorder mt-4" href="#/">Read More</a>
				</div>
			</div>
		</div>
	</section>
	


	
  

	<section class="portfolio ">
		<div class="container">
			<div class="section-intro">
			
				<h2 class="section-intro__subtitle bottom-border">Databases</h2>
			</div>

			<div class="row align-items-end pb-md-5 mb-4">
				<div class="col-md-7 mb-4 mb-md-0">
					<div class="portfolio__img">
						<img class="img-fluid" src="<?php echo ASSETS_URL ?>img/portfolio2.png" alt="">
					</div>
				</div>
				<div class="col-md-5 mb-5 pl-xl-5">
					<h2 class="section-intro__subtitle small">CCINFO</h2>
					<p>Culture Collections Information Worldwide is a database management system for culture collections in the world.</p>

					<a class="btn btn--rightBorder mt-3" href="#/">Read More</a>
				</div>
			</div>

			<div class="row align-items-end pb-md-5 mb-4">
				<div class="col-md-5 mb-5 pr-xl-5 order-2 order-md-1">
					<h2 class="section-intro__subtitle small">Analyzer of Bio-resource citations</h2>
					<p>ABC is a platform that could support the researchers on the citations among papers, patent, genome, nucleotide sequences.</p>

					<a class="btn btn--rightBorder mt-3" href="#/">Read More</a>
				</div>
				<div class="col-md-7 mb-4 mb-md-0 order-1 order-md-2">
					<div class="portfolio__img">
						<img class="img-fluid" src="<?php echo ASSETS_URL ?>img/portfolio1.png" alt="">
					</div>
				</div>
			</div>

			<div class="row align-items-end pb-md-5 mb-4">
				<div class="col-md-7 mb-4 mb-md-0">
					<div class="portfolio__img">
						<img class="img-fluid" src="<?php echo ASSETS_URL ?>img/portfolio3.png" alt="">
					</div>
				</div>

				<div class="col-md-5 mb-5 pl-xl-5">
						<h2 class="section-intro__subtitle small">Global Catalogue of Microorganisms</h2>
					<p>GCM is expected to be a robust, reliable and user-friendly system to help culture collections to manage, disseminate and share the information related to their holdings</p>

					<a class="btn btn--rightBorder mt-3" href="#/">Read More</a>
				</div>
			</div>

			<div class="row align-items-end pb-md-5 mb-4">
				<div class="col-md-5 mb-5 pr-xl-5 order-2 order-md-1">
					<h2 class="section-intro__subtitle small">Reference Strain catalogue</h2>
					<p>This catalogue was produced to enable broader and easier access to the reference strains listed by the ISO Working Groups.</p>

					<a class="btn btn--rightBorder mt-3" href="#/">Read More</a>
				</div>

				<div class="col-md-7 order-1 order-md-2 mb-4 mb-md-0">
					<div class="portfolio__img">
						<img class="img-fluid" src="<?php echo ASSETS_URL ?>img/portfolio4.png" alt="">
					</div>
				</div>
			</div>

			<!-- <div class="text-center pt-2">
				<button class="btn btn--rightBorder btn--leftBorder">Load More Projects</button>
			</div> -->
		</div>
	</section>