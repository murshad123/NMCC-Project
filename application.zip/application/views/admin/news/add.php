<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">


         <?php 
         if($news_time == 1){
         $newstimes = 'Past';
         $newsreturnurl = ADMIN_URL.'news/pastnews';
               }else if($news_time == 2){
         $newstimes = 'Current';
         $newsreturnurl = ADMIN_URL.'news/currentnews';
               } ?> 

            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'news' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="javasript:void(0)" class="btn btn-primary"><span>News</span></a>
                </li>
                <li>
                    <span>Add Current News</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo $newsreturnurl; ?>" class="btn btn-primary">Back</a></div>
            </ol>
        </div>


        <h1 class="page-title"> Add <?php echo $newstimes; ?> News 
            <small>&nbsp;</small>

        </h1>

     <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
			 <form action="<?php echo ADMIN_URL.'news/add';?>" enctype="multipart/form-data" class="form-horizontal" method="post" accept-charset="utf-8" >                           
                                <?php echo $this->session->flashdata('response'); ?>
                                <div><label class="col-sm-2 control-label">News Details</label></div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label">Title Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="Title Name" name="title" type="text" value="<?php echo set_value('title'); ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('title'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label">Short Description</label>
                                                <div class="col-sm-10">
                                                  <input class="form-control" placeholder="Short Description" type="text" name="short_desc" value="<?php echo set_value('short_desc'); ?>" required>
                                                  <span class="help-block m-b-none"><?php echo form_error('short_desc'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                      <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
										                       <label class="col-sm-2 control-label">Added By</label>
										                         <div class="col-sm-10">
                                             <input class="form-control" placeholder="Added By" name="added_by" type="text" value="<?php echo set_value('added_by'); ?>" required>
                                             <span class="help-block m-b-none"><?php echo form_error('added_by'); ?></span>
                                            </div>
                                          </div>
                                        </div>
										
										                    <div class="col-md-6">
                                          <div class="form-group">
                                               <label class="col-sm-2 control-label">Upload Image</label>
                                             <div class="col-sm-10">
                                             <input class="form-control" placeholder="Added By" name="file" type="file" value="<?php echo set_value('file'); ?>" required>
                                             <span class="help-block m-b-none"><?php echo form_error('file'); ?></span>
                                              </div>
                                          </div>
                                        </div>
										
										
                                        </div>
                                    </div>

                                     <div class="row">
                                      <div class="col-md-12">

                                      <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label"> Description</label>
                                                <div class="col-sm-10">
                                                 <textarea class="form-control" placeholder="Description" name="description"><?php echo set_value('short_desc'); ?></textarea>
                                                 
                                                  <span class="help-block m-b-none"><?php echo form_error('description'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                          <div class="form-group">
                                           <label class="col-sm-2 control-label"> Status</label>
                                                <div class="col-sm-10">
                                                  <select name="status" class="form-control">
                                                  <option value="1">Active</option>
                                                  <option value="0">Inactive</option>
                                                </select>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>




                                    

                                     


                                
                                
                              <!--  <div class="row">
                                  <div class="col-md-12">
                              
                                      
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Institution Name</label>
                              
                                          <div class="col-sm-10">
                                              <input class="form-control" name="institution_name" type="text" placeholder="Institution Name" value="<?php echo set_value('institution_name'); ?>" required>    
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                              </div>
                              
                              <div><label class="col-sm-2 control-label">Institution Address</label></div>
                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                                    
                                          <label class="col-sm-2 control-label">Institution Country</label>
                              
                                          <div class="col-sm-10">
                                                    <select name="institution_country" class="form-control" required>
                                                                  <option value="" required>Select Country</option> 
                                                 <?php 
                              
                                                  if(!empty($country)){
                                                    foreach ($country as $countrykey => $countryvalue) { ?>
                                                    <option value="<?php echo $countryvalue['iso_code_2']; ?>"><?php echo $countryvalue['name']; ?></option>  
                                                   <?php  }  } ?>
                                          </select>
                                         <input class="form-control" name="institution_country" type="text" placeholder="Institution Country" value="<?php echo set_value('institution_country'); ?>" required>
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Institution State</label>
                                          <div class="col-sm-10">
                                                    <select name="institution_state" class="form-control" required>
                                                                  <option value="" required>Select state</option> 
                                                 <?php 
                              
                                                  if(!empty($states)){
                                                    foreach ($states as $statekey => $statevalue) { ?>
                                                    <option value="<?php echo $statevalue['name']; ?>"><?php echo $statevalue['name']; ?></option>  
                                                   <?php  }  } ?>
                                          </select>
                              
                                             <input class="form-control" name="institution_state" type="text" placeholder="Istitution State" value="<?php echo set_value('institution_state'); ?>" required>    
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Institution City</label>
                                          <div class="col-sm-10">
                                          <input class="form-control" name="institution_city" type="text" placeholder="Institution City" value="<?php echo set_value('institution_city'); ?>" required>
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Institution Zipcode</label>
                                          <div class="col-sm-10">
                                              <input class="form-control" name="institution_zipcode" type="text" placeholder="Institution Zipcodee" value="<?php echo set_value('institution_zipcodee'); ?>" required>    
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Institution Type</label>
                              
                                          <div class="col-sm-10">
                                          <input class="form-control" name="institution_type" type="text" placeholder="Institution Type" value="<?php echo set_value('institution_type'); ?>" required>
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Status</label>
                              
                                          <div class="col-sm-10">
                                              <input class="form-control" name="state" type="text" placeholder="State" value="<?php echo set_value('state'); ?>">    
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                              </div>
                              
                              <div><label class="col-sm-2 control-label">Isolation Detail</label></div>
                              
                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Isolation Reason</label>
                              
                                          <div class="col-sm-10">
                                          <input class="form-control" name="isolation_reason" type="text" placeholder="Isolation Reason" value="<?php echo set_value('isolation_reason'); ?>" required>
                                          </div>
                                        </div>
                                      </div>
                              
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Journal Name</label>
                              
                                          <div class="col-sm-10">
                                              <input class="form-control" name="journal_name" type="text" placeholder="Journal Name" value="<?php echo set_value('journal_name'); ?>" required>    
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Organisms Name</label>
                              
                                          <div class="col-sm-10">
                                          <input class="form-control" name="organisms_name" type="text" placeholder="Organisms Name" value="<?php echo set_value('journal_name'); ?>" required>
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Organisms Address</label>
                              
                                          <div class="col-sm-10">
                                              <input class="form-control" name="organisms_address" type="text" placeholder="0rganisms Address" value="<?php echo set_value('organisms_address'); ?>" required>    
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Organisms Country</label>
                              
                                          <div class="col-sm-10">
                                                    <select name="organisms_country" class="form-control" required>
                                                                  <option value="" required>Select Country</option> 
                                                 <?php 
                              
                                                  if(!empty($country)){
                                                    foreach ($country as $countrykey => $countryvalue) { ?>
                                                    <option value="<?php echo $countryvalue['iso_code_2']; ?>"><?php echo $countryvalue['name']; ?></option>  
                                                   <?php  }  } ?>
                                          </select>
                                         <input class="form-control" name="organisms_country" type="text" placeholder="Organisms Country" value="<?php echo set_value('organisms_country'); ?>" required>
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Status</label>
                              
                                          <div class="col-sm-10">
                                              <input class="form-control" name="state" type="text" placeholder="State" value="<?php echo set_value('state'); ?>">    
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                              </div>
                              
                              <div><label class="col-sm-2 control-label">Organisms Address</label></div>
                              
                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Organisms State</label>
                              
                                          <div class="col-sm-10">
                                                    <select name="organisms_state" class="form-control" required>
                                                                  <option value="" required>Select State</option> 
                                                 <?php 
                              
                                                  if(!empty($states)){
                                                    foreach ($states as $statekey => $statevalue) { ?>
                                                    <option value="<?php echo $statevalue['name']; ?>"><?php echo $statevalue['name']; ?></option>  
                                                   <?php  }  } ?>
                                          </select>
                                         <input class="form-control" name="organisms_state" type="text" placeholder="Organisms State" value="<?php echo set_value('organisms_state'); ?>">
                                          </div>
                                        </div>
                                      </div>
                                      
                                       <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Organisms City</label>
                              
                                          <div class="col-sm-10">
                                              <input class="form-control" name="organisms_city" type="text" placeholder="organisms city" value="<?php echo set_value('organisms_city'); ?>">    
                                          </div>
                                        </div>
                                      </div> 
                                    </div>
                              </div>
                              
                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Biological Importance</label>
                              
                                          <div class="col-sm-10">
                                          <input class="form-control" name="biological_importance" type="text" placeholder="Biological Importance" value="<?php echo set_value('biological_importance'); ?>">
                                          </div>
                                        </div>
                                      </div>
                                      
                                       <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Isolation Date</label>
                              
                                          <div class="col-sm-10">
                                              <input class="form-control" name="isolation_date" type="text" placeholder="Isolation Date" value="<?php echo set_value('isolation_date'); ?>">    
                                          </div>
                                        </div>
                                      </div> 
                                    </div>
                              </div>
                                              
                                              
                                              <div class="row">
                                  <div class="col-md-12">
                                       <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Isolation Method</label>
                              
                                          <div class="col-sm-10">
                                              <input class="form-control" name="isolation_method" type="text" placeholder="Isolation Method" value="<?php echo set_value('isolation_method'); ?>">    
                                          </div>
                                        </div>
                                      </div> 
                                                  
                                                  <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Depository</label>
                              
                                          <div class="col-sm-10">
                                          <input class="form-control" name="depository" type="text" placeholder="Depository" value="<?php echo set_value('depository'); ?>">
                                          </div>
                                        </div>
                                      </div>
                                                  
                                                  
                                    </div>
                              </div>
                                              
                                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Depository</label>
                              
                                          <div class="col-sm-10">
                                          <input class="form-control" name="depository" type="text" placeholder="Depository" value="<?php echo set_value('depository'); ?>">
                                          </div>
                                        </div>
                                      </div>
                                      
                                       <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Exipry year</label>
                              
                                          <div class="col-sm-10">
                                              <input class="form-control" name="expiryyear" type="text" placeholder="State" value="<?php echo set_value('state'); ?>">    
                                          </div>
                                        </div>
                                      </div> 
                                    </div>
                              </div>
                              
                                              
                              
                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Notification</label>
                              
                                          <div class="col-sm-10">
                                          <select name="email_notification" class="form-control">
                                              <option value="1">Yes</option>
                                              <option value="0">No</option>
                                          </select>
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label">Status</label>
                              
                                          <div class="col-sm-10">
                                              <select name="status" class="form-control">
                                              <option value="1">Active</option>
                                              <option value="0">Inactive</option>
                                          </select>    
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                              </div>
                              
                                    -->
                                
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <input class="btn btn-primary" type="submit" name="submit" value="submit">
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>