<?php foreach ($countriess as $value)
 { ?>
 <tr> 
 	 <td><input name="country_name[<?php echo $value['country_id']; ?>]"  class="form-control" type="text" placeholder=" Enter Patent" value="<?php echo $value['name']; ?>" readonly>  </td>
    <td><input name="patent[<?php echo $value['country_id']; ?>]"  class="form-control" type="text" placeholder=" Enter Patent" value="" >  </td>
     <td><input type="text"  class="form-control" name="store[<?php echo $value['country_id']; ?>]" placeholder=" Enter Store" value=""></td>
     <td><input name="distribution[<?php echo $value['country_id']; ?>]"  class="form-control" type="text" placeholder=" Enter Distribution" value="" ></td>
     <td><input type="text"  class="form-control" name="identification[<?php echo $value['country_id']; ?>]" placeholder=" Enter   Identification" value=""></td>
     <td><input name="training[<?php echo $value['country_id']; ?>]"  class="form-control" type="text" placeholder=" Enter Training" value="" ></td>
     <td><input type="text" name="consult[<?php echo $value['country_id']; ?>]" class="form-control" placeholder="Enter Consult" value=""></td>
 </tr>

 <?php } ?>