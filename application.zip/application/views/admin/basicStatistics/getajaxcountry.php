<?php foreach ($countriess as $value)
 { ?>
<!-- <option value="<?php echo $value['country_id']; ?>"><?php echo $value['name']; ?></option> --> 
<option value="<?php echo $value['name']; ?>"><?php echo $value['name']; ?></option>
 <?php } ?>