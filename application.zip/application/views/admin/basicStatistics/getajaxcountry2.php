<?php foreach ($countriess as $value)
 { ?>
 	<tr>
 	<td><input name="country_name[<?php echo $value['country_id']; ?>]"  class="form-control" type="text" value="<?php echo $value['name']; ?>" required readonly>  </td>

    <td><input name="culture_collections[<?php echo $value['country_id']; ?>]"  class="form-control" type="text" placeholder=" Enter culture collections" value="" > </td>

    <td><input type="text"  class="form-control" name="cultures[<?php echo $value['country_id']; ?>]" placeholder=" Enter  Cultures" value=""></td>
 	</tr>

 <?php } ?>