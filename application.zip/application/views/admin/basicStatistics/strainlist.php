<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'acronyms' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
               
            </ul>
        </div>

    <div class="pull-right">
            <ol>
               <div class="title-action">
                   <a href="<?php echo ADMIN_URL.'basicStatistics/countries' ?>" class="btn btn-primary">Back</a>
                </div> 
            </ol>
        </div>

        <h1 class="page-title"> Strains And No. of Species/sub-species List
            <small>&nbsp;</small>
        </h1>
        <?php echo $this->session->flashdata('response'); ?>  
         <form action="" class="form-horizontal" method="post" accept-charset="utf-8">             
         <div class="row">
          <div class="col-md-12">
              <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                      <div class="table-scrollable">
      
                          <table class="table table-bordered table-hover">
                              <thead>
                                  <tr>
                                               
                                      <th>S.No.</th>
                                      <th>strain</th>
                                      <th>No. of Species/sub-species</th> 
                                      <!-- <th>Added Date</th>
                                      <th>Status</th>
                                      <th>Action</th> -->
                                  </tr>
                              </thead>
                           <tbody>
                     <?php 
                         $i = 1;
                         foreach ($strain as $getculturesHeldlist) { ?>
                         <tr>
                             <td> <?php echo $i; ?> </td>
                             <td> <?php echo $getculturesHeldlist['strains']; ?> </td>
                           <!--   <td> <?php echo $getculturesHeldlist['species']; ?></td> -->
                             <!-- <td> <?php echo date('d/m/Y' ,strtotime($getculturesHeldlist['created_date'])); ?> </td>
                           
                           
                             <td><?php if($getculturesHeldlist['status'] == '1'){ ?>
                             <a href="<?=ADMIN_URL?>basicStatistics/updateStatus/deactive/<?=$getculturesHeldlist['id'];?>" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a>
                             <?php }else if($getculturesHeldlist['status'] == '0'){ ?>
                             <a href="<?=ADMIN_URL?>basicStatistics/updateStatus/active/<?=$getculturesHeldlist['id'];?>" class="btn btn-danger"><i class="fa fa-thumbs-down" aria-hidden="true"></i></a>
                             <?php } ?> </td> 
                             
                             
                           
                            <td> 
                            <a href="<?php echo ADMIN_URL.'basicStatistics/editculturesHeld/'.$getculturesHeldlist['id'] ?>" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a> | <a href="<?php echo ADMIN_URL.'basicStatistics/deleteCulturesHeld/'.$getculturesHeldlist['id'] ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                             
                            </td> -->
                         </tr>
                         <?php $i++; } ?>
                      </tbody>
                </table>
                      </div>
                  </div>
              </div>
          </div>
      </div> 
       <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <input class="btn btn-primary" type="submit" name="submit" value="submit">
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
        <div class="clearfix"></div>
    </div>
</div>