
<script src="http://localhost/NMCC/assets/vendor/jquery/jquery-3.2.1.min.js"></script>
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashboard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="javasript:void(0)"><span>BASIC STATISTICS</span></a><i class="fa fa-circle"></i>
                </li>
                
            </ul>
        </div>
        <h1 class="page-title"> BASIC STATISTICS
            <small>&nbsp;</small>

        </h1>

     <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
      <form action="<?php echo ADMIN_URL;?>basicStatistics/countries" class="form-horizontal" method="post" accept-charset="utf-8">
       <?php echo $this->session->flashdata('response'); ?>
        <div><label class="col-sm-2 control-label"></label></div>
        <?php $country_id = $this->uri->segment(4); ?>
       

          <div class="row">
            <div class="col-md-12">
                <div>
                    <div class="form-group">
                      <!-- <label class="col-sm-2 control-label"></label> -->
                      <div class="col-sm-4">
                        
                             <select class="form-control" onchange="getcountry(this.value),getcountry2(this.value),getcountry3(this.value)">
                        <option value="">Please Select Continent</option>
                        <?php 
                        if(!empty($continents)){
                            foreach ($continents as $continentskey => $continentsvalue) { ?>   
                            <option value="<?php echo $continentsvalue['code']; ?>">
                            <?php echo $continentsvalue['name']; ?></option>
                        
                        <?php } } ?>
                    </select>
                        
                      </div>
                        <div class="col-sm-4">
                             <select name="institution_country" class="form-control" id="country">
                            <option value="">Please Select Country</option>
                           </select>
                        </div>
                        <div class="col-sm-4">
                          <select class="form-control" onchange="gettypes(this.value)">
                          <option >Please Select Category</option>
                          <option value="1">Cultures Held</option>
                          <option value="2">Culture Collections</option>
                          <option value="3">Numbers of culture collections held by States in NMCC</option>
                          <option value="4">Service Provided in addition to regular maintenance</option>
                          <option value="5">Type of Services</option>
                           <option value="6">Upload Strains List</option>
                          </select>
                        </div>
                    </div>
                </div>
                
            </div>
            </div>
        </div>
        
    <?php echo form_close(); ?>
</div>
</div>
</div>
</div>
<div id="cultureHeld">
  <?php   
    $formurl = ADMIN_URL.'basicStatistics/stainadding'; ?>
    <form action="<?php echo $formurl; ?>" class="form-horizontal" method="post" accept-charset="utf-8">
        <h1 class="page-title" style="text-align: center; color:gold;"> Strains And No. of Species/sub-species List
            <small>&nbsp;</small>
        </h1>
       <div class="row">
          <div class="col-md-12">
              <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                      <div class="table-scrollable">
      
                          <table class="table table-bordered table-hover">
                              <thead>
                                  <tr>
                                               
                                      
                                      <th>strain</th>
                                      <th>No. of Species/sub-species</th> 
                                    
                                  </tr>
                              </thead>
                           <tbody>
                     <?php 
                         $i = 1;
                         foreach ($strain as $getculturesHeldlist) { ?>
                         <tr>
                             
                             <td><input name="strain[]"  class="form-control" type="text" value="<?php echo $getculturesHeldlist['strains']; ?>" required readonly>  </td>
                             <td><input type="text"  class="form-control" name="species[]" value=""></td>
                             
                      
                         </tr>
                         <?php $i++; } ?>
                      </tbody>
                </table>
                      </div>
                  </div>
              </div>
          </div>
      </div> 

      <div class="hr-line-dashed"></div>
    <div class="form-group">
<div class="col-sm-6 col-sm-offset-4">
  <input type="hidden" name="country_id" value="<?php echo $country_id; ?>">
<input class="btn btn-primary" type="submit" name="save" value="save">
 </div>
</div>
<?php echo form_close(); ?>

        


</div> 
<div id="culturescollection">
  <?php   
  
    $formurl = ADMIN_URL.'basicStatistics/culturscollections'; ?>
    <form action="<?php echo $formurl; ?>" class="form-horizontal" method="post" accept-charset="utf-8">
        <h1 class="page-title" style="text-align: center; color:gold;">Culture Collections
            <small>&nbsp;</small>
        </h1>
       <div class="row">
          <div class="col-md-12">
              <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                      <div class="table-scrollable">
      
                          <table class="table table-bordered table-hover">
                              <thead>
                                  <tr>
                                               
                                      
                                      
                                      <th>Supported by</th> 
                                      <th>No.of collections</th>
                                    
                                  </tr>
                              </thead>
                           <tbody>
                   
                         <tr>
                             
                            
                             <td><input type="text"  class="form-control" name="supported_by" value=""></td>
                             <td><input type="text"  class="form-control" name="no_of_collection" value=""></td>
                             
                      
                         </tr>
                         
                      </tbody>
                </table>
                      </div>
                  </div>
              </div>
          </div>
      </div> 

      <div class="hr-line-dashed"></div>
    <div class="form-group">
<div class="col-sm-6 col-sm-offset-4">
  <input type="hidden" name="country_id" value="<?php echo $country_id; ?>">
<input class="btn btn-primary" type="submit" name="save" value="save">
 </div>
</div>
<?php echo form_close(); ?>

        

 
</div> 
<div id="culturenumber">
  <?php   
  
    $formurl = ADMIN_URL.'basicStatistics/numberCultureState'; ?>
    <form action="<?php echo $formurl; ?>" class="form-horizontal" method="post" accept-charset="utf-8">
        <h1 class="page-title" style="text-align: center; color:gold;">Numbers of culture collections held by States in NMCC
            <small>&nbsp;</small>
        </h1>
       <div class="row">
          <div class="col-md-12">
              <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                      <div class="table-scrollable">
      
                          <table class="table table-bordered table-hover">
                              <thead>
                                  <tr>
                                               
                                    
                                      <th>Countries and Regions</th>
                                      <th>Culture Collections</th>
                                      <th>Cultures</th> 
                                    
                                  </tr>
                              </thead>
                           <tbody id="country02">
             
                          </tbody>
                </table>
                      </div>
                  </div>
              </div>
          </div>
      </div> 

      <div class="hr-line-dashed"></div>
    <div class="form-group">
<div class="col-sm-6 col-sm-offset-4">
  
<input class="btn btn-primary" type="submit" name="save" value="save">
 </div>
</div>
<?php echo form_close(); ?>

        

 
</div> 
<div id="serviceprovided">
  <?php   

    $formurl = ADMIN_URL.'basicStatistics/serviceProvided'; ?>
    <form action="<?php echo $formurl; ?>" class="form-horizontal" method="post" accept-charset="utf-8">
        <h1 class="page-title" style="text-align: center; color:gold;">Service Provided in addition to regular maintenance
            <small>&nbsp;</small>
        </h1>
       <div class="row">
          <div class="col-md-12">
              <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                      <div class="table-scrollable">
      
                          <table class="table table-bordered table-hover">
                              <thead>
                                  <tr>
                                               
                                      <!-- <td>Continents</td> -->
                                      <th>Countries and Regions</th>
                                      <th>Patent</th>
                                      <th>Store</th> 
                                      <th>Distribution</th>
                                      <th>Identification</th>
                                      <th>Training</th>
                                      <th>Consult</th>
                                    
                                  </tr>
                              </thead>
                           <tbody id="country03">
                    
                        <!--  <tr> 
                          <td><input name="patent"  class="form-control" type="text" placeholder=" Enter Patent" value="" >  </td>
                            <td><input type="text"  class="form-control" name="store" placeholder=" Enter Store" value=""></td>
                            <td><input name=" distribution"  class="form-control" type="text" placeholder=" Enter Distribution" value="" >  </td>
                            <td><input type="text"  class="form-control" name="  identification" placeholder=" Enter   Identification" value=""></td>
                            <td><input name="training"  class="form-control" type="text" placeholder=" Enter Training" value="" >  </td>
                            <td><input type="text" name="consult" class="form-control" placeholder="Enter Consult" value=""></td>
                        </tr> -->
                        
                      </tbody>
                </table>
                      </div>
                  </div>
              </div>
          </div>
      </div> 

      <div class="hr-line-dashed"></div>
    <div class="form-group">
<div class="col-sm-6 col-sm-offset-4">
<input class="btn btn-primary" type="submit" name="save" value="save">
 </div>
</div>
<?php echo form_close(); ?>

        

 
</div> 
<div id="rankofstrain">
  <?php   
 
    $formurl = ADMIN_URL.'basicStatistics/typesofservices'; ?>
    <form action="<?php echo $formurl; ?>" class="form-horizontal" method="post" accept-charset="utf-8">
        <h1 class="page-title" style="text-align: center; color:gold;">Types Of Services
            <small>&nbsp;</small>
        </h1>
       <div class="row">
          <div class="col-md-12">
              <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                      <div class="table-scrollable">
      
                          <table class="table table-bordered table-hover">
                              <thead>
                                  <tr>
                                               
                                      
                                      <th>Service Type</th>
                                      <th>No. of Collections</th> 
                                    
                                  </tr>
                              </thead>
                           <tbody>
                    
                         <tr>
                             
                             <td><input name="service"  class="form-control" type="text" placeholder="Enter Service" value="" required>  </td>
                             <td><input type="text" placeholder="Enter No. of collections"  class="form-control" name="collection" value=""></td>
                             
                      
                         </tr>
                     
                      </tbody>
                </table>
                      </div>
                  </div>
              </div>
          </div>
      </div> 

      <div class="hr-line-dashed"></div>
    <div class="form-group">
<div class="col-sm-6 col-sm-offset-4">
<input class="btn btn-primary" type="submit" name="save" value="save">
 </div>
</div>
<?php echo form_close(); ?>

        


</div>
<div id="strainfiles">
  <?php   
 
    $formurl = ADMIN_URL.'basicStatistics/uploadDataCSVfile'; ?>
    <form action="<?php echo $formurl; ?>" class="form-horizontal" method="post" enctype="multipart/form-data" accept-charset="utf-8">
        <h1 class="page-title" style="text-align: center; color:gold;">Upload Strains Via CSV Files
            <small>&nbsp;</small>
        </h1>
       <div class="row">
          <div class="col-md-6 col-md-offset-3">
              <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                      <div class="table-scrollable">
      
                          <table class="table table-bordered table-hover">
                              <thead>
                                  <tr>
                                               
                                      
                                      <th>Choose your CSV file:</th>
                                     
                                    
                                  </tr>
                              </thead>
                           <tbody>
                    
                         <tr>
                             
                             <td><input type="file" class="form-control" name="userfile" id="userfile"  align="center"/>  </td>
                             
                             
                      
                         </tr>
                     
                      </tbody>
                </table>
                      </div>
                  </div>
              </div>
          </div>
      </div> 

      <div class="hr-line-dashed"></div>
    <div class="form-group">
<div class="col-sm-6 col-sm-offset-4">
<input class="btn btn-primary" type="submit" name="save" value="save">
 </div>
</div>
<?php echo form_close(); ?>

        


</div>                   
</div>
<div class="clearfix"></div>
<!-- END DASHBOARD STATS 1-->

<script type="text/javascript">

  function getcountry(continent_cod) {
    // alert("Hello");
       var target_url =  "<?php echo ADMIN_URL.'basicStatistics/getajaxcountry/'; ?>";
        $.ajax({
              type: 'POST',
              url:target_url,
              data:{continent_cod:continent_cod},
             success :function(data){
                 //console.log(data);
                $('#country').html(data);
                 $('#country2').html(data);
                 $('#country3').html(data);
              }
        });
    }

    function getcountry2(continent_cod) {
      // alert("Hello");
       var target_url =  "<?php echo ADMIN_URL.'basicStatistics/getajaxcountry2/'; ?>";
        $.ajax({
              type: 'POST',
              url:target_url,
              data:{continent_cod:continent_cod},
             success :function(data){
                 console.log(data);
                $('#country02').html(data);
                
              }
        });
    }

function getcountry3(continent_cod) {
      // alert("Hello");
       var target_url =  "<?php echo ADMIN_URL.'basicStatistics/getajaxcountry3/'; ?>";
        $.ajax({
              type: 'POST',
              url:target_url,
              data:{continent_cod:continent_cod},
             success :function(data){
                 console.log(data);
                $('#country03').html(data);
                
              }
        });
    }


// function selectcountry(country_id) {
//    var redirecturl = "<?php echo ADMIN_URL.'basicStatistics/countries/'; ?>";
//    if(country_id != ''){
//     window.location.href = redirecturl+country_id;
//    }else{
//     window.location.href = redirecturl;
//    }
// } 



   $(document).ready(function(){
       $("#cultureHeld").hide();
       $("#culturescollection").hide();
       $("#culturenumber").hide();
       $("#serviceprovided").hide();
       $("#rankofstrain").hide();
       $("#strainfiles").hide();


     /* $("#category").change(function(){
        if($(this).val() == "1")
        {
          $("#cultureHeld").show();
        }
        else if($(this).val() == "2")
        {
          $("#culturescollection").show();
        }
        else if($(this).val() == "3")
        {
          $("#culturenumber").show();
        }
        else if($(this).val() == "4")
        {
          $("#serviceprovided").show();
        }
        else if($(this).val() == "5")
        {
          $("#rankofstrain").show();
        }
        
        }).change();*/
           
});

function gettypes(event) {
                 if(event == 1){
                     $("#cultureHeld").show();
                     $("#culturescollection").hide();
                     $("#culturenumber").hide();
                     $("#serviceprovided").hide();
                     $("#rankofstrain").hide();
                     $("#strainfiles").hide();
                 }else if(event == 2){
                    $("#cultureHeld").hide();
                     $("#culturescollection").show();
                     $("#culturenumber").hide();
                     $("#serviceprovided").hide();
                     $("#rankofstrain").hide();
                     $("#strainfiles").hide();
                }else if(event == 3){
                     $("#cultureHeld").hide();
                     $("#culturescollection").hide();
                     $("#culturenumber").show();
                     $("#serviceprovided").hide();
                     $("#rankofstrain").hide();
                     $("#strainfiles").hide();
                }else if(event == 4){
                     $("#cultureHeld").hide();
                     $("#culturescollection").hide();
                     $("#culturenumber").hide();
                     $("#serviceprovided").show();
                     $("#rankofstrain").hide();
                     $("#strainfiles").hide();
                }else if(event == 5){
                   $("#cultureHeld").hide();
                   $("#culturescollection").hide();
                   $("#culturenumber").hide();
                   $("#serviceprovided").hide();
                   $("#rankofstrain").show();
                   $("#strainfiles").hide();
              }else if(event == 6){
                   $("#cultureHeld").hide();
                   $("#culturescollection").hide();
                   $("#culturenumber").hide();
                   $("#serviceprovided").hide();
                   $("#rankofstrain").hide();
                   $("#strainfiles").show();
              }

            }



</script>
<script type="text/javascript">
  
/*<script type="text/javascript">
    var mydropdown = document.getElementById('mycontinent');
    var mytextbox = document.getElementById('getcontinent');

    mydropdown.onchange = function(){
          mytextbox.value = mytextbox.value + this.value; //to appened
         //mytextbox.innerHTML = this.value;
    }*/

/*$("#mycontinent").on('keydown',function(){
    $("#getcontinent").val($(this).val());
})
*/

/*$("#mycontinent").change(function () {
    var addressArray = [$("#mycontinent").val()];
    $("#getcontinent").text(addressArray.join(' '));
});*/

</script>


                        