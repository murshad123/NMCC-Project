<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'acronyms' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Strains</span>
                </li>
            </ul>
        </div>

    <div class="pull-right">
            <ol>
                <div class="title-action">
                   <a href="<?php echo ADMIN_URL.'basicStatistics/addstraincultures' ?>" class="btn btn-primary">Add</a>
                </div>
            </ol>
        </div>

        <h1 class="page-title"> Strain List
            <small>&nbsp;</small>
        </h1>
        <?php echo $this->session->flashdata('response'); ?>             
         <div class="row">
          <div class="col-md-12">
              <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                      <div class="table-scrollable">
      
                          <table class="table table-bordered table-hover">
                              <thead>
                                  <tr>
                                               <tr>
                                      <th>S.No.</th>
                                      <th>strains</th> 
                                      <th>Added Date</th>
                                      <th>Status</th>
                                      <th>Action</th>
                                  </tr>
                              </thead>
                           <tbody>
                     <?php 
                         $i = 1;
                         foreach ($strains as $strains) { ?>
                         <tr>
                             <td> <?php echo $i; ?> </td>
                             <td> <?php echo $strains['strains']; ?> </td>
                           
                             <td> <?php echo date('d/m/Y' ,strtotime($strains['created_date'])); ?> </td>
                           
                           
                             <td><?php if($strains['status'] == '1'){ ?>
                             <a href="<?=ADMIN_URL?>basicStatistics/updateStatus2/deactive/<?=$strains['id'];?>" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a>
                             <?php }else if($strains['status'] == '0'){ ?>
                             <a href="<?=ADMIN_URL?>basicStatistics/updateStatus2/active/<?=$strains['id'];?>" class="btn btn-danger"><i class="fa fa-thumbs-down" aria-hidden="true"></i></a>
                             <?php } ?> </td> 
                             
                             
                           
                            <td> 
                            <a href="<?php echo ADMIN_URL.'basicStatistics/editStraincultures/'.$strains['id'] ?>" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a> | <a href="<?php echo ADMIN_URL.'basicStatistics/deleteStrainCultures/'.$strains['id'] ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                             
                            </td>
                         </tr>
                         <?php $i++; } ?>
                      </tbody>
                </table>
                      </div>
                  </div>
              </div>
          </div>
      </div> 
        <div class="clearfix"></div>
    </div>
</div>