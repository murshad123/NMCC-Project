<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashbaord'; ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>General</span>
                </li> 

                <li>
                    <span>Inquiry</span>
                </li>   
            </ul>
        </div>


        <h1 class="page-title"> Inquiry List
            <small>&nbsp;</small>
        </h1>
          <?php echo $this->session->flashdata('response'); ?>                
        
        <div class="row">
            <div class="col-md-12">
               <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th> S.No.</th>
                                    <th> Name </th>
                                    <th> Email </th>
                                    <th> Subject </th>
                                    <th> Message </th>
                                    <th> Created Date </th>
                                    <th> Action </th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                                $i = 1;
                                foreach ($inquiry as $inquirylist) { ?>
                                <tr>
                                    <td> <?php echo $i; ?></td>
                                    <td> <?php echo $inquirylist['name']; ?> </td>
                                    <td> <?php echo $inquirylist['email']; ?> </td>
                                    <td> <?php echo $inquirylist['subject']; ?> </td>
                                    <td> <?php echo $inquirylist['message']; ?> </td>
                                    <td> <?php echo date('d/m/Y',strtotime($inquirylist['created_date'])); ?> </td> 
                                    <td>
                                        <a href="<?php echo ADMIN_URL.'admingeneral/edit/'.$inquirylist['id'] ?>" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                                     |<a href="<?php echo ADMIN_URL.'admingeneral/delete/'.$inquirylist['id'] ?>" class="btn btn-danger"><i   class="fa fa-trash" aria-hidden="true"></i></a> </td>   
                                </tr>
                                <?php  $i++; } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    </div>
</div>