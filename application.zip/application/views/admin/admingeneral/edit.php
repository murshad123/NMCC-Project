<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashboard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL.'admingeneral/inquiry' ?>" ><span>Inquiry</span></a><i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Edit Inquiry</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'admingeneral/inquiry' ?>" class="btn btn-primary">Back</a></div>
            </ol>
        </div>


        <h1 class="page-title"> Edit Inquiry
            <small>&nbsp;</small>

        </h1>

     <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
       <form action="<?php echo ADMIN_URL.'Admingeneral/edit/'.$inquiry_id;?>" class="form-horizontal" method="post" accept-charset="utf-8">                           
                              <?php echo $this->session->flashdata('response'); ?>
                                <div><label class="col-sm-2 control-label"></label></div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label">Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="Enter Name" name="name" type="text" value="<?php echo $inquiry['name']; ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('name'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label">Email</label>
                                                <div class="col-sm-10">
                                                  <input class="form-control" placeholder="Enter Email" type="text" name="email" value="<?php echo $inquiry['email'] ; ?>" required>
                                                  <span class="help-block m-b-none"><?php echo form_error('email'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                     <div class="row">
                                        <div class="col-md-12">
                                         <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label">    Subject</label>
                                                <div class="col-sm-10">
                                                  <input class="form-control" placeholder="Enter Subject" type="text" name="subject" value="<?php echo $inquiry['subject'] ; ?>" required>
                                                  <span class="help-block m-b-none"><?php echo form_error('subject'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                         <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label">    Messaget</label>
                                              <div class="col-sm-10">
                                              <input class="form-control" placeholder="Enter Message" type="text" name="message" value="<?php echo $inquiry['message'] ; ?>" required>
                                              <span class="help-block m-b-none"><?php echo form_error('message'); ?></span>
                                              </div>
                                            </div>
                                        </div>
                                        </div>
                                        </div>
                                        
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <input class="btn btn-primary" type="submit" name="submit" value="submit">
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>