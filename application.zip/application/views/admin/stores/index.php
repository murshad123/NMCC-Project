<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Stores</span>
                </li>    
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'stores/add' ?>" class="btn btn-primary">Add</a>   
                </div>
            </ol>
        </div>

        <h1 class="page-title"> Store List
            <small>&nbsp;</small>
        </h1>
                       
        
        <div class="row">
            <div class="col-md-12">
               <div class="portlet light portlet-fit bordered">
                  <div class="portlet-body">
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th> S.No.</th>
                                    <th> Store Name </th>
                                    <th> City </th>
                                    <th> State </th>
                                    <th> Open Hours </th>
                                    <th> Working Day </th>
                                    <th> Status </th>
                                    <th> Created Date </th>
                                    <th> Action </th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                                $i = 1;
                                foreach ($stores as $storeslist) { ?>
                                <tr>
                                    <td> <?php echo $i; ?></td>
                                    <td> <?php echo $storeslist['store_name']; ?> </td>
                                    <td> <?php echo $storeslist['city']; ?> </td>
                                    <td> <?php echo $storeslist['state']; ?> </td>
                                    <td> <?php echo $storeslist['open_hours']; ?> </td>
                                    <td> <?php echo $storeslist['working_days']; ?> </td>
                                    <td> <?php echo date('d/m/Y',strtotime($storeslist['created_date'])); ?> </td>
                                    <td><?php if($storeslist['status'] == '1'){ ?>
                                        <a href="<?=ADMIN_URL?>stores/updateStatus/deactive/<?=$storeslist['id'];?>" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a>
                                        <?php }else if($storeslist['status'] == '0'){ ?>
                                        <a href="<?=ADMIN_URL?>stores/updateStatus/active/<?=$storeslist['id'];?>" class="btn btn-danger"><i class="fa fa-thumbs-down" aria-hidden="true"></i></a>
                                        <?php } ?>   
                                    </td>
                                    
                                    <td> <a href="<?php echo ADMIN_URL.'stores/lockers/'.$storeslist['id']; ?>">Lockers </a>| Edit | Delete  </td>   
                                </tr>
                                <?php  $i++; } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    </div>
</div>