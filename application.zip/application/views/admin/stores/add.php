<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Store</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
            <div class="title-action">
            <a href="<?php echo ADMIN_URL.'stores' ?>" class="btn btn-primary">Back</a>      
            </div>
            </ol>
        </div>

        <h1 class="page-title"> Add Store 
            <small>&nbsp;</small>
        </h1>
                    
        <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
                            <?php echo form_open_multipart('admin/stores/add',array('class'=>'form-horizontal')); ?>
                                <?php echo $this->session->flashdata('response'); ?>

                                <div class="row">
                                <div class="col-md-12">
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Name</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" placeholder="Store Name" name="store_name" type="text" value="<?php echo set_value('store_name'); ?>" required>
                                        <span class="help-block m-b-none"><?php echo form_error('store_name'); ?></span>
                                    </div>
                                </div>
                                </div>
                                
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Address</label>
                                    <div class="col-sm-10"><input class="form-control" placeholder="Address" name="address" value="<?php echo set_value('address'); ?>" type="text" required><span class="help-block m-b-none"><?php echo form_error('address'); ?></span></div>
                                </div>
                                </div>
                                </div>
                                

                                <div class="row">
                                <div class="col-md-12">
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Address2</label>
                                    <div class="col-sm-10"><input class="form-control" name="address2" type="text" placeholder="Address2" value="<?php echo set_value('address2'); ?>"></div>
                                </div>
                                </div>
                                
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">City</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="city" type="text" placeholder="City" value="<?php echo set_value('city'); ?>"><span class="help-block m-b-none"><?php echo form_error('city'); ?></span> </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                

                                <div class="row">
                                <div class="col-md-12">
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">State</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="state" type="text" placeholder="City" value="<?php echo set_value('city'); ?>"> </div>
                                </div>
                                </div>
                                

                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Zip Code</label>
                                  <div class="col-sm-10"><input class="form-control" name="zip" type="text"></div>
                                </div>
                                </div>
                                </div>
                                </div>
                                
                                <div class="row">
                                <div class="col-md-12">
                                <div class="col-md-6">
                                    <div class="form-group"><label class="col-sm-2 control-label">lattitude</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" name="lattitude" type="text" placeholder="lattitude" value="<?php echo set_value('lattitude'); ?>"> </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Longitude</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="longitude" type="text" placeholder="longitude" value="<?php echo set_value('longitude'); ?>"> </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                
                                <div class="row">
                                <div class="col-md-12">
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Open Hours</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="open_hours" type="text" placeholder="Open Hours" value="<?php echo set_value('open_hours'); ?>"> </div>
                                </div>
                                </div>
                                
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Working Days</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="working_days" type="text" placeholder="Working Days" value="<?php echo set_value('working_days'); ?>"> </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                
                                <div class="row">
                                <div class="col-md-12">
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Contact Person Name</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="contact_name" type="text" placeholder="Contact Person Name" value="<?php echo set_value('contact_name'); ?>"> </div>
                                </div>
                                </div>
                                
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Contact Email</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="contact_email" type="text" placeholder="Contact Email" value="<?php echo set_value('contact_email'); ?>"> </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                

                                <div class="row">
                                <div class="col-md-12">
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Contact Phone</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="contact_phone" type="text" placeholder="Contact Phone" value="<?php echo set_value('contact_phone'); ?>"> </div>
                                </div>
                                </div>

                                
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Note</label>

                                    <div class="col-sm-10 " >
                                          <textarea class="form-control" rows="5" placeholder="Note" name="notes" ></textarea></div>
                                    </div>
                                    </div>
                                    </div>
                                    </div>

                                    <div class="row">
                                <div class="col-md-12">
                                <div class="col-md-6">
                                <div class="form-group"><label class="col-sm-2 control-label">Status</label>
                                    <div class="col-sm-10">
                                        <select name="status" class="form-control">
                                              <option value="1">Active</option>
                                              <option value="2">Inactive</option>
                                        </select>   
                                </div>
                                </div>
                                </div>
                                </div>
                                
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>