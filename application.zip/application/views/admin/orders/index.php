<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Orders</span>
                </li>
            </ul>
        </div>

        <!-- <div class="pull-right">
            <ol>
                <div class="title-action">
                   <a href="<?php echo ADMIN_URL.'customers/add' ?>" class="btn btn-primary">Add</a>
                </div>
            </ol>
        </div> -->

        <h1 class="page-title"> Orders List
            <small>&nbsp;</small>
        </h1>

       
                       
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>S.No.</th>
                                        <th>Order Number</th>
                                        <th>Customer Name</th>
                                        <th>Store Name</th>
                                        <th>Lockers</th>
                                        <th>Services</th>
                                        <th>Status</th>
                                        <th>Added Date</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
                                    $i = 1;
                                    if(!empty($orders)){
                                    foreach ($orders as $orderslist) { ?>
                                    <tr>
                                        <td> <?php echo $i; ?> </td>
                                        <td> <?php echo $orderslist['order_number']; ?> </td>
                                        <td> <?php echo $orderslist['firstname']." ".$orderslist['lastname']; ?> </td>
                                        
                                        <td> <?php echo $orderslist['store_name']; ?> </td>
                                        <td> <?php echo $orderslist['locker_name']; ?> </td>
                                        <td> <?php echo $orderslist['services']; ?> </td>
                                        <td> <?php  if($orderslist['order_status'] == 1){ echo "Pending"; }else{ echo "Pending"; } ?> </td>
                                        <td> <?php echo date('d/m/Y',strtotime($orderslist['created_date'])); ?> </td>
                                        
                                    </tr>
                                    <?php $i++; } }else{ ?>
                                    <tr>
                                        <td colspan="8" style="color: red"><center>No orders found </center></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>