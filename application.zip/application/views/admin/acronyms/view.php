<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Customers</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                   <a href="<?php echo ADMIN_URL.'customers' ?>" class="btn btn-primary">Back</a>
                </div>
            </ol>
        </div>

        <h1 class="page-title"> Customer Details
            <small>&nbsp;</small>
        </h1>

        
                       
        <div class="row">
            <div class="col-md-6">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                               <thead><tr><th>Personal Details</th></tr></thead>
                                <tbody>
                                    <tr>
                                        <td>Name :</td>
                                        <td><?php echo $customers['firstname'].' '.$customers['lastname']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Email : </td>
                                        <td><?php echo  $customers['email']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Phone Number : </td>
                                        <td><?php echo  $customers['phonenumber']; ?></td>
                                    </tr>

                                    <tr>
                                        <td>Status : </td>
                                        <td><?php   if($customers['status'] == 1 ){ echo "Active"; }else{ echo "Inactive"; } ?></td>
                                    </tr>
                                    </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                               <thead><tr><th>Payments Details</th></tr></thead>
                                <tr>
                                    <td>Card Number</td>
                                    <?php
                                    if(!empty($customers['cardnumber']) && $customers['cardnumber']!=''){
                                        $newstring = substr($customers['cardnumber'], -4); ?>
                                        <td>xxxx xxxx xxxx <?php echo $newstring; ?></td>
                                    <?php }else{ ?>
                                        <td>&nbsp;&nbsp;</td>
                                    <?php } ?>
                                    
                                    
                                </tr>

                                <tr>
                                    <td>Expiry</td>
                                    <?php if(!empty($customers['expirymonth']) && $customers['expirymonth']!=''){ ?>
                                    <td>xx/xx</td>
                                    <?php }else{ ?>
                                       <td>&nbsp;&nbsp;</td>
                                    <?php } ?> 
                                </tr>

                                <tr>
                                    <td>CVV</td>
                                    <?php if(!empty($customers['cvv']) && $customers['cvv']!=''){ ?>
                                    <td>xx/xx</td>
                                    <?php }else{ ?>
                                       <td>&nbsp;&nbsp;</td>
                                    <?php } ?>
                                </tr>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                               <thead><tr><th>Residentils Address</th></tr></thead>
                                <tbody>
                                    <tr>
                                    <td>Address</td>
                                    <td><?php echo $customers['residentail_address']['address'].' '.$customers['residentail_address']['address2']; ?></td>
                                </tr>

                                <tr>
                                    <td>City</td>
                                    <td><?php echo $customers['residentail_address']['city']; ?></td>
                                </tr>

                                <tr>
                                    <td>State </td>
                                    <td><?php echo $customers['residentail_address']['state']; ?></td>
                                </tr>

                                <tr>
                                    <td>ZIP </td>
                                    <td><?php echo $customers['residentail_address']['postal_code']; ?></td>
                                </tr>
                                    </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                               <thead><tr><th>Billing Address</th></tr></thead>
                                <tr>
                                    <td>Address</td>
                                    <td><?php echo $customers['billing_address']['address'].' '.$customers['billing_address']['address2']; ?></td>
                                </tr>

                                <tr>
                                    <td>City</td>
                                    <td><?php echo $customers['billing_address']['city']; ?></td>
                                </tr>

                                <tr>
                                    <td>State </td>
                                    <td><?php echo $customers['billing_address']['state']; ?></td>
                                </tr>

                                <tr>
                                    <td>ZIP </td>
                                    <td><?php echo $customers['billing_address']['postal_code']; ?></td>
                                </tr>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                               <thead><tr><th>Prefernce</th></tr></thead>
                                <tbody>
                                    <tr>
                                    <td>Language</td>
                                    <td><?php   if($customers['preferred_language'] != 'en'  && $customers['preferred_language'] != ''){ echo "Francais"; }else{ echo "English"; } ?></td>
                                </tr>

                                <tr>
                                    <td>Email Notification</td>
                                    <td><?php   if($customers['email_notification'] == 1 ){ echo "Yes"; }else{ echo "No"; } ?></td>
                                </tr>

                                <tr>
                                    <td>SMS Notification </td>
                                    <td><?php   if($customers['text_sms'] == 1 ){ echo "Yes"; }else{ echo "No"; } ?></td>
                                </tr>

                                <tr>
                                    <td>Push Notification </td>
                                    <td><?php   if($customers['push_notification'] == 1 ){ echo "Yes"; }else{ echo "No"; } ?></td>
                                </tr>
                                    </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="clearfix"></div>
    </div>
</div>