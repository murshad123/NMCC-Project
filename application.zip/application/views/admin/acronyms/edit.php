<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashboard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL.'acronyms' ?>" ><span>Acronyms</span></a><i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Edit Acronyms</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'acronyms' ?>" class="btn btn-primary">Back</a></div>
            </ol>
        </div>


        <h1 class="page-title"> Edit Acronyms
            <small>&nbsp;</small>

        </h1>

     <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
       <form action="<?php echo ADMIN_URL.'acronyms/edit/'.$acronym_id;?>" class="form-horizontal" method="post" accept-charset="utf-8">                           
                                <?php echo $this->session->flashdata('response'); ?>
                                <div><label class="col-sm-2 control-label"></label></div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label">Acronym</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="Enter Acronym" name="acronym" type="text" value="<?php echo $acronyms['acronym']; ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('acronym'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label">Definition</label>
                                                <div class="col-sm-10">
                                                  <input class="form-control" placeholder="Enter Definition of Acronym Word" type="text" name="definition" value="<?php echo $acronyms['definition'] ; ?>" required>
                                                  <span class="help-block m-b-none"><?php echo form_error('definition'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                     <div class="row">
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label"> Status</label>
                                              <div class="col-sm-10">
                                                <select name="status" class="form-control">
                                                  <option value="1">Active</option>
                                                  <option value="0">Inactive</option>
                                                </select>
                                              </div>
                                            </div>
                                          </div> 
                                        </div>
                                        
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <input class="btn btn-primary" type="submit" name="submit" value="submit">
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>