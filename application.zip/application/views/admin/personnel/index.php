<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'personnel' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Personal</span>
                </li>
            </ul>
        </div>

    <div class="pull-right">
            <ol>
                <div class="title-action">
                   <a href="<?php echo ADMIN_URL.'personnel/add' ?>" class="btn btn-primary">Add</a>
                </div>
            </ol>
        </div>

        <h1 class="page-title"> Personal List
            <small>&nbsp;</small>
        </h1>
          <?php echo $this->session->flashdata('response'); ?>              
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-body">
                        <div class="table-scrollable">

                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>S.No.</th>
                                        <th>Images</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone Number</th>
                                        <th>Role</th>
                                        <th>Designation</th>
                                        <th>Resume</th> 
                                        
                                        
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
                                    $i = 1;
                                    foreach ($customers as $customerslist) { ?>
                                    <tr>
                                        <td> <?php echo $i; ?> </td>
                                         <?php if(!empty($customerslist['image'])){?>
                                            <td>
                                                <img style="height: 60px; width: 60px;" src="<?php echo  ASSETS_URL.'dist/personnel_img/'.$customerslist['image'];?>" />
                                            </td>
                                          <?php } else { ?>
                                            <td>
                                                <img style="height: 60px; width: 60px;" src="<?php echo  ASSETS_URL.'img/no-image.jpg'?>" />
                                            </td>

                                         <?php   }   ?>
                                       
                                        <td> <?php echo ucwords($customerslist['name']); ?> </td>
                                        <td> <?php echo $customerslist['email']; ?> </td>
                                        <td> <?php echo $customerslist['phonenumber']; ?> </td>
                                        
                                        <td> <?php if($customerslist['role']== 1){ echo "System Manager"; }else if($customerslist['role']== 2){ echo "Data Manager"; }?> </td>
                                        <td> <?php echo $customerslist['designation']; ?> </td>


                <?php if(!empty($customerslist['resume'])){?>
                                    <td>
                                        <a  class="btn btn-info" href="<?php echo  ASSETS_URL.'dist/personnel_pdf/'.$customerslist['resume'];?>"><i class="fa fa-file" aria-hidden="true"></i>
                                            
                                        </a>
                                       
                                    </td>
                <?php } else { ?>
                                              <td class="text-center"><a  class="btn btn-warning" href="javascript:void(0)">N/A</a>
                                            </td>
                                        
                                            

                    <?php   }   ?>

                       
                                        


                                        <td><?php if($customerslist['status'] == '1'){ ?>
                                        <a href="<?=ADMIN_URL?>personnel/updateStatus/deactive/<?=$customerslist['id'];?>" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a>
                                        <?php }else if($customerslist['status'] == '0'){ ?>
                                        <a href="<?=ADMIN_URL?>personnel/updateStatus/active/<?=$customerslist['id'];?>" class="btn btn-danger"><i class="fa fa-thumbs-down" aria-hidden="true"></i></a>
                                        <?php } ?> </td> 
                                        
                                        

                                       <td> 
                                       <a href="<?php echo ADMIN_URL.'personnel/edit/'.$customerslist['id'] ?>" class="btn btn-success"><i class="fa fa-pencil" aria-hidden="true"></i></a> | <a href="javascript:void(0);" onclick="checkdelete('<?php echo $customerslist['id']; ?>')" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                        
                                       </td>
                                    </tr>
                                    <?php $i++; } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<script type="text/javascript">
    function checkdelete(id) {
        var url = '<?php echo  ADMIN_URL.'personnel/delete/'; ?>';
        if (confirm('Are you sure to delete ?')) {
           window.location.href = url+id;
        } else {
           return false;
        }
        
    }
</script>