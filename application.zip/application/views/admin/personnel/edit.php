<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo ADMIN_URL.'dashboard' ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo ADMIN_URL.'personnel' ?>" ><span>Personnel</span></a><i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Edit Personal Details</span>
                </li>
            </ul>
        </div>

        <div class="pull-right">
            <ol>
                <div class="title-action">
                  <a href="<?php echo ADMIN_URL.'personnel' ?>" class="btn btn-primary">Back</a></div>
            </ol>
        </div>


        <h1 class="page-title"> Edit Personal Details
            <small>&nbsp;</small>

        </h1>

     <div class="row">
            <div class="col-lg-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="ibox-content">
			 <form action="<?php echo ADMIN_URL.'personnel/edit/'.$member_id;?>" enctype="multipart/form-data" class="form-horizontal" method="post" accept-charset="utf-8">                           
                                <?php echo $this->session->flashdata('response'); ?>
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label">Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" placeholder="Enter Name" name="name" type="text" value="<?php echo $memberdetails['name']; ?>" required>
                                                    <span class="help-block m-b-none"><?php echo form_error('name'); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label class="col-sm-2 control-label">Phone Number</label>
                                               <div class="col-sm-10">
                                                 <input class="form-control" name="phonenumber" type="text" placeholder="Phone Number" value="<?php echo $memberdetails['phonenumber']; ?>" required>
                                                <span class="help-block m-b-none"><?php echo form_error('phonenumber'); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                      <div class="col-md-12">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                           <label class="col-sm-2 control-label">Designation</label>
                                             <div class="col-sm-10">
                                             <input class="form-control" placeholder="Designation" name="designation" type="text" value="<?php echo $memberdetails['designation']; ?>" required>
                                             <span class="help-block m-b-none"><?php echo form_error('designation'); ?></span>
                                            </div>
                                          </div>
                                        </div>
                    
                                        <div class="col-md-6">
                                          <div class="form-group">
                                           <label class="col-sm-2 control-label">Email</label>
                                            <div class="col-sm-10">
                                             <input class="form-control" placeholder="Email" name="email" type="email" value="<?php echo $memberdetails['email']; ?>" required>
                                             <span class="help-block m-b-none"><?php echo form_error('email'); ?></span>
                                            </div>
                                          </div>
                                        </div>
                    
                    
                                        </div>
                                    </div>

                                     <div class="row">
                                      <div class="col-md-12">
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Role</label>
                                            <div class="col-sm-10">
                                            <select name="role"   class="form-control">
                                                  <option value="">Select Roles</option>
                                                  <option value="1" <?php if($memberdetails['role'] == '1'){ echo "selected"; } ?>>System Manager</option>
                                                  <option value="2" <?php if($memberdetails['role'] == '2'){ echo "selected"; } ?>>Data Manager</option>
                                                  
                                                </select>
                                          </div>
                                        </div>
                                        </div>
                    
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label"> Status</label>
                                              <div class="col-sm-10">
                                                <select name="status" class="form-control">
                                                  <option value="1" <?php if($memberdetails['status'] == '1'){ echo "selected"; } ?>>Active</option>
                                                  <option value="0" <?php if($memberdetails['status'] == '0'){ echo "selected"; } ?>>Inactive</option>
                                                </select>
                                              </div>
                                            </div>
                                          </div> 
                                        </div>
                                    </div>

                                    <div class="row">
                                      <div class="col-md-12">
                                         <div class="col-md-6">
                                          <div class="form-group">
                                            <label class="col-sm-2 control-label">Upload Image</label>
                                             <div class="col-sm-10">
                                              <?php if(!empty($memberdetails['image'])){?>
                                           <img style="height: 60px; width: 60px;" src="<?php echo  ASSETS_URL.'dist/personnel_img/'.$memberdetails['image'];?>" />
                                            
                                          <?php } else { ?>
                                            
                                                <img style="height: 60px; width: 60px;" src="<?php echo  ASSETS_URL.'dist/personnel_img/img.jpg'?>" />  
                                         <?php   }   ?>
                                             <input class="form-control"  name="file" type="file">
                                             <span class="help-block m-b-none"><?php echo form_error('file'); ?></span>
                                            </div>
                                          </div>
                                        </div>
                    
                  
                                        </div>
                                    </div>
                                   <!--      <div class="col-md-6">
                                     <div class="form-group">
                                       <label class="col-sm-2 control-label">Password</label>
                                   
                                       <div class="col-sm-10">
                                       <input class="form-control" name="password" type="text" placeholder="Password" value="<?php echo set_value('password'); ?>" required>
                                       <span class="help-block m-b-none"><?php echo form_error('password'); ?></span>
                                       </div>
                                     </div>
                                   </div> -->
                                        </div>
                                    </div>   
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <input class="btn btn-primary" type="submit" name="submit" value="Update">
                                    </div>
                                </div>
                                
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                            
                            
                        </div>
                        <div class="clearfix"></div>
                        <!-- END DASHBOARD STATS 1-->
                        

                        </div>
                        </div>