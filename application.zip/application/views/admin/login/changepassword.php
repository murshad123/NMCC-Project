 




   <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-8">
                    <h2>Change Password</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo BASE_URL.'admin/dashboard' ?>">Dashboard</a>
                        </li> 
                        <li class="active">
                            <strong>Change Password</strong>
                        </li>
                    </ol>
                </div>
              <!--  <div class="col-sm-4">
                   <div class="title-action">
                       <a href="<?php echo BASE_URL.'admin/localisation/orderStatus' ?>" class="btn btn-primary">Back</a>
                   </div>
               </div> -->
            </div>
              <?php echo $this->session->flashdata('response'); ?>
            <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Change Password</h5>
                        </div>
                            
                        
                        <div class="ibox-content">
                           <?php $data=array( 'class'=>'form-horizontal','name'=>'submit','id'=>'form'); ?>
                           <?php echo form_open_multipart('admin/changepassword',$data); ?>

                                <div class="form-group"><label class="col-sm-2 control-label">New Password<span style="color:red;">*</span></label>
                                    <div class="col-sm-10"><input type="password"  placeholder="New Password" id="password"  name="password" class="form-control"  value="<?php echo set_value('password'); ?>" required>
                                    <?php echo form_error('password'); ?></div>
                                </div>

                                <div class="form-group"><label class="col-sm-2 control-label">Confirm Password<span style="color:red;">*</span></label>
                                    <div class="col-sm-10"><input type="password"  placeholder="Confirm Password" id="confirm_password"  name="confirm_password" class="form-control"  value="<?php echo set_value('confirm_password'); ?>" required>
                                    <?php echo form_error('confirm_password'); ?></div>
                                </div>


                                
                                <?php //if(!empty($permission['edit'])){ ?>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        
                                        <button class="btn btn-primary" type="submit">Change</button>
                                    </div>
                                </div>
                                <?php //} ?>
                                <?php  echo form_close(); ?>
                            
                        </div>
                    </div>
                </div>
            </div>
            </div>


