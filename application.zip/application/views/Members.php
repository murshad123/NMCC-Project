<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Members extends MY_Controller {

	/*public function __construct() {
           parent::__construct();
           $this->load->model('admin/customer_modal','model_customer');
    }*/
    
	public function  index(){
		$this->adminloginCheck();
		//$this->data['customers'] = $this->model_customer->getcustomers();
		$this->data['customers'] = array();
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function  add(){
		 
	        $this->adminloginCheck();

			$dataArray['firstname'] = $_POST['firstname'];
			$dataArray['email'] = $_POST['email'];
			$dataArray['phonenumber'] = $_POST['phonenumber'];
			$dataArray['email_notification'] = $_POST['email_notification'];
			$dataArray['created_date'] = date('Y-m-d h:i:s');
			$dataArray['status'] = $_POST['status'];
                      			
			
			if($customer_id = $this->common_model->addRow($table,$dataArray)){

				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Customers Successfully Added.</div>');
				redirect('admin/members','refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add Customer.</div>');
			}
		}
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method());	
	}

	public function  view($customer_id){
		$this->adminloginCheck();
		$this->data['customers'] = $this->model_customer->getcustomersdetails($customer_id);
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}

	public function updateStatus($status,$id){
		$this->adminloginCheck();
		if($status == 'deactive'){
           $statusnew = '0';
		}else{
           $statusnew = '1';
		}

        $this->db->where('customers.id', $id);
        $this->db->update('customers', array('status' => $statusnew));
        $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable" status successfully Updated.</div>');
        redirect($_SERVER['HTTP_REFERER'],'refresh');
    }

    public function delete($customer_id){
		$this->adminloginCheck();
	    if($this->model_customer->deleteCustomers($customer_id)){
	      $this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Customers Deleted.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }else{
	      $this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Error While Deleting.</div>');
	      redirect($_SERVER['HTTP_REFERER']);
	    }
  	}

  	public function  edit($customer_id){
		$this->adminloginCheck();
		$this->data['customers'] = $this->model_customer->getcustomersdetails($customer_id);
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('firstname', 'First Name', 'required');
		if (!$this->form_validation->run() == FALSE) {
			$table = 'customers';
			$dataArray['firstname'] = $_POST['firstname'];
			$dataArray['lastname'] = $_POST['lastname'];
			$dataArray['email'] = $_POST['email'];
			$dataArray['phonenumber'] = $_POST['phonenumber'];
			$dataArray['alternatephonenumber'] = $_POST['alternatephonenumber'];
			$dataArray['cardnumber'] = $_POST['cardnumber'];
			$dataArray['cvv'] = $_POST['cvv'];
			$dataArray['expirymonth'] = $_POST['expirymonth'];
			$dataArray['expiryyear'] = $_POST['expiryyear'];
			$dataArray['email_notification'] = $_POST['email_notification'];
			$dataArray['created_date'] = date('Y-m-d h:i:s');
			$dataArray['status'] = $_POST['status'];
			if($this->common_model->updateRow($table,$dataArray,'id',$customer_id)){
				if(!empty($_POST['residentails'])){
                     $dataArray1['address'] = $_POST['residentails']['address'];
                     $dataArray1['address2'] = $_POST['residentails']['address2'];
                     $dataArray1['city'] = $_POST['residentails']['city'];
                     $dataArray1['state'] = $_POST['residentails']['state'];
                     $dataArray1['postal_code'] = $_POST['residentails']['postal_code'];
                     $dataArray1['customer_id'] = $customer_id;
                     $dataArray1['address_type'] = 1;
                     $dataArray1['status'] = 1;
                     $dataArray1['created_date'] = date('Y-m-d h:i:s');

				}

				if(!empty($_POST['billing'])){
                     $dataArray2['address'] = $_POST['billing']['address'];
                     $dataArray2['address2'] = $_POST['billing']['address2'];
                     $dataArray2['city'] = $_POST['billing']['city'];
                     $dataArray2['state'] = $_POST['billing']['state'];
                     $dataArray2['postal_code'] = $_POST['billing']['postal_code'];
                     $dataArray2['customer_id'] = $customer_id;
                     $dataArray2['address_type'] = 2;
                     $dataArray2['status'] = 1;
                     $dataArray2['created_date'] = date('Y-m-d h:i:s');

				}

				$address1 = $this->common_model->addRow('address',$dataArray1);
				$address2 = $this->common_model->addRow('address',$dataArray2);


				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Customers Successfully Added.</div>');
				redirect('admin/customers','refresh');
			}
			else {
				$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to add Customer.</div>');
			}
		}
		$this->load->admin($this->router->fetch_class().'/'.$this->router->fetch_method(),$this->data);	
	}


	
		



	

}