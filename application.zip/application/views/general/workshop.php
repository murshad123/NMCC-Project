<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="<?php echo ASSETS_URL ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">Events</h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">Workshops</span>
      </div>
    </div>
  </header>

 <div class="event-schedule-area-two bg-color comman-main">
            
        </div>
<!-- workshop html start -->
<div class="event-schedule-area-two bg-color comman-main ">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-text">
                            <h2>Workshops</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <div class="title-text">
                                <h4 class="head">PREVIOUS YEAR EVENTS</h4>
                            </div>
                           
                        </div>
                    </div>
                    <!-- /.col end-->
                </div>
                <!-- row end-->

                <div class="row">
                    <div class="col-lg-12">
                       <ul class="nav custom-tab" id="myTab" role="tablist">
                        <?php
                        if(!empty($previousworkshop)){
                        foreach ($previousworkshop as $prevwrkkey => $prevwrkvalue) { ?>
                            <li class="nav-item">
                                <a class="nav-link <?php if($prevwrkkey == '0'){ echo "active"; } ?>" id="home-taThursday-<?php echo $prevwrkkey; ?>" data-toggle="tab" href="#previousworshopevent-<?php echo key($prevwrkvalue); ?>"   role="tab" aria-controls="home" aria-selected="true"><?php echo key($prevwrkvalue); ?></a>
                            </li>
                        <?php $prevworkshop[key($prevwrkvalue)] = $prevwrkvalue[key($prevwrkvalue)]; }} ?>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <?php 
                            if(!empty($prevworkshop)){
                                $arraykeys3 = array_keys($prevworkshop); 
                                foreach ($prevworkshop as $prevworkshopkey => $prevworkshopvalue) { 
                                    ?>      
                            <div class="tab-pane fade <?php if($arraykeys3['0'] == $prevworkshopkey){ echo "show active"; } ?>" id="previousworshopevent-<?php echo $prevworkshopkey; ?>" role="tabpanel" aria-labelledby="home-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="text-center" scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php
                                           if(!empty($prevworkshopvalue)){
                                            foreach ($prevworkshopvalue as $prwpkey => $prwpvalue) { ?>
                                                
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span><?php echo $prwpvalue['start_date']; ?></span>
                                                        <p><?php echo $prwpvalue['end_date']; ?></p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="<?php echo BASE_URL.'general/eventdetails/'.$prwpvalue['id']; ?>"><?php echo $prwpvalue['event_name']; ?></a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <?php
                                                        if(!empty($prwpvalue['presenter_image'])){
                                                            $imgsrc = ASSETS_URL.'dist/pre_img/'.$prwpvalue['presenter_image'];
                                                        }else{
                                                            $imgsrc = ASSETS_URL.'img/no-image.jpg';
                                                        } ?>
                                                        
                                                        <img src="<?php echo $imgsrc;?>">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#"><?php echo $prwpvalue['presenter']; ?></a><span><?php echo $prwpvalue['presenter_designation']; ?></span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="javascript:void(0)" onclick="alert('PDF not found');">PDF</a>
                                                    </div>
                                                </td>
                                            </tr>

                                            <?php }} ?>   
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php } } ?>    
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- future section start -->
        <div class="event-schedule-area-two bg-color comman-main padding ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <div class="title-text">
                                <h4 class="head">CURRENT/FUTURE EVENTS</h4>
                            </div>
                           
                        </div>
                    </div>
                    <!-- /.col end-->
                </div>
                <!-- row end-->
                <div class="row">
                    <div class="col-lg-12">
                    
                          
                        <ul class="nav custom-tab" id="myTab" role="tablist">
                        <?php
                    if(!empty($currentworkshop)){
                        foreach ($currentworkshop as $currentworkshopkey => $currentworkshopvalue) { ?>
                            <li class="nav-item">
                                <a class="nav-link <?php if($currentworkshopkey == '0'){ echo "active"; } ?>" id="home-taThursday-<?php echo $currentworkshopkey; ?>" data-toggle="tab" href="#currentworkshopevent-<?php echo key($currentworkshopvalue); ?>"   role="tab" aria-controls="home" aria-selected="true"><?php echo key($currentworkshopvalue); ?></a>
                            </li>
                        <?php $currentworkshop1[key($currentworkshopvalue)] = $currentworkshopvalue[key($currentworkshopvalue)]; }} ?>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <?php 
                            if(!empty($currentworkshop1)){
                                $arraykeys4 = array_keys($currentworkshop1); 
                                foreach ($currentworkshop1 as $currentworkshop1key => $currentworkshop1value) { 
                                    ?>      
                            <div class="tab-pane fade <?php if($arraykeys4['0'] == $currentworkshop1key){ echo "show active"; } ?>" id="currentworkshopevent-<?php echo $currentworkshop1key; ?>" role="tabpanel" aria-labelledby="home-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="text-center" scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php
                                           if(!empty($currentworkshop1value)){
                                            foreach ($currentworkshop1value as $curwrkkey => $curwrkvalue) { ?>
                                                
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span><?php echo $curwrkvalue['start_date']; ?></span>
                                                        <p><?php echo $curwrkvalue['end_date']; ?></p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="<?php echo BASE_URL.'general/eventdetails/'.$curwrkvalue['id']; ?>"><?php echo $curwrkvalue['event_name']; ?></a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                        <?php
                                                        if(!empty($curwrkvalue['presenter_image'])){
                                                            $imgsrc = ASSETS_URL.'dist/pre_img/'.$curwrkvalue['presenter_image'];
                                                        }else{
                                                            $imgsrc = ASSETS_URL.'img/no-image.jpg';
                                                        } ?>
                                                        
                                                        <img src="<?php echo $imgsrc;?>">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#"><?php echo $curwrkvalue['presenter']; ?></a><span><?php echo $curwrkvalue['presenter_designation']; ?></span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="javascript:void(0)" onclick="alert('PDF not found');">PDF</a>
                                                    </div>
                                                </td>
                                            </tr>

                                            <?php }} ?>
                                            
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <?php } } ?>
                            
                            
                            
                            
                        </div>
                        
                    </div>
                   
                </div>
            </div>
        </div>
        <!-- future section end -->
<!-- workshop html end -->
