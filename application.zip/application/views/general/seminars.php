

<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="<?php echo ASSETS_URL ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">Events</h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">Seminars</span>
      </div>
    </div>
  </header>

 <div class="event-schedule-area-two bg-color comman-main">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-text">
                            <h2>Seminars</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <div class="title-text">
                                <h4 class="head">PREVIOUS YEAR EVENTS</h4>
                            </div>
                           
                        </div>
                    </div>
                    <!-- /.col end-->
                </div>

                <?php
              ?>
                <div class="row">
                    <div class="col-lg-12">
                    
                          
                    <ul class="nav custom-tab" id="myTab" role="tablist">
                        <?php
                    if(!empty($previousseminars)){
                        foreach ($previousseminars as $prekey => $prevalue) { ?>
                            <li class="nav-item">
                                <a class="nav-link <?php if($prekey == '0'){ echo "active"; } ?>" id="home-taThursday-<?php echo $prekey; ?>" data-toggle="tab" href="#previousseminar-<?php echo key($prevalue); ?>"   role="tab" aria-controls="home" aria-selected="true"><?php echo key($prevalue); ?></a>
                            </li>
                        <?php $prevsemi[key($prevalue)] = $prevalue[key($prevalue)]; }} ?>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <?php 
                            if(!empty($prevsemi)){
                                $arraykeys2 = array_keys($prevsemi); 
                                foreach ($prevsemi as $prevsemikey => $prevsemivalue) { 
                                    ?>      
                            <div class="previousseminararry tab-pane fade <?php if($arraykeys2['0'] == $prevsemikey){ echo "show active"; } ?>" id="previousseminar-<?php echo $prevsemikey; ?>" role="tabpanel" aria-labelledby="home-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="text-center" scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php
                                           if(!empty($prevsemivalue)){
                                            
                                            foreach ($prevsemivalue as $pevsemkey => $pevsemvalue) { ?>
                                                
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span><?php echo $pevsemvalue['start_date']; ?></span>
                                                        <p><?php echo $pevsemvalue['end_date']; ?></p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                    <div class="event-wrap">
                                                        <h3><a href="<?php echo BASE_URL.'general/eventdetails/'.$pevsemvalue['id']; ?>"><?php echo $pevsemvalue['event_name']; ?></a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                         <?php
                                                        if(!empty($pevsemvalue['presenter_image'])){
                                                            $imgsrc = ASSETS_URL.'dist/pre_img/'.$pevsemvalue['presenter_image'];
                                                        }else{
                                                            $imgsrc = ASSETS_URL.'img/no-image.jpg';
                                                        } ?>
                                                        
                                                        <img src="<?php echo $imgsrc;?>">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#"><?php echo $pevsemvalue['presenter']; ?></a><span><?php echo $pevsemvalue['presenter_designation']; ?></span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="javascript:void(0)" onclick="alert('PDF not found');">PDF</a>
                                                    </div>
                                                </td>
                                            </tr>

                                            <?php }} ?>
                                            
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php } } ?>  
                        </div>
                        
                    </div>
                   
                </div>


            </div>
        </div>

        <!-- future section start -->
        <div class="event-schedule-area-two bg-color comman-main">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <div class="title-text">
                                <h4 class="head">CURRENT/FUTURE SEMINARS</h4>
                            </div>
                           
                        </div>
                    </div>
                    <!-- /.col end-->
                </div>
                <!-- row end-->
                <div class="row">
                    <div class="col-lg-12">
                    
                          
                        <ul class="nav custom-tab" id="myTab" role="tablist">
                        <?php
                    if(!empty($currentseminars)){
                        foreach ($currentseminars as $key => $value) { ?>
                            <li class="nav-item">
                                <a class="nav-link <?php if($key == '0'){ echo "active"; } ?>" id="home-taThursday-<?php echo $key; ?>" data-toggle="tab" href="#currentseminar-<?php echo key($value); ?>"   role="tab" aria-controls="home" aria-selected="true"><?php echo key($value); ?></a>
                            </li>
                        <?php $currentsemi[key($value)] = $value[key($value)]; }} ?>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <?php 
                            if(!empty($currentsemi)){
                            	$arraykeys1 = array_keys($currentsemi); 
                                foreach ($currentsemi as $currentsemikey => $currentsemivalue) { 
                                	?>      
                            <div class="currentseminararry tab-pane fade <?php if($arraykeys1['0'] == $currentsemikey){ echo "show active"; } ?>" id="currentseminar-<?php echo $currentsemikey; ?>" role="tabpanel" aria-labelledby="home-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="text-center" scope="col">Dates </th>
                                                <th scope="col">Course Title</th>
                                                <th scope="col">Seminar Presenter/Workshop Director</th>
                                                <th scope="col">Seminar/Workshop Report</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php
                                           if(!empty($currentsemivalue)){
                                           
                                            foreach ($currentsemivalue as $csmkey => $csmvalue) { ?>
                                                
                                            <tr class="inner-box">
                                                <th scope="row">
                                                    <div class="event-date">
                                                        <span><?php echo $csmvalue['start_date']; ?></span>
                                                        <p><?php echo $csmvalue['end_date']; ?></p>
                                                    </div>
                                                </th>
                                               
                                                <td>
                                                
                                                    <div class="event-wrap">
                                                        <h3><a href="<?php echo BASE_URL.'general/eventdetails/'.$csmvalue['id']; ?>"><?php echo $csmvalue['event_name']; ?></a></h3>
                                                       
                                                    </div>
                                                </td>
                                                 <td>
                                                    <div class="event-wrap">
                                                      <div class="event-img">
                                                         <?php
                                                        if(!empty($csmvalue['presenter_image'])){
                                                            $imgsrc = ASSETS_URL.'dist/pre_img/'.$csmvalue['presenter_image'];
                                                        }else{
                                                            $imgsrc = ASSETS_URL.'img/no-image.jpg';
                                                        } ?>
                                                        
                                                        <img src="<?php echo $imgsrc;?>">
                                                      </div>
                                                         <div class="meta">
                                                            <div class="organizers">
                                                              <h3>
                                                                <a href="#"><?php echo $csmvalue['presenter']; ?></a><span><?php echo $csmvalue['presenter_designation']; ?></span></h3>

                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="primary-btn">
                                                        <a class="btn-primary" href="javascript:void(0)" onclick="alert('PDF not found');">PDF</a>
                                                    </div>
                                                </td>
                                            </tr>

                                            <?php }} ?>
                                            
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <?php } } ?>
                            
                            
                            
                            
                        </div>
                        
                    </div>
                   
                </div>
                
                
            </div>
        </div>
        <!-- future section end -->




        <!-- future section start -->
    
        <!-- future section end -->
<!-- workshop html end -->
