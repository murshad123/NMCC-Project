
<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="<?php echo ASSETS_URL ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">News Details</h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">News Details</span>
      </div>
    </div>
  </header>

 <section class="post-content-area single-post-area comman-main">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 posts-list">
          <div class="single-post row">
            <div class="col-lg-12">
              <div class="feature-img">
               <?php
                  if(!empty($newsdetail['image'])){
                    $imgsrc = ASSETS_URL.'dist/news_img/'.$newsdetail['image'];
                  }else{
                    $imgsrc = ASSETS_URL.'img/no-image.jpg';
                 } ?>
                <img class="img-fluid" src="<?php echo $imgsrc; ?>" alt="">
              </div>
            </div>
            <div class="col-lg-2  col-md-2 meta-details">
            
              <div class="user-details row">
                <p class="date col-lg-12 col-md-12 col-6"><a href="javascript:void(0)"><?php echo date('d/m/y',strtotime($newsdetail['created_date'])); ?></a> <span class="lnr lnr-calendar-full"></span></p>
              <!--  <p class="comments col-lg-12 col-md-12 col-6"><a href="#">06 Comments</a> <span class="lnr lnr-bubble"></span></p> -->
            
              </div>
            </div>
            <div class="col-lg-10 col-md-10">
              <h3 class="mt-20 mb-20 "><?php echo $newsdetail['title']; ?></h3>
              <p class="excert">
                <?php echo $newsdetail['description']; ?>
              </p>
            </div>
            
          </div>
          
        
        </div> 
       
      </div>
    </div>
  </section>

