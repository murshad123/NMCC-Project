
<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="<?php echo ASSETS_URL ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">News</h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">News </span>
      </div>
    </div>
  </header>
<section class="post-content-area comman-main">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 posts-list">
          <div class="single-post row">

          <?php
          if(!empty($news)){
            foreach ($news as $key => $value) { ?>
              
           
            <div class="col-md-6 col-sm-12">
              <div class="row">
            <div class="col-lg-3 col-md-3 meta-details">
          
              <div class="user-details row">
                <p class="date col-lg-12 col-md-12 col-6"><a href="#"><?php echo date('d/m/Y',strtotime($value['created_date'])); ?></a> <span class="lnr lnr-calendar-full"></span></p>
               <!-- <p class="comments col-lg-12 col-md-12 col-6"><a href="#">06 Comments</a> <span class="lnr lnr-bubble"></span></p> -->
              </div>
            </div>
            <div class="col-lg-9 col-md-9 ">
              <div class="feature-img">
                 <?php
                  if(!empty($value['image'])){
                    $imgsrc = ASSETS_URL.'dist/news_img/'.$value['image'];
                  }else{
                    $imgsrc = ASSETS_URL.'img/no-image.jpg';
                 } ?>
                <img class="img-fluid" src="<?php echo $imgsrc; ?>" alt="">
              </div>
              <a class="posts-title" href="<?php echo BASE_URL; ?>general/newsdetails/<?php echo $value['id']; ?>"><h3><?php echo $value['title']; ?></h3></a>
              <p class="excert">
                <?php echo $value['short_desc'];?>
              </p>
              <a href="<?php echo BASE_URL; ?>general/newsdetails/<?php echo $value['id']; ?>" class="primary-btn">View More</a>
            </div>
          </div>
          </div> 
          <?php } } ?>          

          </div>
        </div>
        
      </div>
    </div>
  </section>
