

<header class="hero-banner project-bg">
    <a class="navbar-brand" href="index.php">
      <img src="img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">Events</h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <a href="<?php echo BASE_URL; ?>"><span class="btn btn--rightBorder">Events</span>
      </div>
    </div>
  </header>

 <div class="comman-main">
     <div class="container">
         <div class="row">
             <div class="col-md-5 col-sm-12">
                 <div class="event-imgs">
                 <?php
                  if(!empty($eventdetails['presenter_image'])){
                    $imgsrc = ASSETS_URL.'dist/pre_img/'.$eventdetails['presenter_image'];
                  }else{
                    $imgsrc = ASSETS_URL.'img/no-image.jpg';
                 } ?>
                     <img src="<?php echo $imgsrc; ?>" width="100%">
                     <div class="content-event">
                         <span><?php echo $eventdetails['presenter'].'('.$eventdetails['presenter_designation']; ?></span>
                         <p><?php echo $eventdetails['start_date'].'-To-'.$eventdetails['end_date']; ?></p>
                     </div>
                 </div>
             </div>
             <div class="col-md-7 col-sm-12">
                 <div class="discripation">
                     <h3 class="head"><?php echo $eventdetails['event_name']; ?></h3>
                     <p><?php echo $eventdetails['description']; ?></p>
                 </div>
             </div>
         </div>
     </div>
 </div>

