<header class="hero-banner project-bg">
    <a class="navbar-brand" href="<?php echo BASE_URL; ?>">
      <img src="<?php echo ASSETS_URL ?>img/logo.png" alt="">
    </a>
    <div class="container">
      <h2 class="section-intro__subtitle subtitle-inner">Personnel </h2>
      <div class=" breadcrumb">
        <a href="<?php echo BASE_URL; ?>" class="btn">Home</a>
        <span class="btn btn--rightBorder">Personnel</span>
      </div>
    </div>
  </header>


<section class="personal-main about ">
  <div class="container">
    <div class="row">
       <?php
          if(!empty($personnel)){ 
           foreach ($personnel as $personnelkey => $personnelvalue) { ?>
      <div class="col-md-4 col-sm-12">
        <div class="personal-box">
          <div class="profile">
          <?php
            if(!empty($personnelvalue['image'])){
                $imgsrc = ASSETS_URL.'dist/presonal_img/'.$personnelvalue['image'];
            }else{
              $imgsrc = ASSETS_URL.'img/no-image.jpg';
          } ?>
            <img src="<?php echo $imgsrc; ?>">
          </div>
          <div class="content-details">
            <h5><?php echo $personnelvalue['name']; ?></h5>
           <p><b>Email :</b> <a href="#"><?php echo $personnelvalue['email']; ?></a></p>
             <p><b>Designation :</b> <?php echo $personnelvalue['designation']; ?></p>
             <p><b>Contact :</b> <a href="#"><?php echo $personnelvalue['phonenumber']; ?></a>
             <p><b>Joied Date :</b> <?php echo date('d/m/Y',strtotime($personnelvalue['created_date'])); ?></p>
             <a class="btn btn--rightBorder mt-4" href="javascript:void(0)" onclick="alert('Details not found')">Details</a>
          </div>
        </div>
      </div>
       <?php } } ?>
    </div>
  </div>
</section>
