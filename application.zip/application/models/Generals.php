<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Generals extends CI_Model {

    	public function __construct(){
	       	parent::__construct();
    }

    public function addRow($tab, $array, $disp = false) {
	        $this->db->insert($tab, $array);

	        $insert_id = $this->db->insert_id();
	        if($disp){
	            return $this->db->last_query();
	        }
	        return $insert_id;
    }

	public function updateRow($tab, $array, $where_field, $where_value,$disp = false) {
	    $this->db->where($where_field, $where_value);
	    $result = $this->db->update($tab, $array);
	    //echo $this->db->last_query(); die;
	  
	    if($disp){
	        return $this->db->last_query();
	    }
	    return $result;
	}
    
	public function getpersonnel()
	{
		
        $query = $this->db->get('personnel');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function geteventbyyear($event_type,$event_year)
	{
		$query = $this->db->get_where('events',array('event_type =' => $event_type, 'event_year =' => $event_year));
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getcurrenetseminar()
	{
        $this->db->select('event_year');
        $this->db->group_by('event_year');
        $query = $this->db->get_where('events',array('event_type =' => 1, 'event_year >=' => date('Y')));
		if($query->num_rows()){
			$seminarres =  $query->result_array();
			$reultarray = array();
			if(!empty($seminarres)){
				foreach ($seminarres as $key => $value) {
					$reultarray[$key][$value['event_year']] = $this->geteventbyyear('1',$value['event_year']);
				}
			}
			return $reultarray;
		}else {
			return false;
		}
	}

	public function getpreviousseminar()
	{
		
		$this->db->select('event_year');
        $this->db->group_by('event_year');
        $query = $this->db->get_where('events',array('event_type =' => 1, 'event_year <' => date('Y')));
		if($query->num_rows()){
			$seminarres =  $query->result_array();
			$reultarray = array();
			if(!empty($seminarres)){
				foreach ($seminarres as $key => $value) {
					$reultarray[$key][$value['event_year']] = $this->geteventbyyear('1',$value['event_year']);
				}
			}
			return $reultarray;
		}else {
			return false;
		}
	}

	public function getpreviousworkshop()
	{
		
        $this->db->select('event_year');
        $this->db->group_by('event_year');
        $query = $this->db->get_where('events',array('event_type =' => 2, 'event_year <' => date('Y')));
		if($query->num_rows()){
			$seminarres =  $query->result_array();
			$reultarray = array();
			if(!empty($seminarres)){
				foreach ($seminarres as $key => $value) {
					$reultarray[$key][$value['event_year']] = $this->geteventbyyear('2',$value['event_year']);
				}
			}
			return $reultarray;
		}else {
			return false;
		}
	}

	public function getcurrentworkshop()
	{
		
        $this->db->select('event_year');
        $this->db->group_by('event_year');
        $query = $this->db->get_where('events',array('event_type =' => 2, 'event_year >=' => date('Y')));
		if($query->num_rows()){
			$seminarres =  $query->result_array();
			$reultarray = array();
			if(!empty($seminarres)){
				foreach ($seminarres as $key => $value) {
					$reultarray[$key][$value['event_year']] = $this->geteventbyyear('2',$value['event_year']);
				}
			}
			return $reultarray;
		}else {
			return false;
		}
	}

	public function geteventdetails($event_id)
	{
		$query = $this->db->get_where('events',array('id =' => $event_id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}
	}

	public function getactivenews()
	{
		$this->db->order_by('news.id');
		$query = $this->db->get_where('news',array('status =' => 1));
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getnewsdetail($newsid)
	{
		$query = $this->db->get_where('news',array('id =' => $newsid));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}
	}

	


	

	
	
}