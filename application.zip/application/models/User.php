<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class User extends CI_Model {

    	public function __construct(){
	       	parent::__construct();
    }

    public function addRow($tab, $array, $disp = false) {
	        $this->db->insert($tab, $array);

	        $insert_id = $this->db->insert_id();
	        if($disp){
	            return $this->db->last_query();
	        }
	        return $insert_id;
    }

	public function updateRow($tab, $array, $where_field, $where_value,$disp = false) {
	    $this->db->where($where_field, $where_value);
	    $result = $this->db->update($tab, $array);
	    //echo $this->db->last_query(); die;
	  
	    if($disp){
	        return $this->db->last_query();
	    }
	    return $result;
	}
    //user login
    public function user_login($username, $password){
		
		$user=$this->db->get_where('user_register',array('email'=>$username,'password'=>$password,'status'=>1));
		
		if($user->num_rows()){
			return $user->row_array();
		}else {
			return false;
		}
		
	}
	public function insert_regdata($arrData){	
		$result = $this->db->insert('user_register',$arrData);
		if($result == 1){
			return true;
		}else{
			return false;
		}
	}

	public function getnigireaauthors()
	{
		$this->db->select('authors.name,authors.email,authors.phonenumber,authors.affilication,authors.institution_name,authors.organisms_name,authors.community,authors.accession_number,country.name as country_name');
        $this->db->join('country','country.country_id = authors.country_id');
		$authors=$this->db->get_where('authors',array('authors.country_id'=>156));
		if($authors->num_rows()){
			return $authors->result_array();
		}else {
			return false;
		}
	}

	public function getotherregionauthors()
	{
		$this->db->select('authors.name,authors.email,authors.phonenumber,authors.affilication,authors.institution_name,authors.organisms_name,authors.community,authors.accession_number,country.name as country_name');
        $this->db->join('country','country.country_id = authors.country_id');
        $this->db->where('authors.country_id != ',156,FALSE);
		$authors=$this->db->get('authors');
		if($authors->num_rows()){
			return $authors->result_array();
		}else {
			return false;
		}
	}

	public function getcollectionauthors($collection)
	{
		$this->db->select('authors.name,authors.strain,authors.email,authors.phonenumber,authors.affilication,authors.institution_name,authors.organisms_name,authors.organisms_group,authors.community,authors.accession_number,country.name as country_name');
        $this->db->join('country','country.country_id = authors.country_id');
		$authors=$this->db->get_where('authors',array('organisms_group'=>$collection));
		if($authors->num_rows()){
			return $authors->result_array();
		}else {
			return false;
		}
	}

	public function getcollectionwithstrainauthors($collection,$strain)
	{
		$this->db->select('authors.name,authors.strain,authors.email,authors.phonenumber,authors.affilication,authors.institution_name,authors.organisms_name,authors.organisms_group,authors.community,authors.accession_number,country.name as country_name');
        $this->db->join('country','country.country_id = authors.country_id');
		$authors=$this->db->get_where('authors',array('organisms_group'=>$collection,'strain'=>$strain));
		//echo $this->db->last_query(); die;
		if($authors->num_rows()){
			return $authors->result_array();
		}else {
			return false;
		}
	}



	public function getactivecountries()
	{
		$this->db->select('country_id,name');
        $query = $this->db->get('country');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getcountrystate($country_id)
	{
		$this->db->select('*');
        $query = $this->db->get_where('zone',array('country_id'=>$country_id));
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}


	public function getnigeriastateslga($state_id)
	{
		$this->db->select('*');
        $query = $this->db->get_where('lga',array('state_id'=>$state_id));
		if($query->num_rows()){
			return $query->result_array();
			//return $res['name'];
		}else {
			return false;
		}
	}

	public function getnigeriacommunity($state_id)
	{
		$this->db->select('*');
        $query = $this->db->get_where('community',array('state_id'=>$state_id));
        // echo $this->db->last_query(); die;
		if($query->num_rows()){
			return $query->result_array();
			//return $res['name'];
		}else {
			return false;
		}
	}

	public function getacronyms()
	{
        $query = $this->db->get('acronyms');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getinquiry()
	{
        $query = $this->db->get('inquiry');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

public function addMultipleData($tab,$datamulti,$disp = false) {

		    $this->db->insert($tab,$datamulti);
	// public function addMultipleData($tab,$totalFormData,$totalFormData1,$totalFormData2,$totalFormData3,$totalFormData4,$disp = false) {

	// 	    $this->db->insert($tab,$totalFormData,$totalFormData1,$totalFormData2,$totalFormData3,$totalFormData4);
	        // $this->db->insert($tab,$totalFormData);
	        // $this->db->insert($tab,$totalFormData1);
	        // $this->db->insert($tab,$totalFormData2);
	        // $this->db->insert($tab,$totalFormData3);
	        // $this->db->insert($tab,$totalFormData4);


	        $insert_id = $this->db->insert_id();
	        if($disp){
	            return $this->db->last_query();
	        }
	        return $insert_id;
    }


    public function getCulture_held()
	{
        $query = $this->db->get('cultures_held');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}


	public function getculture_collection()
	{
		
      $query = $this->db->get('culture_collections');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getNumberCulture()
	{
		$this->db->order_by('continents.name','asc');
		$this->db->select('country.continent_code,continents.name, number_culture_collection.country_name, number_culture_collection.culture_collections, number_culture_collection.cultures');
		$this->db->from('number_culture_collection');
		$this->db->join('country',' number_culture_collection.country_name=country.name');
		$this->db->join('continents','continents.code=country.continent_code');
		$query = $this->db->get();
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getServiceProvided()
	{
		$this->db->order_by('continents.name','asc');
		$this->db->select('continents.name,countries,patent,store,distribution,	identification,training,consult');
		$this->db->from('service_provided');
		$this->db->join('country','country.name=service_provided.countries');
		$this->db->join('continents','continents.code=country.continent_code');
		$query = $this->db->get();
        
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getServiceTypes()
	{
        $query = $this->db->get('culture_services');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	
}