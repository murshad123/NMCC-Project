<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Store_modal extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->table = 'stores';	
	}

	public function getstores()
	{
		$this->db->order_by('id','desc');
        $this->db->select('*');
        $query = $this->db->get('stores');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getstorelockers($store_id)
	{
		//$this->db->order_by('id','desc');
        $this->db->select('*');
        $query = $this->db->get_where('stores_lockers',array('store_id'=>$store_id,'status' => 1));
       //echo  $this->db->last_query(); die;
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function deleteStoreLockers($locker_id)
	{
		$this->db->where('stores_lockers.id', $locker_id);
        $this->db->delete('stores_lockers');
        return true;
	}

	


	
}