<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authors_modal extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->table = 'authors';	
	}
       
        public function insertdata($table,$dataArray)
			{
				$resultData = $this->db->insert($table,$dataArray);
		        
				if($resultData){
					return true;
				}else {
					return false;
				}
			}

			public function updateRow($tab, $array, $where_field, $where_value,$disp = false) {
			    $this->db->where($where_field, $where_value);
			    $result = $this->db->update($tab, $array);
			  
			    if($disp){
			        return $this->db->last_query();
			    }
			    return $result;
			    }


	
	public function getauthors()
	{
		$this->db->order_by('id','ASC');
        $this->db->select('*');
        $query = $this->db->get('authors');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getauthordetails($author_id)
	{
		$data = array();
		$this->db->select('*');
		$query = $this->db->get_where('authors',array('id'=>$author_id));
		if($query->num_rows()){
			$customerdetails =  $query->row_array();
			
		}else {
			$customerdetails = array();
		}

		

		return $customerdetails;

	}

	public function getResidentailsAddress($customer_id)
	{
        $this->db->limit(1);
        $this->db->order_by('id','desc');
        $this->db->select('address,address2,city,state,postal_code');
		$query = $this->db->get_where('address',array('customer_id'=>$customer_id,'address.address_type' => 1));
        $resaddress =  $query->row_array();
        if(!empty($resaddress)){
           return $resaddress;
        }else{
          $ress1 = array('address'=>'','address2' => '', 'city' => '' ,'state' => '' ,'postal_code' => '');
          return $ress1;
        }
	}

	public function getBillingAddress($customer_id)
	{
        $this->db->limit(1);
        $this->db->order_by('id','desc');
        $this->db->select('address,address2,city,state,postal_code');
		$query = $this->db->get_where('address',array('customer_id'=>$customer_id,'address.address_type' => 2));
        $billingaddress =  $query->row_array();

        if(!empty($billingaddress)){
           return $billingaddress;
        }else{
          $billing = array('address'=>'','address2' => '', 'city' => '' ,'state' => '' ,'postal_code' => '');
          return $billing;
        }
	}

	public function deleteCustomers($customer_id)
	{
		$this->db->where('customers.id', $customer_id);
        $this->db->delete('customers');
        return true;
	}


	public function deleteAuthors($author_id)
	{
		$this->db->where('id', $author_id);
        $this->db->delete('authors');
        return true;
	}

	


	
}