<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nmccdatabase extends CI_Controller {
	
    function __construct()
    {

        parent::__construct();
        $this->load->library('session');
		$this->load->library('form_validation');
        $this->load->model('user');

		
    }
	
	public function index()
	{
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method());	
	}

	public function infin(){
		//echo $this->router->fetch_class().'/'.$this->router->fetch_method(); die; 
		$this->load->dbfront($this->router->fetch_class().'/'.$this->router->fetch_method());	
	}
	public function login(){
    
        $this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		if (!$this->form_validation->run() == FALSE){
            $username = $this->input->post('username');
			$password = $this->input->post('password');
			$newpassword = $password;
			
			$user_info = $this->user->user_login($username,$newpassword);
		
			if($user_info){
                $session = $user_info;
				$this->session->set_userdata('customer_logged_in', $session);
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Login Successfully</div>');			
				$redirecturl = BASE_URL.'/nmccdatabase/infin';
				redirect($redirecturl,'refresh');
		    }else{
				$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Email or Password Invalid</div>');			
				$redirecturl = BASE_URL.'/nmccdatabase';
				redirect($redirecturl,'refresh');
		    }
		}else{      
	    $this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method());	
	    $redirecturl = BASE_URL.'/nmccdatabase';
	    redirect($redirecturl,'refresh');
		
        }	

	}
	
    public function register()
	{
      
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block" style="color:red;">', '</p>');
		$this->form_validation->set_rules('firstname', 'Firstname', 'required');
		$this->form_validation->set_rules('lastname', 'Lastname', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[user_register.email]');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
		//$this->form_validation->set_rules('check', '...', 'callback_accept_terms');
	           

		if (!$this->form_validation->run() == FALSE) {
            $arrData = array(
				        'first_name' => $this->input->post('firstname'),
				        'last_name' => $this->input->post('lastname'),
				        'email' => $this->input->post('email'),
				        'password' => $this->input->post('password'),
				        'status' =>  1,
				        'created_date' => date('Y-m-d H:i:s')
				    );
				
				if($useriid = $this->user->insert_regdata($arrData)){
					$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">You have successfully registered.</div>');
					$addressurl = BASE_URL.'/nmccdatabase/infin';
					redirect($addressurl,'refresh');
				}else{
					$this->session->set_flashdata('response', '<div class="alert alert-info alert-dismissable">Failed to registered .</div>');
					$addressurl = BASE_URL.'/nmccdatabase/register';
					redirect($addressurl,'refresh');
				}
		  
		}else{
			
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method());	

		}
	}

	
	//user registration
	public function forgot()
	{
		$this->load->front($this->router->fetch_class().'/'.$this->router->fetch_method());	
	}

}
