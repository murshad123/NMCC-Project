<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class General_modal extends CI_Model {

	public function __construct(){
		parent::__construct();
	}

	public function addRow($tab, $array, $disp = false) {
	        $this->db->insert($tab, $array);

	        $insert_id = $this->db->insert_id();
	        if($disp){
	            return $this->db->last_query();
	        }
	        return $insert_id;
    }

    public function updateRow($tab, $array, $where_field, $where_value,$disp = false) {
	    $this->db->where($where_field, $where_value);
	    $result = $this->db->update($tab, $array);
	  
	    if($disp){
	        return $this->db->last_query();
	    }
	    return $result;
	}

    public function deleteRow($tab, $delete_id, $id , $disp = false) {
	    $this->db->where($delete_id, $id);
        $this->db->delete($tab);
	        return true;
    }

	public function getinquiries()
	{
		$this->db->order_by('id','desc');
        $this->db->select('*');
        $query = $this->db->get('inquiry');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}


	public function getinquiriesDetails($inquiry_id)
	{
       
		$this->db->select('*');
        $query = $this->db->get_where('inquiry',array('id'=>$inquiry_id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}
	}

	public function getcontinents()
	{
        $this->db->select('*');
        $query = $this->db->get('continents');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	

	public function getcountries($continent_code)
	{
		$this->db->select('*');
        $query = $this->db->get_where('country',array('continent_code'=>$continent_code));
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getactivecountries()
	{
		$this->db->select('country_id,name');
        $query = $this->db->get('country');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getcountrystate($country_id)
	{
		$this->db->select('*');
        $query = $this->db->get_where('zone',array('country_id'=>$country_id));
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	/*public function getCurrentEvents()
	{
		$this->db->order_by('id','desc');
        $this->db->select('*');
        $this->db->where('events.start_date >=', date('Y'));
        $query = $this->db->get('events');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}*/

	public function getCurrentEvents()
	{
		$this->db->select('event_year');
        $this->db->order_by('event_year','asc');
        $this->db->group_by('event_year');
        $query = $this->db->get_where('events',array('event_year >=' => date('Y')));
		if($query->num_rows()){
			$seminarres =  $query->result_array();
			$reultarray = array();
			if(!empty($seminarres)){
				foreach ($seminarres as $key => $value) {
                  $query = $this->db->get_where('events',array('event_year =' => $value['event_year']));
				  if($query->num_rows()){
						$eventsdata =  $query->result_array();
				  }else {
						$eventsdata =  array();
				  }
				 $reultarray[$value['event_year']] = $eventsdata;
				}
			}
			return $reultarray;
		}else {
			return false;
		}
	}

	/*public function getPastEvents()
	{
		$this->db->order_by('start_date','desc');
        $this->db->select('*');
        $this->db->where('events.event_year <', date('Y'));
        $query = $this->db->get('events');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}*/

	public function getPastEvents()
	{

		$this->db->select('event_year');
        $this->db->order_by('event_year','desc');
        $this->db->group_by('event_year');
        $query = $this->db->get_where('events',array('event_year <' => date('Y')));
		if($query->num_rows()){
			$seminarres =  $query->result_array();
			$reultarray = array();
			if(!empty($seminarres)){
				foreach ($seminarres as $key => $value) {
                  $query = $this->db->get_where('events',array('event_year =' => $value['event_year']));
				  if($query->num_rows()){
						$eventsdata =  $query->result_array();
				  }else {
						$eventsdata =  array();
				  }
				 $reultarray[$value['event_year']] = $eventsdata;
				}
			}
			return $reultarray;
		}else {
			return false;
		}
	}

	public function geteventdetails($eventid)
	{
		$this->db->select('*');
        $query = $this->db->get_where('events',array('id'=>$eventid));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}
	}

	public function getcmspages()
	{
		$this->db->order_by('page_id','desc');
        $this->db->select('*');
        $query = $this->db->get('cms_pages');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}



	

	public function getStateDeatils($state_id)
	{      
		$this->db->select('*');
        $query = $this->db->get_where('zone',array('zone_id'=>$state_id));
        // echo $this->db->last_query(); die;
        /*echo "<pre>";
        print_r($query); die;*/
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}
	}

	public function getTotalMembers()
	{
		$this->db->select('*');
        $query = $this->db->get('user_register');
		if($query->num_rows()){
			return $query->num_rows();
		}else {
			return 0;
		}
	}

	public function getTotalAutores()
	{
		$this->db->select('*');
        $query = $this->db->get('authors');
		if($query->num_rows()){
			return $query->num_rows();
		}else {
			return 0;
		}
	}


	public function getTotalNews()
	{
		$this->db->order_by('id','desc');
		$this->db->select('*');
        $query = $this->db->get_where('news',array('status ='=> 1));
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return 0;
		}
	}

	public function getNewsDetails($news_id){
		$this->db->select('*');
		$query = $this->db->get_where('news',array('id' => $news_id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}

	public function getcommunities()
	{
		$this->db->select('community.*,zone.name as state_name,country.name as country_name');
		$this->db->join('zone', 'zone.zone_id = community.state_id'); 
		$this->db->join('country', 'country.country_id = community.country_id'); 
		$query = $this->db->get('community');
        if($query->num_rows()){
			return $query->result_array();
		}else {
			return 0;
		}
	}

	public function getcommunitybystates($state_id)
	{
		$this->db->select('community.*,zone.name as state_name,country.name as country_name');
		$this->db->join('zone', 'zone.zone_id = community.state_id'); 
		$this->db->join('country', 'country.country_id = community.country_id'); 
		$query = $this->db->get_where('community',array('state_id'=>$state_id));
        if($query->num_rows()){
			return $query->result_array();
		}else {
			return 0;
		}
	}

	public function getregiondetailsbystateid($state_id)
	{
        $this->db->select('zone.zone_id , zone.name as zone_name , zone.country_id ,country.name as country_name ,continents.name as continents_name,continents.code as continents_code');
		$this->db->join('country', 'zone.country_id = country.country_id'); 
		$this->db->join('continents', 'continents.code = country.continent_code'); 
		$query = $this->db->get_where('zone',array('zone.zone_id' => $state_id));
        if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}

	public function getCommunityDetails($community_id)
	{
		$this->db->select('*');
		$query = $this->db->get_where('community',array('id' => $community_id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}

	public function getcontinentsdetails($id)
	{
		$this->db->select('*');
		$query = $this->db->get_where('continents',array('id' => $id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}
	

	public function getCountryDetails($country_id)
	{
		$this->db->select('*');
		$query = $this->db->get_where('country',array('country_id' => $country_id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}

	public function getcontinentsdetailsbyCode($code)
	{
		$this->db->select('*');
		$query = $this->db->get_where('continents',array('code' => $code));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}

	

	public function getcontrydetails($country_id)
	{
		$this->db->select('country_id,name');
		$query = $this->db->get_where('country',array('country_id' => $country_id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}

	public function getacronyms()
	{
		$this->db->order_by('acronym','asc');
		$this->db->select('*');
        $query = $this->db->get_where('acronyms');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return 0;
		}
	}

	public function GetAcronymsDetails($id)
	{

		$query = $this->db->get_where('acronyms',array('id' => $id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}

	public function editStateDetails($state_id)
	{
		$query = $this->db->get_where('zone',array('zone_id' => $state_id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}


	public function getLga($lga_id)
	{

		$query = $this->db->get_where('lga',array('state_id'=>$lga_id));
		//echo $this->db->last_query(); die; 
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return 0;
		}
	}


	public function editlgaDetails($state_id)
	{
		$query = $this->db->get_where('lga',array('id' => $state_id));
		// print_r($query);  die;
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}
 

 public function editCommunityDetails($state_id)
	{
		$query = $this->db->get_where('community',array('id' => $state_id));
		// echo $this->db->last_query(); die; 
		/*echo "<pre>";
		print_r($query);  die;*/
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return 0;
		}
	}

	




	
}