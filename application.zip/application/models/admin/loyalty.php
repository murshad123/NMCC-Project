 <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>Customer  </h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo BASE_URL.'admin/dashboard' ?>">Dashboard</a>
                        </li> 
                        <li>
                            <a href="<?php echo BASE_URL.'admin/customer/customer' ?>">Customer</a>
                        </li>
                        <li class="active">
                            <strong>Orders</strong>
                        </li>
                    </ol>
                </div>
                 <div class="col-sm-8">
                    <div class="title-action">
                        <a href="<?php echo BASE_URL.'admin/customer/customer' ?>" class="btn btn-primary">Back</a>
                    </div>
                 </div> 
                       
            </div>

            <div class="wrapper wrapper-content">
                <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-content">
                            <?php echo $this->session->flashdata('response'); ?>
                            <table class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Status</th>
                                <th>Total</th>
                                <th>Date Added</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php 
                           $i=1; 
                            if(!empty($orders)){
                            foreach ($orders as $cat) { ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><b><?php echo 'OD'.$cat['order_id'].strtotime($cat['date_added']); ?></b></td>
                                    <td><?php echo $cat['firstname']." ".$cat['lastname']; ?></td>
                                    <td><?php echo $cat['status'] ?></td>
                                    <td><?php echo $cat['total']?></td>
                                    <td><?php echo date('d M Y',strtotime($cat['date_added'])); ?></td>
                                    <td>
                                        <a class="btn btn-info" title="View" href="<?php echo BASE_URL ?>admin/sale/order/view/<?php echo $cat['order_id']; ?>"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                        <a class="btn btn-warning" title="Devliery Note" href="<?php echo BASE_URL ?>admin/sale/order/generate_delivery_notes/<?php echo $cat['order_id']; ?>"><i class="fa fa-sticky-note-o" aria-hidden="true"></i></a>
                                        <a class="btn btn-success" title="Sales Receipt" href="<?php echo BASE_URL ?>admin/sale/order/reciept/<?php echo $cat['order_id']; ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                                        <a class="btn btn-primary" title="Invoice"  href="<?php echo BASE_URL ?>admin/sale/order/invoice/<?php echo $cat['order_id']; ?>"><i class="fa fa-print"></i></a>
                                    </td>
                                </tr>
                            
                            <?php $i++;} }else{ ?> 
                             <tfoot>
                <tr><th rowspan="1" colspan="5">No Record Found.</th></tr>
              </tfoot>   
              <?php } ?>                                
                            </tbody>
                            </table>
                              <div class="box-footer clearfix"> <?php  echo $links ?> </div>   
                            
                        </div>
                    </div>
                </div>
            </div>
            </div>