
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forgot_Model extends CI_Model {

	public function __construct(){
		parent::__construct();
		
	}




public function ForgotPassword($email)
 {
        $this->db->select('email');
        $this->db->from('user_register'); 
        $this->db->where('email',$email); 
        $query=$this->db->get();
        return $query->row_array();
 }


 public function sendpassword($data)
{
     $email = $data['email'];
     $que=$this->db->query("select password,email from user_register where email='$email'");
     $row=$que->row();
     $user_email=$row->email;
     if((!strcmp($email, $user_email))){
            $pass=$row->password;
                /*Mail Code*/
                $to = $user_email;
                $subject = "Password";
                $txt = "Your password is $pass .";
                $headers = "From: gobioh@yahoo.com" . "\r\n" .
                "CC: g.i.obioh@nabda.gov.ng";

                mail($to,$subject,$txt,$headers);
                }
            else{
            $data['error']="Invalid Email ID !";}
                

  }
    





/*
 public function sendpassword($data)
{
        $email = $data['email'];
     
        $query1=$this->db->query("SELECT *  from user_register where email = '".$email."' ");
        $row=$query1->result_array();
        
   if ($query1->num_rows()>0)
      
{
        $passwordplain = "";
        $passwordplain  = rand(10,100);
        $newpass['password'] = md5($passwordplain);
        $this->db->where('email', $email);
        $this->db->update('user_register', $newpass); 
        $mail_message='Dear '.$row[0]['first_name'].','. "\r\n";
        $mail_message.='Thanks for contacting regarding to forgot password,<br> Your <b>Password</b> is <b>'.$passwordplain.'</b>'."\r\n";
        $mail_message.='<br>Please Update your password.';
        $mail_message.='<br>Thanks & Regards';
        $mail_message.='<br>Your company name';   
        echo "<pre>";
        print_r($mail_message);     
        date_default_timezone_set('Etc/UTC');
       
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->SMTPSecure = "tls"; 
        $mail->Debugoutput = 'html';
        $mail->Host = "yooursmtp";
        $mail->Port = 587;
        $mail->SMTPAuth = true;   
        $mail->Username = "your@email.com";    
        $mail->Password = "password";
        $mail->setFrom('admin@site', 'admin');
        $mail->IsHTML(true);
        $mail->addAddress($email);
        $mail->Subject = 'OTP from company';
        $mail->Body    = $mail_message;
        $mail->AltBody = $mail_message;
          echo "<pre>";
        print_r($mail); die;
if (!$mail->send()) {
	$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Failed to send password, please try again!</div>');

} else {
	$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Password sent to your email!</div>');
}
        $redirecturl = ADMIN_URL.'/Login';
        redirect($redirecturl,'refresh');       
}
else
{  
	$this->session->set_flashdata('response', '<div class="alert alert-danger alert-dismissable">Email not found try again!</div>');
        $redirecturl = ADMIN_URL.'/Login';
        redirect($redirecturl,'refresh');
}
}
	*/



  










} ?>




