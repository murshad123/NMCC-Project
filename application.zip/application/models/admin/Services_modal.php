<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Services_modal extends CI_Model {
   
	public function __construct(){
		parent::__construct();
		$this->table = 'services';	
	}

	public function addRow($tab, $array, $disp = false) {
        $this->db->insert($tab, $array);
        $insert_id = $this->db->insert_id();
        if($disp){
            return $this->db->last_query();
        }
        return $insert_id;
    }

	public function updateRow($tab, $array, $where_field, $where_value,$disp = false) {
	    $this->db->where($where_field, $where_value);
	    $result = $this->db->update($tab, $array);
	  
	    if($disp){
	        return $this->db->last_query();
	    }
	    return $result;
	}

	public function add($data){
		$data['date_added'] = date('Y-m-d H:i:s');	
		$this->db->insert($this->table,$data);
		return $this->db->insert_id();
    }

	public function getServices(){
        $this->db->order_by('id','desc');
        $this->db->select('*');
        $query = $this->db->get('services');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
        
	}

	public function getServicesbyid($service_id)
	{
		$query = $this->db->get_where('services',array('id'=>$service_id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}
	}
	
	public function getServicesPricing()
	{
		
		$this->db->select('services.name,pricing.comments,pricing.description,pricing.status,pricing.added_date,pricing.id');
		$this->db->join('services', 'pricing.service_id = services.id');
		$query = $this->db->get_where('pricing',array('pricing.status'=>1));
		if($query->num_rows()){
            return $query->result_array();
		}else {
			return false;
		}
	}



	public function getServicesPricinglist($pricing_id)
	{
		$query = $this->db->get_where('pricing_meta',array('pricing_meta.pricing_id'=>$pricing_id));
		if($query->num_rows()){
            return $query->result_array();
		}else {
			return false;
		}
	}

	public function deleteServices($service_id)
	{
		$this->db->where('services.id', $service_id);
        $this->db->delete('services');
        return true;
	}


	
}