<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_modal extends CI_Model {

    public function insertdata($table,$dataArray)
	{
		$resultData = $this->db->insert($table,$dataArray);
        
		if($resultData){
			return true;
		}else {
			return false;
		}
	}

	public function updateRow($tab, $array, $where_field, $where_value,$disp = false) {
	    $this->db->where($where_field, $where_value);
	    $result = $this->db->update($tab, $array);
	  
	    if($disp){
	        return $this->db->last_query();
	    }
	    return $result;
	}
	
	
	
	public function getstates()
	{
        $query = $this->db->get('states');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}
	
	public function getcountry()
	{
        $query = $this->db->get('country');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getmembers()
	{
		$this->db->order_by('id','ASC');
        $this->db->select('*');
        $query = $this->db->get('user_register');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getpersonal()
	{
		$this->db->order_by('id','ASC');
        $this->db->select('*');
        $query = $this->db->get('personnel');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	/*public function getnews()
	{
		$this->db->order_by('id','desc');
        $this->db->select('*');
       $this->db->where('news.created_date >=', date('Y'));
        $query = $this->db->get('news');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}
*/

	public function getCurrentNews()
	{
		$this->db->select('news_year');
        $this->db->order_by('news_year','asc');
        $this->db->group_by('news_year');
        $query = $this->db->get_where('news',array('news_year >=' => date('Y')));
		if($query->num_rows()){
			$seminarres =  $query->result_array();
			$reultarray = array();
			if(!empty($seminarres)){
				foreach ($seminarres as $key => $value) {
                  $query = $this->db->get_where('news',array('news_year =' => $value['news_year']));
				  if($query->num_rows()){
						$eventsdata =  $query->result_array();
				  }else {
						$eventsdata =  array();
				  }
				 $reultarray[$value['news_year']] = $eventsdata;
				}
			}
			return $reultarray;
		}else {
			return false;
		}
	}
	/*public function pastgetnews()
	{
		$this->db->order_by('id','desc');
        $this->db->select('*');
       $this->db->where('news.created_date <', date("Y/m/d"));
        $query = $this->db->get('news');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}*/

   public function pastgetnews()
	{

		$this->db->select('news_year');
        $this->db->order_by('news_year','desc');
        $this->db->group_by('news_year');
        $query = $this->db->get_where('news',array('news_year <' => date('Y')));
		if($query->num_rows()){
			$seminarres =  $query->result_array();
			$reultarray = array();
			if(!empty($seminarres)){
				foreach ($seminarres as $key => $value) {
                  $query = $this->db->get_where('news',array('news_year =' => $value['news_year']));
				  if($query->num_rows()){
						$eventsdata =  $query->result_array();
				  }else {
						$eventsdata =  array();
				  }
				 $reultarray[$value['news_year']] = $eventsdata;
				}
			}
			return $reultarray;
		}else {
			return false;
		}
	}
	
	
	public function getcustomers()
	{
		$this->db->order_by('id','desc');
        $this->db->select('*');
        $query = $this->db->get('authors');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getcustomersdetails($customer_id)
	{
		$data = array();
		$this->db->select('*');
		$query = $this->db->get_where('customers',array('id'=>$customer_id));
		if($query->num_rows()){
			$customerdetails =  $query->row_array();
			if(!empty($customerdetails)){
               $residentailAddress = $this->getResidentailsAddress($customer_id);
               $billingAddress = $this->getBillingAddress($customer_id);
			}
		}else {
			$customerdetails = array();
		}

		$data = $customerdetails;
		$data['billing_address'] = $billingAddress;
		$data['residentail_address'] = $residentailAddress;

		return $data;

	}

	public function getmeberetails($member_id){
		$this->db->select('*');
		$query = $this->db->get_where('user_register',array('id' => $member_id));
		if($query->num_rows()){
			$res = $query->row_array();
		}else{
			$res = array();
		}
		return $res;

	}

	public function getpersonalDetails($member_id){
		$this->db->select('*');
		$query = $this->db->get_where('personnel',array('id' => $member_id));
		if($query->num_rows()){
			$res = $query->row_array();
		}else{
			$res = array();
		}
		return $res;

	}

	public function getNewsDetails($member_id){
		$this->db->select('*');
		$query = $this->db->get_where('news',array('id' => $member_id));
		if($query->num_rows()){
			$res = $query->row_array();
		}else{
			$res = array();
		}
		return $res;

	}

	public function getResidentailsAddress($customer_id)
	{
        $this->db->limit(1);
        $this->db->order_by('id','desc');
        $this->db->select('address,address2,city,state,postal_code');
		$query = $this->db->get_where('address',array('customer_id'=>$customer_id,'address.address_type' => 1));
        $resaddress =  $query->row_array();
        if(!empty($resaddress)){
           return $resaddress;
        }else{
          $ress1 = array('address'=>'','address2' => '', 'city' => '' ,'state' => '' ,'postal_code' => '');
          return $ress1;
        }
	}

	public function getBillingAddress($customer_id)
	{
        $this->db->limit(1);
        $this->db->order_by('id','desc');
        $this->db->select('address,address2,city,state,postal_code');
		$query = $this->db->get_where('address',array('customer_id'=>$customer_id,'address.address_type' => 2));
        $billingaddress =  $query->row_array();

        if(!empty($billingaddress)){
           return $billingaddress;
        }else{
          $billing = array('address'=>'','address2' => '', 'city' => '' ,'state' => '' ,'postal_code' => '');
          return $billing;
        }
	}

	public function deleteCustomers($customer_id)
	{
		$this->db->where('id', $customer_id);
        $this->db->delete('user_register');
        return true;
	}



	public function deletePersonalDetails($customer_id)
	{
		$this->db->where('id', $customer_id);
        $this->db->delete('personnel');
        return true;
	}


	public function deleteNewsDetails($customer_id)
	{
		$this->db->where('id', $customer_id);
        $this->db->delete('news');
        return true;
	}

	


	
}