<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->table = 'users';	
	}

	public function addRow($tab, $array, $disp = false) {
	        $this->db->insert($tab, $array);

	        $insert_id = $this->db->insert_id();
	        if($disp){
	            return $this->db->last_query();
	        }
	        return $insert_id;
    }

	public function updateRow($tab, $array, $where_field, $where_value,$disp = false) {
	    $this->db->where($where_field, $where_value);
	    $result = $this->db->update($tab, $array);
	  
	    if($disp){
	        return $this->db->last_query();
	    }
	    return $result;
	}

	public function login($username, $password){
		$user=$this->db->limit(1)->get_where('users',array('username'=>$username,'password'=>md5($password),'status'=>1));
		if($user->num_rows()){
			return $user->row_array();
		}else {
			return false;
		}
		
	}

	public function add($data){
		$data['date_added'] = date('Y-m-d H:i:s');	
		$this->db->insert($this->table,$data);
		return $this->db->insert_id();
    }

	public function getUsers(){
        $this->db->order_by('user_id','desc');
        $this->db->select('user.*,department.name as department_name ,designation.name as designation_name');
		$this->db->join('department','department.department_id=user.department','left');
		$this->db->join('designation','designation.designation_id=user.designation','left');
        $query = $this->db->get('user');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
        
	}

	public function getUsersGroup(){
		$query = $this->db->get('user_group');
		if($query->num_rows()){
            return $query->result_array();
		}else {
			return false;
		}
	}

	public function getUsersById($id){
		$query = $this->db->get_where('user',array('user_id'=>$id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}
	}

	public function update($data,$id){
		$this->db->where('user_id',$id);
		$this->db->update($this->table,$data);
		return $this->db->affected_rows();
	}
 

    public function getUsersGroupById($id){
		$query = $this->db->get_where('user_group',array('user_group_id'=>$id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}
	}

	public function getSubcriber(){
		$this->db->order_by('created','desc');
		$query = $this->db->get('suscriber');
		if($query->num_rows()){
            return $query->result_array();
		}else {
			return false;
		}
	}

	public function getSalaryDetails($id){
		$query = $this->db->get_where('user_salary_details',array('user_id'=>$id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}

	}

	public function getBankDetails($id){
		$query = $this->db->get_where('user_bank_details',array('user_id'=>$id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}

	}

    public function getContactDetails($id){
		$query = $this->db->get_where('user_contact_details',array('user_id'=>$id));
		if($query->num_rows()){
			return $query->row_array();
		}else {
			return false;
		}

	}

	public function getDepartments(){
		$this->db->order_by('name','asc');
		$query = $this->db->get('department');
		if($query->num_rows()){
            return $query->result_array();
		}else {
			return false;
		}
	}

	public function getDesignations(){
		$this->db->order_by('name','asc');
		$query = $this->db->get('designation');
		if($query->num_rows()){
            return $query->result_array();
		}else {
			return false;
		}
	}

	public function getDepartmentbyid($department_id){
		$query = $this->db->get_where('department',array('department_id'=>$department_id));
		if($query->num_rows()){
            return $query->row_array();
		}else {
			return false;
		}
    }

	public function getDesignationbyid($designation_id){
		$query = $this->db->get_where('designation',array('designation_id'=>$designation_id));
		if($query->num_rows()){
            return $query->row_array();
		}else {
			return false;
		}

	}

	public function getActiveDepartments(){
		$this->db->order_by('name','asc');
		$query = $this->db->get_where('department',array('status'=>1));
		if($query->num_rows()){
            return $query->result_array();
		}else {
			return false;
		}
	}

	public function getActiveDesignations(){
		$this->db->order_by('name','asc');
		$query = $this->db->get_where('designation',array('status'=>1));
		if($query->num_rows()){
            return $query->result_array();
		}else {
			return false;
		}
	}

	public function getnigeriastateslga($state_id)
	{
		$this->db->select('*');
        $query = $this->db->get_where('locals',array('state_id'=>$state_id));
		if($query->num_rows()){
			return $query->result_array();
			//return $res['name'];
		}else {
			return false;
		}
	}


	
}