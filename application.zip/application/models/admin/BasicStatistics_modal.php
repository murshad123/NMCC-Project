<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BasicStatistics_modal extends CI_Model {

    public function insertdata($table,$dataArray)
	{
		$resultData = $this->db->insert($table,$dataArray);
        
		if($resultData){
			return true;
		}else {
			return false;
		}
	}

	public function updateRow($tab, $array, $where_field, $where_value,$disp = false) {
	    $this->db->where($where_field, $where_value);
	    $result = $this->db->update($tab, $array);
	  
	    if($disp){
	        return $this->db->last_query();
	    }
	    return $result;
	}
	
	
	

	public function getactivecountries()
	{
		$this->db->select('country_id,name');
        $query = $this->db->get('country');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getcontinents()
	{
	   $query = $this->db->get('continents');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	
	



	public function getculturesHeld()
	{
		$this->db->order_by('id','asc');
		$this->db->select('*');
        $query = $this->db->get_where('cultures_held');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return 0;
		}
	}

	
public function GetCulturesDetails($cultures_held_id){
		$this->db->select('*');
		$query = $this->db->get_where('cultures_held',array('id' =>$cultures_held_id));
		if($query->num_rows()){
			$res = $query->row_array();
		}else{
			$res = array();
		}
		return $res;

	}

	public function getstrain(){
		$this->db->order_by('id','asc');
		$this->db->select('*');
        $query = $this->db->get_where('strain');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return 0;
		}

	}


/*function fetch_dataCountry($query)
 {
 	
  $this->db->like('name', $query);
  $query = $this->db->get('country');
  if($query->num_rows() > 0)
  {
   foreach($query->result_array() as $row)
   {
    $output[] = array('name' => $row["name"]);
   }
   echo json_encode($output);
  }
 }*/

	

	

	public function deleteculturesHeldDetails($cultures_held_id)
	{
		$this->db->where('id',$cultures_held_id);
        $this->db->delete('cultures_held');
        return true;
	}


	public function getcultureCollection()
	{
		$this->db->order_by('id','asc');
		$this->db->select('*');
        $query = $this->db->get_where('cultures_held');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return 0;
		}
	}

	public function getContinentsCountry($continent_cod)
	{
		$this->db->select('*');
        $query = $this->db->get_where('country',array('continent_code'=>$continent_cod));
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}


	


    
    function uploadData()
    {
        $count=0;
        $fp = fopen($_FILES['userfile']['tmp_name'],'r') or die("can't open file");
        while($csv_line = fgetcsv($fp,1024))
        {
            $count++;
            if($count == 1)
            {
                continue;
            }//keep this if condition if you want to remove the first row
            for($i = 0, $j = count($csv_line); $i < $j; $i++)
            {
                $insert_csv = array();
                $insert_csv['id'] = $csv_line[0];//remove if you want to have primary key,
                $insert_csv['empName'] = $csv_line[1];
                $insert_csv['empAddress'] = $csv_line[2];

            }
            $i++;
            $data = array(
                'id' => $insert_csv['id'] ,
                'empName' => $insert_csv['empName'],
                'empAddress' => $insert_csv['empAddress'],
            );
            $data['crane_features']=$this->db->insert('tableName', $data);
        }
        fclose($fp) or die("can't close file");
        $data['success']="success";
        return $data;
    }

    public function getstraincultures()
	{
		$this->db->order_by('id','asc');
		$this->db->select('*');
        $query = $this->db->get_where('strain');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return 0;
		}
	}


	public function GetStrainCulturesDetails($strain_id){
		$this->db->select('*');
		$query = $this->db->get_where('strain',array('id' =>$strain_id));
		if($query->num_rows()){
			$res = $query->row_array();
		}else{
			$res = array();
		}
		return $res;

	}


	public function deleteStrainCulturesDetails($strain_id)
	{
		$this->db->where('id',$strain_id);
        $this->db->delete('strain');
        return true;
	}



 public function insertdata2($table,$dataArray,$value)
	{
	 $query = $this->db->get_where('number_culture_collection',array('country_name' =>$value));
           if($query->num_rows()){

			  $this->db->where('country_name',$value);
              $this->db->delete('number_culture_collection');
              $resultData = $this->db->insert($table,$dataArray);
			        
					if($resultData){
						return true;
					}else {
						return false;
					}

		}else {
						$resultData = $this->db->insert($table,$dataArray);
			        
					if($resultData){
						return true;
					}else {
						return false;
					}
		  }
		
	}

public function insertdata3($table,$dataArray,$value)
	{
	 $query = $this->db->get_where('service_provided',array('countries' =>$value));
           if($query->num_rows()){

			  $this->db->where('countries',$value);
              $this->db->delete('service_provided');
              $resultData = $this->db->insert($table,$dataArray);
			        
					if($resultData){
						return true;
					}else {
						return false;
					}

		}else {
						$resultData = $this->db->insert($table,$dataArray);
			        
					if($resultData){
						return true;
					}else {
						return false;
					}
		  }
		
	}

	



}


