<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order_modal extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->table = 'orders';	
	}

	public function getorders()
	{
		$this->db->order_by('orders.id','desc');
        $this->db->select('orders.id,orders.order_number,customers.firstname,customers.lastname,orders.store_name,orders.locker_name,orders.access_code,orders.created_date,orders.order_status');
        $this->db->from('orders');
        $this->db->join('customers', 'customers.id = orders.customer_id');
        $query = $this->db->get();     
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	public function getorderservices($order_id)
	{	
        $this->db->select('GROUP_CONCAT(orders_services.services_name) as orderservices');
        $query = $this->db->get_where('orders_services',array('order_id'=>$order_id));    
		if($query->num_rows()){
			$res =  $query->row_array();
			return $res['orderservices'];
		}else {
			return false;
		}
	}

	


	
}