<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Acronyms_modal extends CI_Model {

    public function insertdata($table,$dataArray)
	{
		$resultData = $this->db->insert($table,$dataArray);
        
		if($resultData){
			return true;
		}else {
			return false;
		}
	}

	public function updateRow($tab, $array, $where_field, $where_value,$disp = false) {
	    $this->db->where($where_field, $where_value);
	    $result = $this->db->update($tab, $array);
	  
	    if($disp){
	        return $this->db->last_query();
	    }
	    return $result;
	}
	
	
	

	public function getacronyms()
	{
		$this->db->order_by('id','asc');

        $this->db->select('*');
        
        $query = $this->db->get('acronyms');
		if($query->num_rows()){
			return $query->result_array();
		}else {
			return false;
		}
	}

	

	
	
	
	


	public function GetAcronymsDetails($acronym_id){
		$this->db->select('*');
		$query = $this->db->get_where('acronyms',array('id' =>$acronym_id));
		if($query->num_rows()){
			$res = $query->row_array();
		}else{
			$res = array();
		}
		return $res;

	}

	

	

	public function deleteAcronym($acronym_id)
	{
		$this->db->where('id', $acronym_id);
        $this->db->delete('acronyms');
        return true;
	}

	


	
}