<?php
/**
 * Template Name: Localiza puntos de venta
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?>


<?php get_header(); ?>

           
                <style>
                .tooltip-container {
                    position:relative;
                }
                .tooltips {
                    background-color: #0091da!important;  
                    color:#fff;
                    font-size:13px;
                    line-height:1.4;
                    padding:10px;
                    position:absolute;
                    top: 35px;
                    left: -30px;
                    display:none;
                    width: 220px;
                    text-transform: none;
                }
                  
                .tooltips:before {
                    content:"";
                    position:absolute;
                    bottom: 100%;
                    left:20px;
                    width:0;
                    height:0;
                    border-width:15px;
                    border-style:solid;
                    border-color: transparent transparent #0091da transparent;
                }

                .tooltip-container:hover .tooltips {
                    display:block!important;
                }
                    
                </style>




<style type="text/css">
.popup .close {
    position: absolute;
    top: 20px;
    right: 30px;
    transition: all 200ms;
    font-size: 30px;
    font-weight: bold;
    text-shadow: none;
    width: 40px;
    text-align: center;
    height: 40px;
    padding: 6px;
    border-radius: 100%;
    box-shadow: none;
    background: rgba(3, 169, 244, 0.69)!important;
    text-decoration: none;
    color: #fff;
}
.popup.container {
    /* min-height: 450px; */
    background: #fff;
    padding: 30px 25px;
    position: relative;
    top: 10%;
    width: 60%;
}
    #map {
    overflow: visible!important;
    position: static!important;
 
}
.page:not(.home) #content{
    padding-bottom: 0!important;
}
.pdv-map-res-main{
  min-height: 650px!important;
}
.buscar-btn {
    padding: 19px 27px!important;
    font-size: 15px!important;
    font-weight: normal!important;
    border-radius: 0!important;
    background: #0092d4!important;
}
.table-list {
    padding: 0px 7px 0 20px;
    overflow-x: scroll;
    height: 650px;
}
</style>
<script 
    src="https://maps.googleapis.com/maps/api/js?v=3&libraries=places&key=AIzaSyCLoLZlbJ7HC0YaLxFn1Rmw5G4LxMrE9aw">
    </script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" ></script>


<?php
error_reporting(E_ALL ^ E_WARNING); 

function compareByName($a, $b) {
  return strcmp($a["nombre"], $b["nombre"]);
}



function getNearestPostalcode($postalcode,$countrycode){
  $nearestData = file_get_contents('http://api.geonames.org/findNearbyPostalCodesJSON?postalcode='.$postalcode.'&country='.$countrycode.'&radius=10&username=vikram4585'); 
  if(!empty($nearestData)){
    $postal = json_decode($nearestData);
    $postalData = json_decode(json_encode($postal), true); 
    $close_postalcode = array_column($postalData['postalCodes'], 'postalCode');
  }else{
    $close_postalcode = array();
  }
  return $close_postalcode;
}

function addressKeySearch($address,$searchkey){
    $searchAddress = json_decode(json_encode($address), true);
    $typesArray = array_column($searchAddress, 'types');
    if(!empty($typesArray)){
          $keyLookUpArray = array();
          foreach ($typesArray as $key1 => $value1) {
            $keyLookUpArray[$key1] = $value1[0];
          }
    }
    $keeys = array_search($searchkey, $keyLookUpArray);
    return $keeys;
}



function getZipcode($address){
    if(!empty($address)){
        $formattedAddr = str_replace(' ','+',$address);
        $geocodeFromAddr = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyCLoLZlbJ7HC0YaLxFn1Rmw5G4LxMrE9aw&address='.$formattedAddr.''); 
        if(!empty($geocodeFromAddr)){
          $output1 = json_decode($geocodeFromAddr);
        }else{
          $output1 = array();
        }
        return $output1;
      }
}

$pointsalearray = array();
if(!empty($_POST)){
  //echo "<pre>";
  //print_r($_POST); die;
  $searchtext = $_POST['cherchbox'];
  $leyenda = $_POST['type'];
  $leyenda = implode("','",$leyenda);
  
  if(!empty($searchtext) && $searchtext!=''){
     $addressDetails = getZipcode($searchtext);
     if(!empty($addressDetails)){
        $mapZoom = '9';
        $postalcodekey = addressKeySearch($addressDetails->results[0]->address_components,'postal_code');
        $countrycodekey = addressKeySearch($addressDetails->results[0]->address_components,'country');
        $latitude  = $addressDetails->results[0]->geometry->location->lat; 
        $longitude = $addressDetails->results[0]->geometry->location->lng;
        $addresspostal_code = $addressDetails->results[0]->address_components[$postalcodekey]->long_name;
        $addresscountry_code = $addressDetails->results[0]->address_components[$countrycodekey]->short_name;
       //echo $addresspostal_code;
        if(!preg_match('#[^0-9]#',$addresspostal_code))
        {
           /* $nearestPostalCode = getNearestPostalcode($addresspostal_code,$addresscountry_code);

            $nearestPostalCode = array_unique($nearestPostalCode);
            if(!empty($nearestPostalCode)){
              $postalcodeiid = implode("','",$nearestPostalCode);
              $query_parts = array();
              foreach ($nearestPostalCode as $val) {
                  $query_parts[] = "'%".$val."%'";
              }
              $string = implode(' OR wp_postmeta.meta_value LIKE ', $query_parts);

              $sql2 ="LIKE {$string}";
            }else{
              $sql2 = "like '%".$addresspostal_code."%'";md_codigo_postal
            }*/
            $sql2 = "like '%".$addresspostal_code."%' ) or ( wp_postmeta.meta_key = 'md_codigo_postal' and wp_postmeta.meta_value like '%".$addresspostal_code."%'";
        }
        else
        {
            $sql2 = "like '%".$addresspostal_code."%' ) or ( wp_postmeta.meta_key = 'md_codigo_postal' and wp_postmeta.meta_value like '%".$addresspostal_code."%'";
        }


      $sql1 = "select GROUP_CONCAT(wp_posts.ID) as posid from wp_postmeta join wp_posts on wp_posts.ID = wp_postmeta.post_id where ((wp_postmeta.meta_key = 'direccion' and wp_postmeta.meta_value" ;
      $sql3 = " ))and wp_posts.post_type = 'puntos-venta' and wp_posts.post_status='publish'";

      
        $sql = $sql1.' '.$sql2.' '.$sql3;

     

      $posi = $wpdb->get_results( $sql );
      if(!empty($posi)){
        $posi = json_decode(json_encode($posi), true);
        $pointsaleiid=array_map('intval', explode(',', $posi[0]['posid']));
        $pointsaleiid = implode("','",$pointsaleiid);


        $posIds = $wpdb->get_results( "select wp_posts.ID from wp_postmeta join wp_posts on wp_posts.ID = wp_postmeta.post_id  where wp_postmeta.meta_key = 'mid_tipo_puntoventa' and wp_postmeta.meta_value in ('".$leyenda."') and wp_postmeta.post_id in ('".$pointsaleiid."')  " );


      }else{
        $posIds = array();
      }

      }else{ $posIds = array(); }

      
  }else{
     $mapZoom = '5';
     $latitude  = '40.4378698';
     $longitude = '-3.8196207';

    $posIds = $wpdb->get_results( "select wp_posts.ID from wp_postmeta join wp_posts on wp_posts.ID = wp_postmeta.post_id where wp_postmeta.meta_key = 'mid_tipo_puntoventa' and wp_postmeta.meta_value in ('".$leyenda."') and wp_posts.post_type = 'puntos-venta' and wp_posts.post_status='publish'" );
  }
  
  
}else{
   $mapZoom = '5';
   $latitude  = '40.4378698';
   $longitude = '-3.8196207';
  $posIds = $wpdb->get_results( "SELECT ID from wp_posts where wp_posts.post_type = 'puntos-venta' and wp_posts.post_status='publish'" );
}

$preminum_values = array();
$premimum_filter = array();
$check = 1;
 
$postArray = json_decode(json_encode($posIds), true);
$postid = array_column($postArray, 'ID');
if(!empty($postid) && is_array($postid)){
    if(!empty($_POST)){
      if(in_array('retail', $_POST['type'])){
        $check = 1;
      }else{
        $check = 2;
      }
    }else{
      $check = 1;
    }

    //echo $check.':check';
    foreach ($postid as $postkey => $postvalue) {
        //in_array('retail', $_POST['type'])
        if($check == 1)
        {
          //echo "iff";
          $acfvalue = get_field( "field_5d124ff266097",$postvalue);
          $testacf[$postvalue] = $acfvalue;  
          if($acfvalue == 'si'){
            $premimum_filter[$postvalue] = $acfvalue;  
          }
          $pointsalearray = array();
          $preminumpointsalearray = array();
          $preminum_values = array_unique(array_keys($premimum_filter));
          $newpostiid = array_diff($postid,$preminum_values);
          //$preminumposidd = array_merge($preminum_values,$newpostiid);

          if(!empty($preminum_values)){
            foreach ($preminum_values as $preminumretailkey => $preminumretailvalue) {
              $premposdata = get_post_meta($preminumretailvalue);
              $premposdata['pos_id'] = array($preminumretailvalue);
              foreach($premposdata as $key=>$val)
              {
                $preminumpointsalearray[$preminumretailvalue][$key] = $val[0];
              }
            }
            
          }  
          if(!empty($newpostiid)){
            foreach ($newpostiid as $preminumposkey => $preminumposvalue) {
              $premposdata = get_post_meta($preminumposvalue);
              $premposdata['pos_id'] = array($preminumposvalue);
              foreach($premposdata as $key=>$val)
              {
                $pointsalearray[$preminumposvalue][$key] = $val[0];
              }
            }
            
          }  

        }else{
          //echo "else";
          $posdata = get_post_meta($postvalue);
          $posdata['pos_id'] = array($postvalue);
          
          foreach($posdata as $key=>$val)
          {
            $pointsalearray[$postvalue][$key] = $val[0];
          }

        }

        
        
    }
}




//echo "<pre>";
//echo $_POST['preminum'];
//echo count($preminum_values); 
//echo count($newpostiid);  die;


//echo count($newpostiid); die;





?>


<div id="shops-main" class="content-pdv">
    <div class="row image-row image-row-nofloat">
        <div class="img" style="background-image: url(<?php echo get_attachment_url_by_slug('puntos-venta'); ?>);">            
        </div>
         <div class="shadow"></div>
         <div class="container">
            <h1 class="col-xs-12"><?php the_title(); ?></h1>
         </div>
    </div>

    <div class="container container-search-pdv">
        <div class="row">
            <div class="shops-intro col-xs-12">
               <?php dynamic_sidebar( 'texto-puntosventa' ); ?>
            </div>
        </div>

        <form action="" method="post" id="searchform">
        <div class="row form-pdv-search-row">
            <div class="col-md-3">
                <label for="cherchbox" class="cherchbox-label">
                    <?php echo __('Código postal / Población','twentyseventeen');?>
                </label> 
            </div>
            <div class="col-md-4">
                <input type="search" name="cherchbox" value="<?php if(!empty($_POST['cherchbox'])){ echo $_POST['cherchbox']; }else{ } ?>" placeholder="<?php echo __('Buscar','twentyseventeen');?>..." id="cherchbox" class="cherchbox"/>
            </div>
            <div class="col-md-3">
      
                <input name="search" type="submit" class="buscar-btn" value="<?php echo __('Buscar','twentyseventeen');?>" ></th>
            </div>
            <div class="col-md-12">
                <span data-search-message id="no-results-message" style="display:none" class="u-text-size--lg c-alert c-alert--sm c-alert--neutral"></span>
            </div>
        </div>

   </div>
    <div class="leyenda">
        <div class="container">
            <span class="label-leyenda">
                <?php echo __('Leyenda','twentyseventeen');?>:
            </span>
            <span class="label-leyenda label-leyenda-hotspot label-leyenda-instalador">
                <input type="checkbox" name="type[]" onchange="jQuery('#searchform').submit();" value="instalador" <?php if(!empty($_POST['type'])){ if(in_array('instalador', $_POST['type'])){ echo "checked";} }else{
                  if(!empty($_POST)){}else{echo "checked";} } ?>>
                <img src="<?php echo bloginfo('template_url');?>/assets/icons/marker-instalador.png" alt="Instaladores"/>
                <?php echo __('Instalador / Ingeniería','twentyseventeen');?>
            </span>
            <span class="label-leyenda label-leyenda-hotspot label-leyenda-retail">
            <input type="hidden" name="preminum" value="0" id="preminum">
            <input type="checkbox" name="type[]" onchange="jQuery('#searchform').submit();" value="retail" <?php if(!empty($_POST['type'])){ if(in_array('retail', $_POST['type'])){ echo "checked";} }else{ if(!empty($_POST)){}else{echo "checked";}} ?>>
                <img src="<?php echo bloginfo('template_url');?>/assets/icons/marker-retail.png" alt="Retail"/>
                <?php echo __('Tienda de electrodomésticos','twentyseventeen');?>
            </span>
            <span class="label-leyenda label-leyenda-hotspot label-leyenda-distribuidor">
            <input type="checkbox" name="type[]" onchange="jQuery('#searchform').submit();" value="distribuidor" <?php if(!empty($_POST['type'])){ if(in_array('distribuidor', $_POST['type'])){ echo "checked";} }else{ if(!empty($_POST)){}else{echo "checked";}} ?>>
                <img src="<?php echo bloginfo('template_url');?>/assets/icons/marker-distribuidor.png" alt="Distribuidores"/>
                <?php echo __('Distribuidor','twentyseventeen');?>
               <!-- HTML to write -->
                <span class="tooltip-container" data-toggle="tooltip" > <!-- title="Comercialización de equipos de climatización y refrigeración al por mayor." -->

                    <i class="fa fa-info-circle " aria-hidden="true" ></i>

                    <div class="tooltips" >
                        <?php if ( get_field('distribuidor_tooltip_text') && get_field('distribuidor_tooltip_text')!="" ) {
                            the_field('distribuidor_tooltip_text');
                        } else { ?>
                            Comercialización de equipos de climatización y refrigeración al por mayor.
                        <?php } ?>
                    </div>
                    

                </span>
     

            </span>


    </div>



</div>
</form>
     

        </div>



<div class="map-main">

            <div class="row" id="mapview" >
              
                    <div class="col-md-3">
                      <div class="table-list row">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col" colspan="2"><b>Puntos de venta</b></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                           <?php if(!empty($preminumpointsalearray)){ 
                        array_multisort(array_column($preminumpointsalearray, 'nombre'), SORT_ASC, $preminumpointsalearray);
                        foreach($preminumpointsalearray as $retailposkeey => $retailposvallue){
                            $location_id = $retailposvallue['pos_id'];
                            $marker_title = $retailposvallue['nombre'];
                            $marker_address = $retailposvallue['direccion'];
                            $marker_email = $retailposvallue['e-mail'];
                            $marker_telephone = $retailposvallue['telefono'];
                            $marker_type = $retailposvallue['mid_tipo_puntoventa'];
                            $addressbar = unserialize($retailposvallue['midea_direccion_mapa']);
                            $latitude = $addressbar['lat'];
                            $longitude = $addressbar['lng'];
                            $mapurl = 'https://maps.google.com/maps?&z=10&q='.$latitude.'+'.$longitude.'&ll='.$latitude.'+'.$longitude.'&output=embed';
                           
                            ?>
                          <tr>
                          
                          <th scope="col">
                          <input type="hidden" id='address-<?php echo $location_id; ?>' value='<?php echo $marker_address; ?>'>
                          <input type="hidden" id='latitude-<?php echo $location_id; ?>' value='<?php echo $latitude; ?>'>
                          <input type="hidden" id='longitude-<?php echo $location_id; ?>' value='<?php echo $longitude; ?>'>
                          <a href="javascript:void(0)" style="text-transform: capitalize;""  onclick="getpracticsdetails('<?php echo $location_id; ?>','<?php echo $marker_title; ?>','<?php echo $marker_type; ?>','<?php echo $marker_address; ?>','<?php echo $marker_email; ?>','<?php echo $marker_telephone; ?>')"  ><?php echo ucwords(mb_strtolower($retailposvallue['nombre'],'UTF-8')); ?></a>

                          </th>
                          <th scope="col"><?php  if($retailposvallue['mid_tipo_puntoventa'] == 'retail'){ echo "Tienda electrodomésticos";}else{ echo ucfirst($retailposvallue['mid_tipo_puntoventa']); } ?> </th>
                          <?php } }?>
                      
                    <?php if(!empty($pointsalearray)){ 
                        array_multisort(array_column($pointsalearray, 'nombre'), SORT_ASC, $pointsalearray);
                        foreach($pointsalearray as $poskeey => $posvallue){
                            $location_id = $posvallue['pos_id'];
                            $marker_title = $posvallue['nombre'];
                            $marker_address = $posvallue['direccion'];
                            $marker_email = $posvallue['e-mail'];
                            $marker_telephone = $posvallue['telefono'];
                            $marker_type = $posvallue['mid_tipo_puntoventa'];
                            $addressbar = unserialize($posvallue['midea_direccion_mapa']);
                            $latitude = $addressbar['lat'];
                            $longitude = $addressbar['lng'];
                            $mapurl = 'https://maps.google.com/maps?&z=10&q='.$latitude.'+'.$longitude.'&ll='.$latitude.'+'.$longitude.'&output=embed';
                           
                            ?>
                          <tr>
                          
                          <th scope="col">
                          <input type="hidden" id='address-<?php echo $location_id; ?>' value='<?php echo $marker_address; ?>'>
                          <input type="hidden" id='latitude-<?php echo $location_id; ?>' value='<?php echo $latitude; ?>'>
                          <input type="hidden" id='longitude-<?php echo $location_id; ?>' value='<?php echo $longitude; ?>'>
                          <a href="javascript:void(0)"  onclick="getpracticsdetails('<?php echo $location_id; ?>','<?php echo $marker_title; ?>','<?php echo $marker_type; ?>','<?php echo $marker_address; ?>','<?php echo $marker_email; ?>','<?php echo $marker_telephone; ?>')" ><?php echo ucwords(mb_strtolower($posvallue['nombre'],'UTF-8')) ; ?></a>

                          </th>
                          <th scope="col"><?php  if($posvallue['mid_tipo_puntoventa'] == 'retail'){ echo "Tienda electrodomésticos";}else{ echo ucfirst($posvallue['mid_tipo_puntoventa']);} ?></th>
                          <?php } }else{?>
                          <tr><th colspan="2">No record found</th></tr>
                          <?php } ?>
                        </tr>
                       

                      </tbody>

                </table>
                </div>
                </div>  
                     
                      <div class="col-md-9">
                        <div class="row">
                         <div id="pdv-map-res" class="pdv-map-res-main"></div>
                          </div>
        
                      </div>
                
        </div>
                </div> 

<div class="modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" class="overlay">

    <div class="popup container">
        <h2 id="practicsname"></h2>
        <a class="close"  data-dismiss="modal" aria-label="Close" href="#">&times;</a>
        <div class="content col-md-6">
      <div class="row">
      <div class="col-md-7">
            <ul class="nav  ">
                <li id="practicsaddress"></li>
                <li id="practicsservice"></li>
                <li id="practicshour"></li>
                <li id="practicscontact"></li>
                
            </ul>
    
    </div>
  </div>
 </div>
        <div class=" col-md-6" style="padding-top: 10px;" id="practicsmap" >
            
        </div>
            
          
    </div>
    </div>
<?php get_footer(); 

$themespath =  get_template_directory_uri(); ?>

<script type="text/javascript">

  function applypreminumfilter(){
    jQuery('#preminum').val(1);
    jQuery('#searchform').submit();
  }

  function getpracticsdetails_dev(markertitle,markeraddress,markeremail,markerphone,markertype,maplink){
    var addresshtml = "<span><b>Dirección:</b></span><br>"+markeraddress;
    var hourshtml = "<span><b>Teléfono:</b></span><br>"+markerphone;
    var maphtml = "<iframe  src='"+maplink+"' width='100%'' height='250px' frameborder='0' style='border:0' allowfullscreen></iframe>";
    var contacthtml = "<span><b>E-Mail:</b></span><br>"+markeremail;
    var serviceHtml = "<span><b>LEYENDA:</b></span><br>"+markertype;
    jQuery('#practicsname').html(markertitle);
    jQuery('#practicsaddress').html(addresshtml);
    jQuery('#practicshour').html(hourshtml);
    jQuery('#practicscontact').html(contacthtml);
    jQuery('#practicsmap').html(maphtml);
    jQuery('#practicsservice').html(serviceHtml);
  } 

  function getpracticsdetails(marker_id,markertitle,markertype,markeraddress,markeremail,markerphone){
    var marker;
    var lat = jQuery("#latitude-"+marker_id).val();
    var lng = jQuery("#longitude-"+marker_id).val();
    var infowindow = new google.maps.InfoWindow();
    var mapiconurl = '<?php echo $themespath; ?>'+'/assets/icons/marker-'+markertype+'.png';
    var map = new google.maps.Map(document.getElementById('pdv-map-res'), {
      zoom: 15,
      center: new google.maps.LatLng(lat, lng),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    marker = new google.maps.Marker({
        position: new google.maps.LatLng(lat, lng),
        map: map,
        title: markertitle,
        icon : mapiconurl
    });

    var contentString = '<div id="content">'+
            '<div id="siteNotice">'+
            '</div>'+
            '<h4 id="firstHeading" class="firstHeading">' + markertitle + '</h4>'+
            '<div id="bodyContent">'+
            '<p><b>Dirección : </b>' + markeraddress + '</p>'+
            '<p><b>E-Mail : </b>' + markeremail + '</p>'+
            '<p><b>Teléfono:</b>' + markerphone + '</p>'+
            '</div>'+
            '</div>';
          //alert(locations[i][0]);
    infowindow.setContent(contentString);
    infowindow.open(map, marker);
  } 

  function initialize() {
    var input = document.getElementById('cherchbox');
    var options = {
        componentRestrictions: {country: 'es'}
      };
    var autocomplete = new google.maps.places.Autocomplete(input,options);
  }
  google.maps.event.addDomListener(window, 'load', initialize);
</script>

<script>

 
   
  var locations = [];

   <?php 
   
   foreach ($pointsalearray as $kkey => $item){

   $iconurl = $themespath.'/assets/icons/marker-'.$item['mid_tipo_puntoventa'].'.png';
   $latlng_array = unserialize($item['midea_direccion_mapa']);
     if(!empty($item['direccion'])){
      $marker_address = (string)$item['direccion'];
     }else{
      $marker_address = 'N/A';
     }
   
    if(!empty($item['e-mail'])){
       $marker_email = $item['e-mail'];
    }else{
      $marker_email = 'N/A';
    }

     if(!empty($item['telefono'])){
       $marker_telephone = $item['telefono'];
     }else{
      $marker_telephone = 'N/A';
     }

   


    ?>
   // var cptaddress = '<?php echo $marker_address; ?>';
   var markerid = '<?php echo $item['pos_id']; ?>';
    var telefono = '<?php echo $marker_telephone; ?>';
    var cptemail = '<?php echo $marker_email; ?>';
    locations.push(["<?php echo $item['nombre']?>",<?php echo $latlng_array['lat']?>,<?php echo $latlng_array['lng']?>,"<?php echo $iconurl;?>",cptemail,telefono,markerid]);
    //locations.push(telefono);
    //locations.push(cptemail);
   <?php } ?>

    //alert(locations); 

    var lat = "<?php echo $latitude; ?>";
    var lng = "<?php echo $longitude; ?>";
    var zoomMap = '<?php echo $mapZoom; ?>';
    var zoomSize = Number(zoomMap);
    //alert(zoomMap);
    //alert(lat);
    //alert(lng);
    var map = new google.maps.Map(document.getElementById('pdv-map-res'), {
      zoom: zoomSize,
      center: new google.maps.LatLng(lat, lng),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();
    var marker, i;
    

    for (i = 0; i < locations.length; i++) { 

        marker = new google.maps.Marker({

        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
        title: locations[i][0],
        icon: locations[i][3]
      });

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          var markeraddressname = jQuery('#address-'+locations[i][6]).val();
          var contentString = '<div id="content">'+
            '<div id="siteNotice">'+
            '</div>'+
            '<h4 id="firstHeading" class="firstHeading">' + locations[i][0] + '</h4>'+
            '<div id="bodyContent">'+
            '<p><b>Dirección : </b>' + markeraddressname + '</p>'+
            '<p><b>E-Mail : </b>' + locations[i][4] + '</p>'+
            '<p><b>Teléfono: : </b>' + locations[i][5] + '</p>'+
            '</div>'+
            '</div>';
          //alert(locations[i][0]);
         infowindow.setContent(contentString);
         infowindow.open(map, marker);
        }
      })(marker, i));
    }
        </script>
    
  

 
   